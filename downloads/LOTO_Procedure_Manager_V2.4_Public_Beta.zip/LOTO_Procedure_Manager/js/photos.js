// Photo import/compression, the shared photo composer (crop + callouts), and the photo editor.
// The composer (drawComposed) is the ONLY code that draws a photo into a procedure, so the
// preview, print, PNG and SVG outputs all show the same crop and the same callouts.
// Editor handles and selection outlines are drawn by the editor only and never reach an output.
const LotoPhotos = (() => {
  const MAX_EDGE = 1600;                 // long edge stored for a new photo (px)
  const MIN_EDGE = 1280;                 // smallest long edge the compressor will fall back to
  const QUALITIES = [0.82, 0.74, 0.66, 0.6];
  const TARGET_BYTES = 350 * 1024;       // per-photo size target
  const LOW_RES_EDGE = 800;              // warn when the source is smaller than this
  const BUDGET_BYTES = 24 * 1024 * 1024; // local photo-data budget shown by the storage meter
  const MAX_ZOOM = 6;
  const FRAME_ASPECT = { Landscape: 4 / 3, Portrait: 3 / 4 };
  const COLORS = [
    { value: '#e02020', name: 'Red' },
    { value: '#ffd400', name: 'Yellow' },
    { value: '#ffffff', name: 'White' },
    { value: '#000000', name: 'Black' }
  ];
  const TYPE_NAMES = { arrow: 'Arrow', circle: 'Circle', marker: 'Number' };

  const $ = id => document.getElementById(id);
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  function newId() {
    return (crypto.randomUUID ? crypto.randomUUID() : 'ph-' + Date.now() + '-' + Math.random().toString(16).slice(2));
  }

  function frameAspect(orientation) {
    return FRAME_ASPECT[orientation] || FRAME_ASPECT.Landscape;
  }

  function fmtBytes(n) {
    if (!Number.isFinite(n)) return '—';
    if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(n >= 10 * 1024 * 1024 ? 0 : 1) + ' MB';
    return Math.max(1, Math.round(n / 1024)) + ' KB';
  }

  function defaultCrop() {
    return { cx: 0.5, cy: 0.5, zoom: 1, rotation: 0 };
  }

  // Returns a clean copy of stored photo metadata (tolerates partial/old data).
  function normalizeMeta(meta) {
    if (!meta || !meta.photoId) return null;
    const c = meta.crop || {};
    const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
    return {
      photoId: String(meta.photoId),
      crop: {
        cx: clamp(num(c.cx, 0.5), 0, 1),
        cy: clamp(num(c.cy, 0.5), 0, 1),
        zoom: clamp(num(c.zoom, 1), 1, MAX_ZOOM),
        rotation: ((Math.round(num(c.rotation, 0) / 90) * 90) % 360 + 360) % 360
      },
      callouts: (Array.isArray(meta.callouts) ? meta.callouts : [])
        .filter(k => k && TYPE_NAMES[k.type])
        .map(k => ({
          id: String(k.id || newId()),
          type: k.type,
          x: num(k.x, 0.5), y: num(k.y, 0.5),
          x2: num(k.x2, 0.4), y2: num(k.y2, 0.6),
          r: Math.max(0.005, num(k.r, 0.1)),
          n: Math.max(1, Math.round(num(k.n, 1))),
          label: String(k.label || '').slice(0, 40),
          color: COLORS.some(col => col.value === k.color) ? k.color : COLORS[0].value
        }))
    };
  }

  /* ---------- decode / compress ---------- */

  async function decode(blob) {
    if (typeof createImageBitmap === 'function') {
      try { return await createImageBitmap(blob, { imageOrientation: 'from-image' }); }
      catch (e) {
        try { return await createImageBitmap(blob); } catch (e2) { /* fall through to <img> */ }
      }
    }
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('The image could not be read.')); };
      img.src = url;
    });
  }

  function imgSize(img) {
    return { w: img.naturalWidth || img.width, h: img.naturalHeight || img.height };
  }

  function canvasBlob(canvas, type, quality) {
    return new Promise(resolve => canvas.toBlob(b => resolve(b), type, quality));
  }

  // Downscale in halving steps so fine detail (labels, valve handles) survives large reductions.
  function scaledCanvas(img, edge) {
    const { w, h } = imgSize(img);
    const ratio = Math.min(1, edge / Math.max(w, h));
    const tw = Math.max(1, Math.round(w * ratio));
    const th = Math.max(1, Math.round(h * ratio));
    let src = img, cw = w, ch = h;
    while (cw / 2 >= tw * 1.01) {
      const c = document.createElement('canvas');
      c.width = Math.round(cw / 2); c.height = Math.round(ch / 2);
      const cx = c.getContext('2d');
      cx.imageSmoothingQuality = 'high';
      cx.drawImage(src, 0, 0, c.width, c.height);
      src = c; cw = c.width; ch = c.height;
    }
    const out = document.createElement('canvas');
    out.width = tw; out.height = th;
    const ctx = out.getContext('2d');
    ctx.fillStyle = '#fff';           // flatten transparency (JPEG has no alpha)
    ctx.fillRect(0, 0, tw, th);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, tw, th);
    return out;
  }

  // Compresses a user-selected file into the asset that gets stored.
  // The original file is never kept. Returns:
  //   { blob, mime, width, height, bytes, originalBytes, overTarget, lowRes }
  // overTarget=true means the quality floor was reached before the size target;
  // the caller must tell the user instead of degrading the image further.
  async function importFile(file) {
    if (!file) throw new Error('No file selected.');
    let img;
    try { img = await decode(file); }
    catch (e) {
      throw new Error('This file could not be opened as an image. Use a JPEG, PNG or WebP photo (HEIC photos must be converted first).');
    }
    const { w, h } = imgSize(img);
    if (!w || !h) throw new Error('The image is empty.');
    const longEdge = Math.max(w, h);
    const edges = [...new Set([Math.min(MAX_EDGE, longEdge), Math.min(MIN_EDGE, longEdge)])];

    let type = 'image/webp';
    let best = null;
    outer:
    for (const edge of edges) {
      const canvas = scaledCanvas(img, edge);
      for (const q of QUALITIES) {
        let blob = await canvasBlob(canvas, type, q);
        if (!blob || blob.type !== type) {          // WebP encoding not supported here
          type = 'image/jpeg';
          blob = await canvasBlob(canvas, type, q);
        }
        if (!blob) throw new Error('This browser could not compress the image.');
        best = { blob, mime: blob.type, width: canvas.width, height: canvas.height, bytes: blob.size };
        if (blob.size <= TARGET_BYTES) break outer;
      }
    }
    if (img.close) img.close();
    return {
      ...best,
      originalBytes: file.size,
      overTarget: best.bytes > TARGET_BYTES,
      lowRes: longEdge < LOW_RES_EDGE
    };
  }

  /* ---------- geometry shared by composer and editor ---------- */

  // Crop model: (cx, cy) is the point of the SOURCE image shown at the frame centre
  // (0..1), zoom >= 1 is relative to "cover the frame", rotation is 0/90/180/270.
  // Callout positions are stored in source-image coordinates so they stay on the
  // equipment when the photo is repositioned, zoomed or rotated.
  function geometry(sw, sh, crop, fw, fh) {
    const rot = ((Math.round((crop.rotation || 0) / 90) * 90) % 360 + 360) % 360;
    const swap = rot % 180 !== 0;
    const rw = swap ? sh : sw, rh = swap ? sw : sh;
    const zoom = clamp(crop.zoom || 1, 1, MAX_ZOOM);
    const s = Math.max(fw / rw, fh / rh) * zoom;

    const fwd = (x, y) => rot === 90 ? [sh - y, x] : rot === 180 ? [sw - x, sh - y] : rot === 270 ? [y, sw - x] : [x, y];
    const inv = (px, py) => rot === 90 ? [py, sh - px] : rot === 180 ? [sw - px, sh - py] : rot === 270 ? [sw - py, px] : [px, py];

    let [pcx, pcy] = fwd((crop.cx ?? 0.5) * sw, (crop.cy ?? 0.5) * sh);
    const hw = fw / (2 * s), hh = fh / (2 * s);
    pcx = clamp(pcx, hw, rw - hw);
    pcy = clamp(pcy, hh, rh - hh);

    return {
      sw, sh, rw, rh, rot, s, pcx, pcy, fw, fh,
      unit: Math.sqrt(fw * fh) / 100,
      toFrame(u, v) {
        const [px, py] = fwd(u * sw, v * sh);
        return [fw / 2 + (px - pcx) * s, fh / 2 + (py - pcy) * s];
      },
      toImage(fx, fy) {
        const [x, y] = inv(pcx + (fx - fw / 2) / s, pcy + (fy - fh / 2) / s);
        return [x / sw, y / sh];
      },
      center() {
        const [x, y] = inv(pcx, pcy);
        return [x / sw, y / sh];
      }
    };
  }

  function outlineFor(color) {
    return (color === '#ffffff' || color === '#ffd400') ? '#000000' : '#ffffff';
  }

  function drawLabel(ctx, g, text, ax, ay, align) {
    if (!text) return;
    const U = g.unit;
    const size = 3.1 * U, pad = 0.8 * U;
    ctx.font = `700 ${size}px Arial, Helvetica, sans-serif`;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    const tw = ctx.measureText(text).width;
    const bw = tw + pad * 2, bh = size + pad * 2;
    let bx = align === 'left' ? ax : ax - bw / 2;
    let by = ay - bh / 2;
    bx = clamp(bx, 0.5 * U, Math.max(0.5 * U, g.fw - bw - 0.5 * U));
    by = clamp(by, 0.5 * U, Math.max(0.5 * U, g.fh - bh - 0.5 * U));
    ctx.fillStyle = 'rgba(255,255,255,0.93)';
    ctx.fillRect(bx, by, bw, bh);
    ctx.lineWidth = Math.max(1, 0.25 * U);
    ctx.strokeStyle = '#000';
    ctx.strokeRect(bx, by, bw, bh);
    ctx.fillStyle = '#000';
    ctx.fillText(text, bx + pad, by + bh / 2 + size * 0.04);
  }

  function drawCallout(ctx, k, g) {
    const U = g.unit;
    const color = k.color || COLORS[0].value;
    const outline = outlineFor(color);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (k.type === 'arrow') {
      const [hx, hy] = g.toFrame(k.x, k.y);
      const [tx, ty] = g.toFrame(k.x2, k.y2);
      const ang = Math.atan2(hy - ty, hx - tx);
      const head = 4.2 * U;
      const bx = hx - Math.cos(ang) * head * 0.85, by = hy - Math.sin(ang) * head * 0.85;
      const path = () => {
        ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(bx, by);
      };
      const tri = () => {
        ctx.beginPath();
        ctx.moveTo(hx, hy);
        ctx.lineTo(hx - Math.cos(ang - 0.42) * head, hy - Math.sin(ang - 0.42) * head);
        ctx.lineTo(hx - Math.cos(ang + 0.42) * head, hy - Math.sin(ang + 0.42) * head);
        ctx.closePath();
      };
      ctx.strokeStyle = outline; ctx.lineWidth = 1.7 * U; path(); ctx.stroke(); tri(); ctx.lineWidth = 0.8 * U; ctx.stroke();
      ctx.strokeStyle = color; ctx.lineWidth = 1.0 * U; path(); ctx.stroke();
      ctx.fillStyle = color; tri(); ctx.fill();
      drawLabel(ctx, g, k.label, tx - Math.cos(ang) * 3.4 * U, ty - Math.sin(ang) * 3.4 * U, 'center');
    } else if (k.type === 'circle') {
      const [cx, cy] = g.toFrame(k.x, k.y);
      const R = Math.max(1.5 * U, k.r * g.sw * g.s);
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.strokeStyle = outline; ctx.lineWidth = 1.6 * U; ctx.stroke();
      ctx.strokeStyle = color; ctx.lineWidth = 0.9 * U; ctx.stroke();
      drawLabel(ctx, g, k.label, cx, cy + R + 3.6 * U, 'center');
    } else if (k.type === 'marker') {
      const [cx, cy] = g.toFrame(k.x, k.y);
      const R = 3.3 * U;
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = color; ctx.fill();
      ctx.strokeStyle = outline; ctx.lineWidth = 0.55 * U; ctx.stroke();
      ctx.fillStyle = outline;
      ctx.font = `800 ${3.7 * U}px Arial, Helvetica, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(k.n), cx, cy + 0.2 * U);
      drawLabel(ctx, g, k.label, cx + R + 1.2 * U, cy, 'left');
    }
  }

  // Draws the cropped photo and its callouts into the rectangle (x, y, fw, fh) of ctx.
  function drawComposed(ctx, img, meta, x, y, fw, fh) {
    const { w, h } = imgSize(img);
    const g = geometry(w, h, meta.crop || defaultCrop(), fw, fh);
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, fw, fh); ctx.clip();
    ctx.translate(x, y);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, fw, fh);

    ctx.save();
    ctx.translate(fw / 2, fh / 2);
    ctx.scale(g.s, g.s);
    ctx.translate(-g.pcx, -g.pcy);
    if (g.rot === 90) { ctx.translate(g.rw, 0); ctx.rotate(Math.PI / 2); }
    else if (g.rot === 180) { ctx.translate(g.rw, g.rh); ctx.rotate(Math.PI); }
    else if (g.rot === 270) { ctx.translate(0, g.rh); ctx.rotate(-Math.PI / 2); }
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, w, h);
    ctx.restore();

    (meta.callouts || []).forEach(k => drawCallout(ctx, k, g));
    ctx.restore();
    return g;
  }

  // Largest rectangle with the photo-frame aspect that fits inside (x, y, w, h), centred.
  function fitFrame(x, y, w, h, orientation) {
    const a = frameAspect(orientation);
    let fw = w, fh = w / a;
    if (fh > h) { fh = h; fw = h * a; }
    return { x: x + (w - fw) / 2, y: y + (h - fh) / 2, w: fw, h: fh };
  }

  function composeCanvas(img, meta, orientation, longEdge) {
    const a = frameAspect(orientation);
    const fw = Math.round(a >= 1 ? longEdge : longEdge * a);
    const fh = Math.round(a >= 1 ? longEdge / a : longEdge);
    const canvas = document.createElement('canvas');
    canvas.width = fw; canvas.height = fh;
    drawComposed(canvas.getContext('2d'), img, meta, 0, 0, fw, fh);
    return canvas;
  }

  function composeDataURL(img, meta, orientation, longEdge = 1500) {
    return composeCanvas(img, meta, orientation, longEdge).toDataURL('image/jpeg', 0.9);
  }

  async function composeObjectURL(img, meta, orientation, longEdge = 1500) {
    const blob = await canvasBlob(composeCanvas(img, meta, orientation, longEdge), 'image/jpeg', 0.9);
    if (!blob) throw new Error('Could not render the photo.');
    return URL.createObjectURL(blob);
  }

  /* ---------- editor ---------- */

  let ed = null;       // active editor session
  let wired = false;

  function edGeometry() {
    const { w, h } = imgSize(ed.img);
    return geometry(w, h, ed.meta.crop, ed.canvas.width, ed.canvas.height);
  }

  function selected() {
    return ed && ed.meta ? ed.meta.callouts.find(k => k.id === ed.selectedId) || null : null;
  }

  function sizeCanvas() {
    const a = frameAspect(ed.orientation);
    const stage = $('photoStage');
    const maxW = Math.max(220, Math.min(640, stage.clientWidth - 4));
    const maxH = Math.max(220, Math.min(window.innerHeight * 0.66, 620));
    let cw = maxW, ch = cw / a;
    if (ch > maxH) { ch = maxH; cw = ch * a; }
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    ed.canvas.style.width = Math.round(cw) + 'px';
    ed.canvas.style.height = Math.round(ch) + 'px';
    ed.canvas.width = Math.round(cw * dpr);
    ed.canvas.height = Math.round(ch * dpr);
  }

  function handlePoints(k, g) {
    if (k.type === 'arrow') {
      return [{ kind: 'head', p: g.toFrame(k.x, k.y) }, { kind: 'tail', p: g.toFrame(k.x2, k.y2) }];
    }
    if (k.type === 'circle') {
      const [cx, cy] = g.toFrame(k.x, k.y);
      const R = Math.max(1.5 * g.unit, k.r * g.sw * g.s);
      return [{ kind: 'radius', p: [cx + R * Math.SQRT1_2, cy - R * Math.SQRT1_2] }];
    }
    return [];
  }

  function draw() {
    const c = ed.canvas, ctx = c.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, c.width, c.height);
    if (!ed.img || !ed.meta) {
      ctx.fillStyle = '#eef2f5';
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = '#66737f';
      ctx.font = `700 ${Math.round(c.width / 28)}px Arial, Helvetica, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('No photo yet — use “Upload Photo”', c.width / 2, c.height / 2);
      return;
    }
    const g = drawComposed(ctx, ed.img, ed.meta, 0, 0, c.width, c.height);

    // Editor-only overlay: selection handles. Never part of drawComposed.
    const k = selected();
    if (k) {
      const U = g.unit;
      ctx.save();
      handlePoints(k, g).forEach(hp => {
        const sz = 1.5 * U;
        ctx.fillStyle = '#fff'; ctx.strokeStyle = '#1f4f78'; ctx.lineWidth = Math.max(1.5, 0.4 * U);
        ctx.fillRect(hp.p[0] - sz, hp.p[1] - sz, sz * 2, sz * 2);
        ctx.strokeRect(hp.p[0] - sz, hp.p[1] - sz, sz * 2, sz * 2);
      });
      if (k.type === 'marker') {
        const [cx, cy] = g.toFrame(k.x, k.y);
        ctx.setLineDash([U, U]); ctx.strokeStyle = '#1f4f78'; ctx.lineWidth = Math.max(1.5, 0.4 * U);
        ctx.beginPath(); ctx.arc(cx, cy, 4.6 * U, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.restore();
    }
  }

  function setStatus(text, kind = '') {
    const s = $('photoStatus');
    s.textContent = text || '';
    s.className = 'photo-status' + (kind ? ' ' + kind : '');
  }

  function syncPanel() {
    const has = !!(ed.img && ed.meta);
    $('photoUploadLabelText').textContent = has ? 'Replace Photo' : 'Upload Photo';
    ['photoZoom', 'photoRotateLeftBtn', 'photoRotateRightBtn', 'photoResetCropBtn',
      'addArrowBtn', 'addCircleBtn', 'addMarkerBtn', 'photoRemoveBtn'].forEach(id => { $(id).disabled = !has; });
    $('photoZoom').value = has ? ed.meta.crop.zoom : 1;
    $('photoZoomValue').textContent = has ? Math.round(ed.meta.crop.zoom * 100) + '%' : '100%';

    if (has) {
      const { w, h } = imgSize(ed.img);
      const info = ed.info || {};
      const fmt = info.mime ? info.mime.replace('image/', '').toUpperCase() : '';
      $('photoInfo').textContent = [`${w} × ${h} px`, fmt, info.bytes ? fmtBytes(info.bytes) : ''].filter(Boolean).join(' · ');
    } else {
      $('photoInfo').textContent = 'No photo attached. The printed card keeps its placeholder.';
    }

    const list = $('calloutList');
    list.innerHTML = '';
    (has ? ed.meta.callouts : []).forEach(k => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'callout-chip' + (k.id === ed.selectedId ? ' selected' : '');
      b.dataset.calloutId = k.id;
      b.textContent = (k.type === 'marker' ? `Number ${k.n}` : TYPE_NAMES[k.type]) + (k.label ? ` — ${k.label}` : '');
      list.appendChild(b);
    });
    if (has && !ed.meta.callouts.length) {
      const empty = document.createElement('span');
      empty.className = 'photo-muted';
      empty.textContent = 'No callouts.';
      list.appendChild(empty);
    }

    const k = selected();
    $('calloutFields').classList.toggle('hidden', !k);
    if (k) {
      if (document.activeElement !== $('calloutLabel')) $('calloutLabel').value = k.label || '';
      $('calloutColor').value = k.color;
      $('calloutNumberWrap').classList.toggle('hidden', k.type !== 'marker');
      if (document.activeElement !== $('calloutNumber')) $('calloutNumber').value = k.n;
    }
  }

  function refresh() { draw(); syncPanel(); }

  function canvasPos(evt) {
    const r = ed.canvas.getBoundingClientRect();
    return [(evt.clientX - r.left) * ed.canvas.width / r.width, (evt.clientY - r.top) * ed.canvas.height / r.height];
  }

  function distToSegment(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay;
    const len2 = dx * dx + dy * dy || 1;
    const t = clamp(((px - ax) * dx + (py - ay) * dy) / len2, 0, 1);
    return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
  }

  function hitCallout(g, fx, fy) {
    const U = g.unit;
    const list = ed.meta.callouts;
    for (let i = list.length - 1; i >= 0; i--) {
      const k = list[i];
      const [x, y] = g.toFrame(k.x, k.y);
      if (k.type === 'marker' && Math.hypot(fx - x, fy - y) <= 4.4 * U) return k;
      if (k.type === 'circle') {
        const R = Math.max(1.5 * U, k.r * g.sw * g.s);
        if (Math.abs(Math.hypot(fx - x, fy - y) - R) <= 2.6 * U) return k;
      }
      if (k.type === 'arrow') {
        const [tx, ty] = g.toFrame(k.x2, k.y2);
        if (distToSegment(fx, fy, x, y, tx, ty) <= 2.8 * U) return k;
      }
    }
    return null;
  }

  function onPointerDown(evt) {
    if (!ed || !ed.img || !ed.meta) return;
    evt.preventDefault();
    const g = edGeometry();
    const [fx, fy] = canvasPos(evt);
    let drag = null;

    const sel = selected();
    if (sel) {
      const hp = handlePoints(sel, g).find(h => Math.hypot(fx - h.p[0], fy - h.p[1]) <= 3.2 * g.unit);
      if (hp) drag = { kind: hp.kind, id: sel.id };
    }
    if (!drag) {
      const hit = hitCallout(g, fx, fy);
      if (hit) { ed.selectedId = hit.id; drag = { kind: 'move', id: hit.id }; }
      else { ed.selectedId = null; drag = { kind: 'pan' }; }
    }
    drag.last = [fx, fy];
    ed.drag = drag;
    try { ed.canvas.setPointerCapture(evt.pointerId); } catch (e) { /* not critical */ }
    ed.canvas.classList.add('dragging');
    refresh();
  }

  function onPointerMove(evt) {
    if (!ed || !ed.drag) return;
    evt.preventDefault();
    const g = edGeometry();
    const [fx, fy] = canvasPos(evt);
    const [lx, ly] = ed.drag.last;
    const d = ed.drag;

    if (d.kind === 'pan') {
      const [u, v] = g.toImage(g.fw / 2 - (fx - lx), g.fh / 2 - (fy - ly));
      ed.meta.crop.cx = u; ed.meta.crop.cy = v;
      const [cu, cv] = edGeometry().center();     // store the clamped centre
      ed.meta.crop.cx = cu; ed.meta.crop.cy = cv;
    } else {
      const k = ed.meta.callouts.find(c => c.id === d.id);
      if (k) {
        const [u1, v1] = g.toImage(fx, fy);
        const [u0, v0] = g.toImage(lx, ly);
        const du = u1 - u0, dv = v1 - v0;
        const lim = v => clamp(v, -0.05, 1.05);
        if (d.kind === 'move') {
          k.x = lim(k.x + du); k.y = lim(k.y + dv);
          if (k.type === 'arrow') { k.x2 = lim(k.x2 + du); k.y2 = lim(k.y2 + dv); }
        } else if (d.kind === 'head') { k.x = lim(u1); k.y = lim(v1); }
        else if (d.kind === 'tail') { k.x2 = lim(u1); k.y2 = lim(v1); }
        else if (d.kind === 'radius') {
          const [cx, cy] = g.toFrame(k.x, k.y);
          k.r = Math.max(1.5 * g.unit, Math.hypot(fx - cx, fy - cy)) / (g.sw * g.s);
        }
      }
    }
    d.last = [fx, fy];
    draw();
  }

  function onPointerUp() {
    if (!ed || !ed.drag) return;
    ed.drag = null;
    ed.canvas.classList.remove('dragging');
    refresh();
  }

  function setZoom(z) {
    if (!ed.meta) return;
    ed.meta.crop.zoom = clamp(z, 1, MAX_ZOOM);
    const [cu, cv] = edGeometry().center();
    ed.meta.crop.cx = cu; ed.meta.crop.cy = cv;
    refresh();
  }

  function rotate(delta) {
    if (!ed.meta) return;
    ed.meta.crop.rotation = ((ed.meta.crop.rotation + delta) % 360 + 360) % 360;
    const [cu, cv] = edGeometry().center();
    ed.meta.crop.cx = cu; ed.meta.crop.cy = cv;
    refresh();
  }

  function addCallout(type) {
    if (!ed.img || !ed.meta) return;
    const g = edGeometry();
    const n = ed.meta.callouts.length;
    const off = ((n % 5) - 2) * 3 * g.unit;                 // avoid stacking new callouts exactly
    const fx = g.fw / 2 + off, fy = g.fh / 2 + off;
    const [u, v] = g.toImage(fx, fy);
    const k = { id: newId(), type, x: u, y: v, x2: u, y2: v, r: 0.1, n: 1, label: '', color: COLORS[0].value };
    if (type === 'arrow') {
      const [u2, v2] = g.toImage(fx - 0.2 * g.fw, fy + 0.2 * g.fh);
      k.x2 = u2; k.y2 = v2;
    }
    if (type === 'circle') k.r = (0.13 * Math.min(g.fw, g.fh)) / (g.sw * g.s);
    if (type === 'marker') k.n = ed.meta.callouts.filter(c => c.type === 'marker').reduce((m, c) => Math.max(m, c.n), 0) + 1;
    ed.meta.callouts.push(k);
    ed.selectedId = k.id;
    refresh();
  }

  function deleteSelected() {
    if (!ed.meta || !ed.selectedId) return;
    ed.meta.callouts = ed.meta.callouts.filter(k => k.id !== ed.selectedId);
    ed.selectedId = null;
    refresh();
  }

  async function onFileChosen(file) {
    if (!file || !ed) return;
    setStatus('Compressing photo…');
    try {
      const res = await importFile(file);
      if (!ed) return;
      if (res.overTarget) {
        const ok = confirm(
          `This photo could not be compressed to the ${fmtBytes(TARGET_BYTES)} target without making it unclear.\n\n` +
          `It was reduced from ${fmtBytes(res.originalBytes)} to ${fmtBytes(res.bytes)} (${res.width} × ${res.height} px) and will not be compressed further.\n\n` +
          'OK = use it at this size.  Cancel = do not add this photo.'
        );
        if (!ok) { setStatus('Photo not added.', 'warn'); return; }
      }
      const img = await decode(res.blob);     // show exactly what will be stored
      const photo = { id: newId(), blob: res.blob, mime: res.mime, width: res.width, height: res.height, bytes: res.bytes };
      const hadCallouts = ed.meta && ed.meta.callouts.length;
      ed.newPhoto = photo;
      ed.img = img;
      ed.info = photo;
      ed.meta = { photoId: photo.id, crop: defaultCrop(), callouts: ed.meta ? ed.meta.callouts : [] };
      ed.selectedId = null;

      const notes = [`Stored copy: ${res.width} × ${res.height} px, ${fmtBytes(res.bytes)} (original ${fmtBytes(res.originalBytes)} is not kept).`];
      let kind = 'ok';
      if (res.lowRes) { notes.push('This photo is small; it may look soft when printed. Check that the isolation point is identifiable.'); kind = 'warn'; }
      if (hadCallouts) notes.push('Existing callouts were kept — check their positions on the new photo.');
      const projected = (ed.storageBytes || 0) + res.bytes;
      if (projected >= BUDGET_BYTES * 0.8) {
        notes.push(`Photo storage would be about ${fmtBytes(projected)} of the ${fmtBytes(BUDGET_BYTES)} budget.`);
        kind = 'warn';
      }
      setStatus(notes.join(' '), kind);
      refresh();
    } catch (err) {
      setStatus(err.message || 'The photo could not be added.', 'error');
    }
  }

  function close(result) {
    const session = ed;
    ed = null;
    $('photoEditorModal').classList.add('hidden');
    if (session) session.resolve(result);
  }

  function wire() {
    if (wired) return;
    wired = true;
    const canvas = $('photoCanvas');
    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('pointercancel', onPointerUp);
    canvas.addEventListener('wheel', evt => {
      if (!ed || !ed.meta) return;
      evt.preventDefault();
      setZoom(ed.meta.crop.zoom * (evt.deltaY < 0 ? 1.08 : 1 / 1.08));
    }, { passive: false });

    $('photoFileInput').addEventListener('change', evt => {
      const f = evt.target.files && evt.target.files[0];
      evt.target.value = '';
      onFileChosen(f);
    });
    $('photoZoom').addEventListener('input', evt => setZoom(Number(evt.target.value)));
    $('photoRotateLeftBtn').addEventListener('click', () => rotate(-90));
    $('photoRotateRightBtn').addEventListener('click', () => rotate(90));
    $('photoResetCropBtn').addEventListener('click', () => { if (ed.meta) { ed.meta.crop = defaultCrop(); refresh(); } });
    $('addArrowBtn').addEventListener('click', () => addCallout('arrow'));
    $('addCircleBtn').addEventListener('click', () => addCallout('circle'));
    $('addMarkerBtn').addEventListener('click', () => addCallout('marker'));
    $('calloutList').addEventListener('click', evt => {
      const b = evt.target.closest('[data-callout-id]');
      if (!b) return;
      ed.selectedId = b.dataset.calloutId;
      refresh();
    });
    $('calloutLabel').addEventListener('input', evt => { const k = selected(); if (k) { k.label = evt.target.value.slice(0, 40); refresh(); } });
    $('calloutColor').addEventListener('change', evt => { const k = selected(); if (k) { k.color = evt.target.value; refresh(); } });
    $('calloutNumber').addEventListener('input', evt => {
      const k = selected();
      const n = Math.round(Number(evt.target.value));
      if (k && n >= 1 && n <= 99) { k.n = n; refresh(); }
    });
    $('calloutDeleteBtn').addEventListener('click', deleteSelected);
    $('photoRemoveBtn').addEventListener('click', () => {
      if (!ed.meta) return;
      if (!confirm('Remove this photo and its callouts from the card? The printed card will show the placeholder again.')) return;
      ed.meta = null; ed.img = null; ed.info = null; ed.newPhoto = null; ed.selectedId = null;
      setStatus('Photo removed. Choose Apply to confirm.', 'warn');
      refresh();
    });
    $('photoCancelBtn').addEventListener('click', () => close(null));
    $('photoApplyBtn').addEventListener('click', () => {
      if (!ed) return;
      let meta = null;
      if (ed.meta && ed.img) {
        const [cu, cv] = edGeometry().center();
        ed.meta.crop.cx = cu; ed.meta.crop.cy = cv;
        meta = normalizeMeta(ed.meta);
      }
      close({ meta, newPhoto: meta && ed.newPhoto && ed.newPhoto.id === meta.photoId ? ed.newPhoto : null });
    });
    document.addEventListener('keydown', evt => {
      if (!ed || !ed.selectedId) return;
      if (evt.key !== 'Delete' && evt.key !== 'Backspace') return;
      if (evt.target.closest('input, select, textarea')) return;
      evt.preventDefault();
      deleteSelected();
    });
    window.addEventListener('resize', () => { if (ed) { sizeCanvas(); draw(); } });

    const colorSel = $('calloutColor');
    COLORS.forEach(c => {
      const o = document.createElement('option');
      o.value = c.value; o.textContent = c.name;
      colorSel.appendChild(o);
    });
  }

  // Opens the editor. Resolves with null (cancelled) or
  //   { meta, newPhoto }  where meta is the photo metadata to store on the step
  //   (null = photo removed) and newPhoto is a freshly imported asset, if any.
  function openEditor({ title, orientation, meta, img, info, storageBytes }) {
    wire();
    return new Promise(resolve => {
      const m = normalizeMeta(meta);
      ed = {
        resolve, orientation,
        canvas: $('photoCanvas'),
        meta: m && img ? m : null,
        img: m && img ? img : null,
        info: m && img ? info : null,
        newPhoto: null, selectedId: null, drag: null,
        storageBytes: storageBytes || 0
      };
      $('photoEditorTitle').textContent = title || 'Photo Editor';
      $('photoFrameNote').textContent = `${orientation === 'Portrait' ? 'Portrait (3:4)' : 'Landscape (4:3)'} photo area — set by the step’s photo orientation.`;
      setStatus('');
      $('photoEditorModal').classList.remove('hidden');
      sizeCanvas();
      refresh();
    });
  }

  return {
    BUDGET_BYTES, TARGET_BYTES,
    newId, fmtBytes, frameAspect, normalizeMeta, decode, importFile,
    drawComposed, fitFrame, composeCanvas, composeDataURL, composeObjectURL, openEditor
  };
})();
