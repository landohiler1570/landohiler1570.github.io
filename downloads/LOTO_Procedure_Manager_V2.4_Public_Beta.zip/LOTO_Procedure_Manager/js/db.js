const LotoDB = (() => {
  const DB_NAME = 'lotoProcedureManager';
  // v1: `procedures` only.
  // v2: adds `photos` (compressed image Blobs) and `revisions` (saved-version history).
  //     The upgrade only ADDS stores/indexes; existing procedure records are never touched.
  const DB_VERSION = 2;
  const STORE = 'procedures';
  const PHOTOS = 'photos';
  const REVISIONS = 'revisions';

  let dbPromise = null;

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        const tx = request.transaction;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'id' });
        }
        const photos = db.objectStoreNames.contains(PHOTOS)
          ? tx.objectStore(PHOTOS)
          : db.createObjectStore(PHOTOS, { keyPath: 'id' });
        if (!photos.indexNames.contains('procedureId')) photos.createIndex('procedureId', 'procedureId');
        // Lets the storage meter total photo sizes from index keys without reading any Blob.
        if (!photos.indexNames.contains('bytes')) photos.createIndex('bytes', 'bytes');

        const revs = db.objectStoreNames.contains(REVISIONS)
          ? tx.objectStore(REVISIONS)
          : db.createObjectStore(REVISIONS, { keyPath: 'id' });
        if (!revs.indexNames.contains('procedureId')) revs.createIndex('procedureId', 'procedureId');
      };
      request.onblocked = () => reject(new Error('The database upgrade is blocked by another open tab of this app. Close the other tab(s) and reload.'));
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => { db.close(); dbPromise = null; };
        db.onclose = () => { dbPromise = null; };
        resolve(db);
      };
      request.onerror = () => { dbPromise = null; reject(request.error); };
    });
    return dbPromise;
  }

  function reqP(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  // Runs `work(tx)` in one transaction. Everything inside commits together or not at all.
  async function withTx(stores, mode, work) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      let result;
      let tx;
      try {
        tx = db.transaction(stores, mode);
      } catch (err) { reject(err); return; }
      tx.oncomplete = () => resolve(result);
      tx.onabort = () => reject(tx.error || new Error('The save was cancelled by the browser.'));
      tx.onerror = () => {};
      try {
        result = work(tx);
      } catch (err) {
        try { tx.abort(); } catch (e) { /* already finished */ }
        reject(err);
      }
    });
  }

  function deleteByIndex(store, indexName, key, keepIds) {
    const req = store.index(indexName).openKeyCursor(IDBKeyRange.only(key));
    req.onsuccess = () => {
      const cur = req.result;
      if (!cur) return;
      if (!keepIds || !keepIds.has(cur.primaryKey)) store.delete(cur.primaryKey);
      cur.continue();
    };
  }

  /* ---------- procedures ---------- */

  async function getAll() {
    const db = await openDB();
    return (await reqP(db.transaction(STORE, 'readonly').objectStore(STORE).getAll())) || [];
  }

  async function get(id) {
    const db = await openDB();
    return (await reqP(db.transaction(STORE, 'readonly').objectStore(STORE).get(id))) || null;
  }

  async function put(record) {
    await withTx([STORE], 'readwrite', tx => { tx.objectStore(STORE).put(record); });
    return record;
  }

  // Saves a procedure together with its new photos and revision entries.
  // Photos of this procedure that are no longer referenced (not in keepPhotoIds) are removed.
  // All of it is one transaction: on a quota or write error nothing changes.
  async function saveProcedure({ record, newPhotos = [], keepPhotoIds = null, revisions = [] }) {
    await withTx([STORE, PHOTOS, REVISIONS], 'readwrite', tx => {
      const photos = tx.objectStore(PHOTOS);
      tx.objectStore(STORE).put(record);
      newPhotos.forEach(ph => photos.put(ph));
      if (keepPhotoIds) deleteByIndex(photos, 'procedureId', record.id, keepPhotoIds);
      revisions.forEach(r => tx.objectStore(REVISIONS).put(r));
    });
    return record;
  }

  // Deleting a procedure also removes its photos and revision history.
  async function remove(id) {
    await withTx([STORE, PHOTOS, REVISIONS], 'readwrite', tx => {
      tx.objectStore(STORE).delete(id);
      deleteByIndex(tx.objectStore(PHOTOS), 'procedureId', id);
      deleteByIndex(tx.objectStore(REVISIONS), 'procedureId', id);
    });
  }

  /* ---------- photos ---------- */

  async function getPhoto(id) {
    const db = await openDB();
    return (await reqP(db.transaction(PHOTOS, 'readonly').objectStore(PHOTOS).get(id))) || null;
  }

  async function getPhotosForProcedure(procedureId) {
    const db = await openDB();
    return (await reqP(db.transaction(PHOTOS, 'readonly').objectStore(PHOTOS).index('procedureId').getAll(procedureId))) || [];
  }

  async function getAllPhotoKeys() {
    const db = await openDB();
    return (await reqP(db.transaction(PHOTOS, 'readonly').objectStore(PHOTOS).getAllKeys())) || [];
  }

  // Count and total size of stored photos, read from index keys only (no Blob is loaded).
  async function photoStats() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const out = { count: 0, bytes: 0 };
      const req = db.transaction(PHOTOS, 'readonly').objectStore(PHOTOS).index('bytes').openKeyCursor();
      req.onsuccess = () => {
        const cur = req.result;
        if (!cur) { resolve(out); return; }
        out.count += 1;
        out.bytes += Number(cur.key) || 0;
        cur.continue();
      };
      req.onerror = () => reject(req.error);
    });
  }

  /* ---------- revisions ---------- */

  async function getRevisions(procedureId) {
    const db = await openDB();
    const list = (await reqP(db.transaction(REVISIONS, 'readonly').objectStore(REVISIONS).index('procedureId').getAll(procedureId))) || [];
    return list.sort((a, b) => (a.rev || 0) - (b.rev || 0));
  }

  async function getAllRevisions() {
    const db = await openDB();
    return (await reqP(db.transaction(REVISIONS, 'readonly').objectStore(REVISIONS).getAll())) || [];
  }

  /* ---------- restore ---------- */

  // Full-backup restore: replaces procedures, photos and revisions in one transaction.
  async function restoreAll({ procedures, photos = [], revisions = [] }) {
    await withTx([STORE, PHOTOS, REVISIONS], 'readwrite', tx => {
      const ps = tx.objectStore(STORE), ph = tx.objectStore(PHOTOS), rv = tx.objectStore(REVISIONS);
      ps.clear(); ph.clear(); rv.clear();
      procedures.forEach(r => ps.put(r));
      photos.forEach(r => ph.put(r));
      revisions.forEach(r => rv.put(r));
    });
  }

  // Legacy JSON restore (procedures only). Photos still referenced by the restored
  // procedures are kept; unreferenced photos and orphaned revision history are removed.
  async function replaceAll(records) {
    const procIds = new Set(records.map(r => r.id));
    const keep = new Set();
    records.forEach(r => (r.steps || []).forEach(s => {
      if (s.photo && s.photo.photoId) keep.add(s.photo.photoId);
      if (s.verificationPhoto && s.verificationPhoto.photoId) keep.add(s.verificationPhoto.photoId);
    }));
    await withTx([STORE, PHOTOS, REVISIONS], 'readwrite', tx => {
      const store = tx.objectStore(STORE);
      store.clear();
      for (const r of records) store.put(r);

      const ph = tx.objectStore(PHOTOS);
      const pReq = ph.openKeyCursor();
      pReq.onsuccess = () => {
        const cur = pReq.result;
        if (!cur) return;
        if (!keep.has(cur.primaryKey)) ph.delete(cur.primaryKey);
        cur.continue();
      };

      const rv = tx.objectStore(REVISIONS);
      const rReq = rv.index('procedureId').openKeyCursor();
      rReq.onsuccess = () => {
        const cur = rReq.result;
        if (!cur) return;
        if (!procIds.has(cur.key)) rv.delete(cur.primaryKey);
        cur.continue();
      };
    });
  }

  return {
    getAll, get, put, remove, replaceAll,
    saveProcedure, getPhoto, getPhotosForProcedure, getAllPhotoKeys, photoStats,
    getRevisions, getAllRevisions, restoreAll
  };
})();
