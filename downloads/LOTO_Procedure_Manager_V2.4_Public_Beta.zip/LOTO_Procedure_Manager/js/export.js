const LotoExport = (() => {
  const APP_VERSION = '2.4';

  const STANDARD_LOCKOUT = [
    'Verbally notify affected personnel of shutdown.',
    'Properly shut down the machine.',
    'Identify all applicable energy sources.',
    'Isolate each energy source using the correct device.',
    'Apply lock(s) and tag(s) to each isolation device.',
    'Release or restrain any stored energy.',
    'Verify isolation and zero-energy state (attempt start / test / observe as appropriate).'
  ];

  const STANDARD_REENERGIZE = [
    'Ensure all tools and items have been removed.',
    'Confirm that all employees are safely located.',
    'Verify controls are neutral; confirm guarding and panels are returned/closed.',
    'Remove lockout devices and re-energize equipment.',
    'Verbally notify affected employees that servicing is completed.'
  ];

  const VERIFICATION_TEXT = {
    'Meter / Try-Out': 'Attempt normal start and confirm the equipment does not energize; use a meter where applicable.',
    'Try-Out': 'Attempt normal start and confirm the equipment does not energize or move.',
    'Bleed / Zero Pressure': 'Bleed stored pressure and confirm pressure is at zero.',
    'Lower / Block / Restrain': 'Lower, block, or restrain the load and confirm no stored movement remains.',
    'Release / Restrain': 'Release or restrain stored mechanical energy and confirm no movement.',
    'Safe Temperature': 'Allow the system to reach a safe temperature and verify before work begins.',
    'Drain / Isolate': 'Drain or isolate the source and verify no flow or residual pressure remains.',
    'Visual / Physical Check': 'Confirm the energy source is isolated and no hazardous energy remains.'
  };

  function esc(v='') {
    return String(v)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;');
  }

  function fmtDate(v) {
    if (!v) return '';
    const d = new Date(v + 'T00:00:00');
    if (Number.isNaN(d.getTime())) return v;
    return d.toLocaleDateString('en-US', { year:'numeric', month:'2-digit', day:'2-digit' });
  }

  function getVerificationMethod(s) {
    if (s.verificationMethod && VERIFICATION_TEXT[s.verificationMethod]) return s.verificationMethod;

    const defaults = {
      'Electrical': 'Meter / Try-Out',
      'Control Circuit': 'Try-Out',
      'Pneumatic': 'Bleed / Zero Pressure',
      'Pressure': 'Bleed / Zero Pressure',
      'Hydraulic': 'Bleed / Zero Pressure',
      'Gravity': 'Lower / Block / Restrain',
      'Mechanical': 'Release / Restrain',
      'Stored Energy': 'Release / Restrain',
      'Thermal': 'Safe Temperature',
      'Chemical': 'Drain / Isolate',
      'Other': 'Visual / Physical Check'
    };

    const old = String(s.verification || s.verificationMethod || '').toLowerCase();
    if (old.includes('pressure') || old.includes('gauge') || old.includes('bleed')) return 'Bleed / Zero Pressure';
    if (old.includes('meter') || old.includes('voltage')) return 'Meter / Try-Out';
    if (old.includes('lower') || old.includes('gravity') || old.includes('block')) return 'Lower / Block / Restrain';
    if (old.includes('release') || old.includes('restrain')) return 'Release / Restrain';
    if (old.includes('temperature') || old.includes('thermal')) return 'Safe Temperature';
    if (old.includes('drain') || old.includes('chemical')) return 'Drain / Isolate';
    if (old.includes('try') || old.includes('start')) return 'Try-Out';

    return defaults[s.energyType] || 'Visual / Physical Check';
  }

  function getVerificationText(s) {
    return VERIFICATION_TEXT[getVerificationMethod(s)] || '';
  }

  function buildCardPages(steps) {
    const pages = [];
    let current = [];

    (steps || []).forEach((step, idx) => {
      const group = [{ kind: 'lock', step, stepIndex: idx }];
      if (step.verificationPhotoMode === 'Photo + Message') {
        group.push({ kind: 'verify', step, stepIndex: idx });
      }

      if (current.length && current.length + group.length > 2) {
        pages.push(current);
        current = [];
      }

      if (!current.length && group.length === 2) {
        pages.push(group);
        return;
      }

      current.push(...group);

      if (current.length === 2) {
        pages.push(current);
        current = [];
      }
    });

    if (current.length) pages.push(current);
    if (!pages.length) pages.push([]);
    return pages;
  }

  function cardTitle(card) {
    return card.kind === 'verify'
      ? `VERIFY — ${card.step.stepId || `STEP ${card.stepIndex + 1}`}`
      : `${card.step.stepId || `STEP ${card.stepIndex + 1}`}${card.step.energyType ? ' — ' + String(card.step.energyType).toUpperCase() : ''}`;
  }

  // Photo assets are passed in by the caller, keyed "<stepIndex>:<lock|verify>".
  //   assets.urls[key]   -> URL of the composed photo (crop + callouts) for HTML output
  //   assets.images[key] -> { img, meta, orientation } for the canvas (PNG) renderer
  // A card without an attached photo keeps its text placeholder.
  function photoKey(card) {
    return `${card.stepIndex}:${card.kind}`;
  }

  function photoSpaceHTML(url, label) {
    return url
      ? `<div class="card-photo-space has-photo"><img class="card-photo" src="${esc(url)}" alt="${esc(label)}" /></div>`
      : `<div class="card-photo-space">
          <div class="card-photo-placeholder">${esc(label)}</div>
        </div>`;
  }

  function lockCardHTML(step, idx, url) {
    const meta = `${esc(step.magnitude || '—')} | ${esc(step.device || '—')}`;
    return `
      <section class="sheet-card lock-card">
        <h3>${esc(cardTitle({ kind:'lock', step, stepIndex: idx }))}</h3>
        ${photoSpaceHTML(url, step.photoLabel || `PHOTO ${idx+1}`)}
        <div class="card-bottom-text">
          <div class="card-meta-line">${meta}</div>
          <div class="card-section-label">LOCK HERE:</div>
          <div class="card-section-text">${esc(step.location || '—')}</div>
          ${step.verificationPhotoMode === 'Photo + Message' ? '' : `
            <div class="card-section-label verify-label">VERIFY:</div>
            <div class="card-verify-method">${esc(getVerificationMethod(step))}</div>
            <div class="card-verify-text">${esc(getVerificationText(step))}</div>
          `}
        </div>
      </section>`;
  }

  function verifyCardHTML(step, idx, url) {
    return `
      <section class="sheet-card verify-card">
        <h3>${esc(cardTitle({ kind:'verify', step, stepIndex: idx }))}</h3>
        ${photoSpaceHTML(url, step.verificationPhotoLabel || `VERIFY PHOTO ${idx+1}`)}
        <div class="card-bottom-text">
          <div class="card-section-label">METHOD:</div>
          <div class="card-verify-method">${esc(getVerificationMethod(step))}</div>
          <div class="card-verify-text">${esc(getVerificationText(step))}</div>
        </div>
      </section>`;
  }

  function cardHTML(card, urls) {
    const url = (urls && urls[photoKey(card)]) || '';
    return card.kind === 'verify'
      ? verifyCardHTML(card.step, card.stepIndex, url)
      : lockCardHTML(card.step, card.stepIndex, url);
  }

  function fullHeaderHTML(p) {
    return `
      <div class="sheet-title">LOCKOUT / TAGOUT INSTRUCTIONS</div>
      <div class="sheet-grid">
        <div class="sheet-cell"><span class="sheet-label">Area</span>${esc(p.area)}</div>
        <div class="sheet-cell"><span class="sheet-label">Equipment</span>${esc(p.equipmentName)}</div>
        <div class="sheet-cell"><span class="sheet-label">LOTO ID</span>${esc(p.lotoId)}</div>
        <div class="sheet-cell"><span class="sheet-label">Procedure Type</span>${esc(p.procedureType)}</div>
        <div class="sheet-cell"><span class="sheet-label">Born / Original Issue</span>${fmtDate(p.bornDate)}</div>
        <div class="sheet-cell"><span class="sheet-label">Last Annual Inspection</span>${fmtDate(p.annualInspectionDate)}</div>
        <div class="sheet-cell"><span class="sheet-label">Last Revision</span>${fmtDate(p.revisionDate)}</div>
        <div class="sheet-cell"><span class="sheet-label">Reviewed By</span>${esc(p.reviewedBy)}</div>
        <div class="sheet-cell full"><span class="sheet-label">Status / Special Notes</span>${esc(p.lifecycleStatus || 'Active')} — ${esc(p.specialNotes || '—')}</div>
      </div>

      <div class="sheet-section-title">Lockout Application Process</div>
      <div class="sheet-standard sheet-standard-columns">
        <ol>${STANDARD_LOCKOUT.map(x => `<li>${esc(x)}</li>`).join('')}</ol>
      </div>`;
  }

  function continuationHeaderHTML(p, pageNum, totalPages) {
    return `
      <div class="continuation-header">
        <div>
          <span class="sheet-label">LOTO CONTINUATION</span>
          <strong>${esc(p.lotoId)} — ${esc(p.equipmentName)}</strong>
        </div>
        <div class="continuation-meta">
          <span>${esc(p.area)}</span>
          <span>Page ${pageNum} of ${totalPages}</span>
        </div>
      </div>`;
  }

  function closingHTML() {
    return `
      <div class="sheet-closing">
        <div class="sheet-section-title">Verify Zero Energy</div>
        <div class="sheet-standard">
          Attempt to start equipment using normal controls. Confirm zero voltage, zero pressure, and no movement as applicable.
        </div>

        <div class="sheet-section-title">Re-Energization Process</div>
        <div class="sheet-standard sheet-standard-columns reenergization-columns">
          <ol>${STANDARD_REENERGIZE.map(x => `<li>${esc(x)}</li>`).join('')}</ol>
        </div>

        <div class="sheet-footer"><b>AUTHORIZED PERSONNEL ONLY — FULL LOCKOUT.</b> All applicable energy sources must be isolated and verified before work begins.</div>
      </div>`;
  }

  function singlePageHTML(p, pageCards, pageIndex, totalPages, urls) {
    const pageNum = pageIndex + 1;
    const isFirst = pageIndex === 0;
    const isLast = pageIndex === totalPages - 1;
    const isMultiPage = totalPages > 1;
    return `
      <article class="loto-sheet ${isFirst ? 'first-page' : 'continuation-page'} ${isLast ? 'final-page' : ''} ${isMultiPage ? 'multi-page-procedure' : ''}">
        ${isFirst ? fullHeaderHTML(p) : continuationHeaderHTML(p, pageNum, totalPages)}
        <div class="sheet-section-title">Isolation / Lockout Steps</div>
        <div class="sheet-cards ${pageCards.length === 1 ? 'one-card' : 'two-card'}">
          ${pageCards.map(c => cardHTML(c, urls)).join('')}
        </div>
        ${isLast ? closingHTML() : ''}
        <div class="page-number">Page ${pageNum} of ${totalPages}</div>
      </article>`;
  }

  function sheetHTML(p, assets) {
    const pages = buildCardPages(p.steps || []);
    const urls = assets && assets.urls;
    return pages.map((cards, i) => singlePageHTML(p, cards, i, pages.length, urls)).join('');
  }

  function csvCell(v) {
    const s = String(v ?? '');
    return `"${s.replaceAll('"','""')}"`;
  }

  function downloadBlob(content, filename, type) {
    const blob = content instanceof Blob ? content : new Blob([content], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  function exportRegisterCSV(records, statusFn) {
    const headers = ['LOTO ID','Area','Equipment','Born Date','Last Annual Inspection','Next Due','Inspection Status','Procedure Status','Step Count','Last Revision','Reviewed By'];
    const rows = records.map(p => {
      const stat = statusFn(p);
      return [
        p.lotoId,p.area,p.equipmentName,p.bornDate,p.annualInspectionDate,stat.nextDue,stat.label,p.lifecycleStatus || 'Active',
        (p.steps||[]).length,p.revisionDate,p.reviewedBy
      ];
    });
    const csv = [headers, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n');
    downloadBlob(csv, 'LOTO_Procedure_Register.csv', 'text/csv;charset=utf-8');
  }

  function exportStepsCSV(records) {
    const headers = ['LOTO ID','Area','Equipment','Step ID','Energy Type','Magnitude','Device','Lock Location','Verification Method','Verification Text','Verification Photo Card','Verification Photo Label','Lock Photo Label','Lock Photo Attached','Verification Photo Attached'];
    const rows = [];
    records.forEach(p => (p.steps||[]).forEach(s => rows.push([
      p.lotoId,p.area,p.equipmentName,s.stepId,s.energyType,s.magnitude,s.device,s.location,getVerificationMethod(s),getVerificationText(s),
      s.verificationPhotoMode === 'Photo + Message' ? 'Yes' : 'No',
      s.verificationPhotoLabel || '',s.photoLabel || '',
      s.photo && s.photo.photoId ? 'Yes' : 'No',
      s.verificationPhoto && s.verificationPhoto.photoId ? 'Yes' : 'No'
    ])));
    const csv = [headers, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n');
    downloadBlob(csv, 'LOTO_Isolation_Steps.csv', 'text/csv;charset=utf-8');
  }

  // Same shape as the V2.x "Backup JSON" file. It is written as procedures.json inside the
  // full backup ZIP, so the procedure data stays readable by the legacy restore path.
  function proceduresPayload(records) {
    return JSON.stringify({
      app: 'LOTO Procedure Manager',
      version: APP_VERSION,
      exportedAt: new Date().toISOString(),
      procedures: records
    }, null, 2);
  }

  function safeName(p) {
    return `${p.lotoId || 'LOTO'}_${p.equipmentName || 'Procedure'}`.replace(/[^\w-]+/g,'_');
  }

  function svgPageCSS() {
    return `
      *{box-sizing:border-box}
      .loto-sheet{width:780px;height:1020px;background:#fff;color:#000;padding:24px;border:2px solid #000;font-family:Arial,Helvetica,sans-serif;position:relative;overflow:hidden}
      .sheet-title{text-align:center;font-weight:800;font-size:23px;border:2px solid #000;padding:7px}
      .sheet-grid{display:grid;grid-template-columns:1fr 1fr;border-left:1px solid #000;border-top:1px solid #000}
      .sheet-cell{border-right:1px solid #000;border-bottom:1px solid #000;padding:5px 7px;min-height:35px;font-size:12px}
      .sheet-cell.full{grid-column:1/-1}.sheet-label{font-size:9px;font-weight:800;text-transform:uppercase;display:block;margin-bottom:1px}
      .sheet-section-title{margin-top:7px;border:1px solid #000;background:#ececec;padding:4px 6px;font-weight:800;font-size:11px;text-transform:uppercase}
      .sheet-standard{border:1px solid #000;border-top:none;padding:5px 7px;font-size:9.5px;line-height:1.25}
      .sheet-standard-columns ol{columns:2;column-gap:26px;margin:0;padding-left:18px}.sheet-standard-columns li{break-inside:avoid;margin-bottom:2px}
      .sheet-cards{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:7px}
      .sheet-cards.one-card{grid-template-columns:1fr}
      .sheet-card{border:1.5px solid #000;padding:7px;min-height:392px;display:flex;flex-direction:column}
      .loto-sheet.multi-page-procedure{display:flex;flex-direction:column}
      .loto-sheet.multi-page-procedure .sheet-cards{flex:1 1 auto;min-height:0}
      .loto-sheet.multi-page-procedure .sheet-card{height:100%;min-height:0}
      .loto-sheet.multi-page-procedure .sheet-closing{flex:0 0 auto}
      .card-bottom-text{margin-top:auto;padding-top:6px}
      .sheet-card h3{margin:0 0 5px;font-size:17px}
      .card-photo-space{flex:1 1 auto;min-height:215px;display:flex;align-items:center;justify-content:center;text-align:center}
      .card-photo-placeholder{font-size:17px;font-weight:800}
      .card-photo-space.has-photo{position:relative}
      .card-photo{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:contain;display:block}
      .card-meta-line{font-size:15px;font-weight:800;margin-top:4px}
      .card-section-label{font-size:15px;font-weight:800;margin-top:6px}
      .verify-label{margin-top:8px}
      .card-section-text,.card-verify-text{font-size:15px;line-height:1.24;margin-top:2px}
      .card-verify-method{font-size:15px;font-weight:800;margin-top:2px}
      .continuation-header{border:2px solid #000;padding:8px 10px;display:flex;justify-content:space-between;align-items:center;font-size:12px}.continuation-meta{text-align:right;display:grid;gap:2px}
      .sheet-closing{margin-top:7px}.sheet-footer{margin-top:7px;border:1px solid #000;padding:5px;font-size:8.5px;line-height:1.2}.page-number{position:absolute;right:24px;bottom:9px;font-size:8px}
    `;
  }

  function downloadSVG(p, assets) {
    const pages = buildCardPages(p.steps || []);
    // SVG files must be self-contained: embed each composed photo as a data URL.
    const urls = {};
    Object.entries((assets && assets.images) || {}).forEach(([key, a]) => {
      urls[key] = LotoPhotos.composeDataURL(a.img, a.meta, a.orientation, 1500);
    });
    pages.forEach((pageCards, i) => {
      setTimeout(() => {
        const html = singlePageHTML(p, pageCards, i, pages.length, urls);
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="816" height="1056" viewBox="0 0 816 1056">
          <rect width="816" height="1056" fill="white"/>
          <foreignObject x="18" y="18" width="780" height="1020">
            <div xmlns="http://www.w3.org/1999/xhtml">
              <style>${svgPageCSS()}</style>
              ${html}
            </div>
          </foreignObject>
        </svg>`;
        downloadBlob(svg, `${safeName(p)}_Page_${i+1}_of_${pages.length}.svg`, 'image/svg+xml');
      }, i * 250);
    });
  }

  async function downloadPNG(p, assets) {
    const pages = buildCardPages(p.steps || []);
    const images = (assets && assets.images) || {};
    for (let i = 0; i < pages.length; i++) {
      const canvas = renderPNGPage(p, pages[i], i, pages.length, images);
      const blob = await new Promise((resolve, reject) => {
        canvas.toBlob(b => b ? resolve(b) : reject(new Error('PNG export failed.')), 'image/png');
      });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `${safeName(p)}_Page_${i+1}_of_${pages.length}_8.5x11.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      if (i < pages.length - 1) await new Promise(r => setTimeout(r, 300));
    }
  }

  function renderPNGPage(p, cards, pageIndex, totalPages, images = {}) {
    const PAGE_W = 2550;
    const PAGE_H = 3300;
    const M = 100;
    const W = PAGE_W - M * 2;
    const canvas = document.createElement('canvas');
    canvas.width = PAGE_W;
    canvas.height = PAGE_H;
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, PAGE_W, PAGE_H);
    ctx.fillStyle = '#000';
    ctx.strokeStyle = '#000';
    ctx.textBaseline = 'top';

    let y = M;

    function font(size, weight='400') {
      ctx.font = `${weight} ${size}px Arial, Helvetica, sans-serif`;
    }

    function box(x, yy, w, h, lw=3, fill=null) {
      if (fill) {
        ctx.fillStyle = fill;
        ctx.fillRect(x, yy, w, h);
        ctx.fillStyle = '#000';
      }
      ctx.lineWidth = lw;
      ctx.strokeRect(x, yy, w, h);
    }

    function wrap(text, maxWidth, size, weight='400') {
      font(size, weight);
      const words = String(text || '').split(/\s+/).filter(Boolean);
      if (!words.length) return [''];
      const lines = [];
      let cur = words[0];
      for (let i = 1; i < words.length; i++) {
        const test = cur + ' ' + words[i];
        if (ctx.measureText(test).width <= maxWidth) cur = test;
        else { lines.push(cur); cur = words[i]; }
      }
      lines.push(cur);
      return lines;
    }

    function drawWrap(text, x, yy, maxWidth, size, weight='400', lh=null) {
      const lineH = lh || Math.round(size * 1.22);
      const lines = wrap(text, maxWidth, size, weight);
      font(size, weight);
      lines.forEach((ln, i) => ctx.fillText(ln, x, yy + i * lineH));
      return lines.length * lineH;
    }

    function center(text, x, yy, w, size, weight='700') {
      font(size, weight);
      ctx.textAlign = 'center';
      ctx.fillText(String(text || ''), x + w / 2, yy);
      ctx.textAlign = 'left';
    }

    function section(title) {
      const h = 68;
      box(M, y, W, h, 3, '#ececec');
      font(34, '800');
      ctx.fillText(title.toUpperCase(), M + 18, y + 16);
      y += h;
    }

    function field(x, yy, w, h, label, value) {
      box(x, yy, w, h, 3);
      font(26, '800');
      ctx.fillText(label.toUpperCase(), x + 15, yy + 10);
      drawWrap(value || '—', x + 15, yy + 44, w - 30, 34, '400', 40);
    }

    function drawTwoColumns(items, textSize=26) {
      const pad = 24, gap = 44;
      const colW = (W - pad * 2 - gap) / 2;
      const split = Math.ceil(items.length / 2);
      const left = items.slice(0, split);
      const right = items.slice(split);
      const lh = Math.round(textSize * 1.24);

      function height(list, start) {
        let h = 0;
        list.forEach((item, idx) => h += wrap(`${start + idx}. ${item}`, colW, textSize).length * lh + 4);
        return h;
      }

      const h = Math.max(height(left, 1), height(right, split + 1)) + 30;
      box(M, y, W, h, 3);
      let ly = y + 14, ry = y + 14;
      left.forEach((item, idx) => ly += drawWrap(`${idx + 1}. ${item}`, M + pad, ly, colW, textSize, '400', lh) + 4);
      right.forEach((item, idx) => ry += drawWrap(`${split + idx + 1}. ${item}`, M + pad + colW + gap, ry, colW, textSize, '400', lh) + 4);
      y += h;
    }

    const isFirst = pageIndex === 0;
    const isLast = pageIndex === totalPages - 1;

    if (isFirst) {
      box(M, y, W, 105, 5);
      center('LOCKOUT / TAGOUT INSTRUCTIONS', M, y + 22, W, 54, '800');
      y += 105;

      const half = W / 2, rh = 105;
      field(M, y, half, rh, 'Area', p.area); field(M + half, y, half, rh, 'Equipment', p.equipmentName); y += rh;
      field(M, y, half, rh, 'LOTO ID', p.lotoId); field(M + half, y, half, rh, 'Procedure Type', p.procedureType); y += rh;
      field(M, y, half, rh, 'Born / Original Issue', fmtDate(p.bornDate)); field(M + half, y, half, rh, 'Last Annual Inspection', fmtDate(p.annualInspectionDate)); y += rh;
      field(M, y, half, rh, 'Last Revision', fmtDate(p.revisionDate)); field(M + half, y, half, rh, 'Reviewed By', p.reviewedBy); y += rh;

      const noteText = `${p.lifecycleStatus || 'Active'} — ${p.specialNotes || '—'}`;
      const noteLines = wrap(noteText, W - 30, 26);
      const nh = Math.max(100, 52 + noteLines.length * 32);
      box(M, y, W, nh, 3);
      font(26, '800'); ctx.fillText('STATUS / SPECIAL NOTES', M + 15, y + 10);
      drawWrap(noteText, M + 15, y + 44, W - 30, 30, '400', 36);
      y += nh + 16;

      section('Lockout Application Process');
      drawTwoColumns(STANDARD_LOCKOUT, 29);
      y += 16;
    } else {
      box(M, y, W, 112, 5);
      font(31, '800'); ctx.fillText('LOTO CONTINUATION', M + 18, y + 14);
      font(38, '800'); ctx.fillText(`${p.lotoId || ''} — ${p.equipmentName || ''}`, M + 18, y + 47);
      font(29, '400'); ctx.textAlign = 'right';
      ctx.fillText(`${p.area || ''}     Page ${pageIndex + 1} of ${totalPages}`, PAGE_W - M - 18, y + 40);
      ctx.textAlign = 'left';
      y += 112 + 16;
    }

    section('Isolation / Lockout Steps');
    y += 16;

    const twoCol = cards.length === 2;
    const gap = 28;
    const cardW = twoCol ? (W - gap) / 2 : W;
    const cardY = y;
    const isMultiPage = totalPages > 1;

    // Preserve the current card size for single-page procedures.
    // Multi-page procedures stretch cards vertically to consume dead space.
    // The final page reserves room for Verify Zero Energy / Re-Energization.
    const cardH = isMultiPage
      ? Math.max(1410, PAGE_H - cardY - (isLast ? 720 : 160))
      : 1410;

    // Draws the attached photo (same composer as the preview) fitted and centred in the
    // open photo area; returns false when the card has no photo so the placeholder is used.
    function drawCardPhoto(card, x, top, bottom) {
      const a = images[photoKey(card)];
      if (!a) return false;
      const areaH = bottom - top;
      if (areaH < 40) return false;
      const f = LotoPhotos.fitFrame(x + 18, top, cardW - 36, areaH, a.orientation);
      LotoPhotos.drawComposed(ctx, a.img, a.meta, f.x, f.y, f.w, f.h);
      ctx.fillStyle = '#000';
      ctx.strokeStyle = '#000';
      ctx.textBaseline = 'top';
      ctx.textAlign = 'left';
      return true;
    }

    function drawLockCard(card, x) {
      const s = card.step;
      box(x, cardY, cardW, cardH, 4);
      font(52, '800');
      ctx.fillText(cardTitle(card), x + 18, cardY + 18);

      const textW = cardW - 36;
      const hasSeparateVerifyCard = s.verificationPhotoMode === 'Photo + Message';

      // Estimate the bottom text block first so it can be pinned to the bottom.
      const locLines = wrap(s.location || '—', textW, 46);
      const verifyLines = wrap(getVerificationText(s), textW, 46);
      const bottomTextH = hasSeparateVerifyCard
        ? (
            60 +                         // magnitude/device
            52 + locLines.length * 56   // LOCK HERE
          )
        : (
            60 +                         // magnitude/device
            52 + locLines.length * 56 + // LOCK HERE
            16 +
            52 + 56 + verifyLines.length * 56 // VERIFY
          );

      const bottomPad = 24;
      let dy = cardY + cardH - bottomPad - bottomTextH;

      // Photo placeholder is centered in all remaining open space above the text.
      const photoTop = cardY + 82;
      const photoBottom = dy - 20;
      const photoCenterY = photoTop + Math.max(0, photoBottom - photoTop) / 2;
      if (!drawCardPhoto(card, x, photoTop, photoBottom)) {
        center(s.photoLabel || `PHOTO ${card.stepIndex + 1}`, x, photoCenterY - 18, cardW, 52, '800');
      }

      const metaParts = [s.magnitude || '—', s.device || '—'];
      font(48, '800');
      ctx.fillText(metaParts.join(' | '), x + 18, dy);
      dy += 60;

      font(44, '800');
      ctx.fillText('LOCK HERE:', x + 18, dy);
      dy += 52;
      dy += drawWrap(s.location || '—', x + 18, dy, textW, 46, '400', 56);

      if (!hasSeparateVerifyCard) {
        dy += 16;
        font(44, '800');
        ctx.fillText('VERIFY:', x + 18, dy);
        dy += 52;
        font(46, '800');
        ctx.fillText(getVerificationMethod(s), x + 18, dy);
        dy += 56;
        drawWrap(getVerificationText(s), x + 18, dy, textW, 46, '400', 56);
      }
    }

    function drawVerifyCard(card, x) {
      const s = card.step;
      box(x, cardY, cardW, cardH, 4);
      font(52, '800');
      ctx.fillText(cardTitle(card), x + 18, cardY + 18);

      const textW = cardW - 36;
      const verifyLines = wrap(getVerificationText(s), textW, 46);
      const bottomTextH = 52 + 56 + verifyLines.length * 56;
      const bottomPad = 24;
      let dy = cardY + cardH - bottomPad - bottomTextH;

      const photoTop = cardY + 108;
      const photoBottom = dy - 20;
      const photoCenterY = photoTop + Math.max(0, photoBottom - photoTop) / 2;
      if (!drawCardPhoto(card, x, photoTop, photoBottom)) {
        center(s.verificationPhotoLabel || `VERIFY PHOTO ${card.stepIndex + 1}`, x, photoCenterY - 22, cardW, 50, '800');
      }

      font(44, '800');
      ctx.fillText('METHOD:', x + 18, dy);
      dy += 52;
      font(46, '800');
      ctx.fillText(getVerificationMethod(s), x + 18, dy);
      dy += 56;

      drawWrap(getVerificationText(s), x + 18, dy, textW, 46, '400', 56);
    }

    cards.forEach((card, i) => {
      const x = M + (twoCol ? i * (cardW + gap) : 0);
      if (card.kind === 'verify') drawVerifyCard(card, x);
      else drawLockCard(card, x);
    });

    y = cardY + cardH + 16;

    if (isLast) {
      section('Verify Zero Energy');
      const vText = 'Attempt to start equipment using normal controls. Confirm zero voltage, zero pressure, and no movement as applicable.';
      const vh = 82;
      box(M, y, W, vh, 3);
      drawWrap(vText, M + 16, y + 18, W - 32, 30, '400', 36);
      y += vh + 14;

      section('Re-Energization Process');
      drawTwoColumns(STANDARD_REENERGIZE, 28);
      y += 14;

      const footer = 'AUTHORIZED PERSONNEL ONLY — FULL LOCKOUT. All applicable energy sources must be isolated and verified before work begins.';
      const fh = 74;
      box(M, y, W, fh, 3);
      drawWrap(footer, M + 15, y + 18, W - 30, 28, '800', 34);
    }

    font(26, '400');
    ctx.textAlign = 'right';
    ctx.fillText(`Page ${pageIndex + 1} of ${totalPages}`, PAGE_W - M, PAGE_H - 55);
    ctx.textAlign = 'left';

    return canvas;
  }

  return {
    APP_VERSION, sheetHTML, exportRegisterCSV, exportStepsCSV, proceduresPayload,
    downloadSVG, downloadPNG, renderPNGPage, buildCardPages, downloadBlob,
    getVerificationMethod, getVerificationText, VERIFICATION_TEXT
  };
})();