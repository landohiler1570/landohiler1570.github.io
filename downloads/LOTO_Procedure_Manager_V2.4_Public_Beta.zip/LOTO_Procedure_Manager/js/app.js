const state = {
  records: [],
  editingId: null,
  previewing: null,
  previewAssets: null,
  previewReturnsToHistory: null,
  sort: { field: 'area', dir: 1 },
  photoStats: { count: 0, bytes: 0 }
};

// Photo state for the procedure currently open in the drawer. Nothing here is written to
// the database until Save Procedure succeeds.
//   extras : step uid -> { photo, verificationPhoto }   (crop + callout metadata)
//   pending: photoId  -> newly imported/duplicated photo asset, not yet saved
//   saved  : photoId  -> photo record already stored for this procedure
//   images : photoId  -> Promise of the decoded image (for thumbnails and the editor)
const draft = { extras: new Map(), pending: new Map(), saved: new Map(), images: new Map(), thumbRun: 0 };

const PHOTO_SLOTS = [
  { slot: 'lock', key: 'photo', orientationField: 'photoOrientation' },
  { slot: 'verify', key: 'verificationPhoto', orientationField: 'verificationPhotoOrientation' }
];

const ENERGY_TYPES = [
  { value: 'Electrical', prefix: 'E' },
  { value: 'Control Circuit', prefix: 'CC' },
  { value: 'Gravity', prefix: 'G' },
  { value: 'Hydraulic', prefix: 'H' },
  { value: 'Pneumatic', prefix: 'P' },
  { value: 'Mechanical', prefix: 'M' },
  { value: 'Thermal', prefix: 'T' },
  { value: 'Chemical', prefix: 'C' },
  { value: 'Pressure', prefix: 'PR' },
  { value: 'Stored Energy', prefix: 'SE' },
  { value: 'Other', prefix: 'O' }
];

const VERIFICATION_METHODS = [
  { value: 'Meter / Try-Out', text: 'Attempt normal start and confirm the equipment does not energize; use a meter where applicable.' },
  { value: 'Try-Out', text: 'Attempt normal start and confirm the equipment does not energize or move.' },
  { value: 'Bleed / Zero Pressure', text: 'Bleed stored pressure and confirm pressure is at zero.' },
  { value: 'Lower / Block / Restrain', text: 'Lower, block, or restrain the load and confirm no stored movement remains.' },
  { value: 'Release / Restrain', text: 'Release or restrain stored mechanical energy and confirm no movement.' },
  { value: 'Safe Temperature', text: 'Allow the system to reach a safe temperature and verify before work begins.' },
  { value: 'Drain / Isolate', text: 'Drain or isolate the source and verify no flow or residual pressure remains.' },
  { value: 'Visual / Physical Check', text: 'Confirm the energy source is isolated and no hazardous energy remains.' }
];

function verificationOptions(selected='Control Panel / Try-Out') {
  return VERIFICATION_METHODS.map(x =>
    `<option value="${x.value}" ${x.value === selected ? 'selected' : ''}>${x.value}</option>`
  ).join('');
}

function verificationText(method) {
  return VERIFICATION_METHODS.find(x => x.value === method)?.text || '';
}

function defaultVerificationForEnergy(energyType) {
  const defaults = {
    'Electrical': 'Meter / Try-Out',
    'Control Circuit': 'Try-Out',
    'Pneumatic': 'Bleed / Zero Pressure',
    'Pressure': 'Bleed / Zero Pressure',
    'Hydraulic': 'Bleed / Zero Pressure',
    'Gravity': 'Lower / Block / Restrain',
    'Mechanical': 'Release / Restrain',
    'Stored Energy': 'Release / Restrain',
    'Thermal': 'Safe Temperature',
    'Chemical': 'Drain / Isolate',
    'Other': 'Visual / Physical Check'
  };
  return defaults[energyType] || 'Visual / Physical Check';
}

function applyDefaultVerification(card) {
  if (!card) return;
  const energyType = card.querySelector('[data-field="energyType"]')?.value || 'Other';
  const methodEl = card.querySelector('[data-field="verificationMethod"]');
  if (!methodEl) return;
  const method = defaultVerificationForEnergy(energyType);
  methodEl.value = method;
  const preview = card.querySelector('.verification-method-preview');
  if (preview) preview.textContent = verificationText(method);
}

function syncVerificationPhotoFields(card) {
  const mode = card.querySelector('[data-field="verificationPhotoMode"]')?.value || 'None';
  card.querySelectorAll('.verification-photo-fields').forEach(wrap =>
    wrap.classList.toggle('hidden', mode !== 'Photo + Message'));
}


function energyPrefix(type) {
  return ENERGY_TYPES.find(x => x.value === type)?.prefix || 'O';
}

function energyOptions(selected='') {
  return ENERGY_TYPES.map(x =>
    `<option value="${x.value}" ${x.value === selected ? 'selected' : ''}>${x.value}</option>`
  ).join('');
}

function autoNumberIsolationIds() {
  const counters = {};
  [...el('stepsContainer').querySelectorAll('.step-card')].forEach(card => {
    const type = card.querySelector('[data-field="energyType"]').value || 'Other';
    const prefix = energyPrefix(type);
    counters[prefix] = (counters[prefix] || 0) + 1;
    card.querySelector('[data-field="stepId"]').value = `${prefix}-${counters[prefix]}`;
  });
}

const el = id => document.getElementById(id);

function uid() {
  return (crypto.randomUUID ? crypto.randomUUID() : 'p-' + Date.now() + '-' + Math.random().toString(16).slice(2));
}

function datePlusOneYear(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return '';
  d.setFullYear(d.getFullYear() + 1);
  return d.toISOString().slice(0,10);
}

function getStatus(p) {
  if (p.lifecycleStatus === 'Draft') return { label:'Draft', nextDue:datePlusOneYear(p.annualInspectionDate || p.bornDate) };
  if (p.lifecycleStatus === 'Retired') return { label:'Retired', nextDue:'' };

  const base = p.annualInspectionDate || p.bornDate;
  const nextDue = datePlusOneYear(base);
  if (!nextDue) return { label:'Draft', nextDue:'' };

  const today = new Date();
  today.setHours(0,0,0,0);
  const due = new Date(nextDue + 'T00:00:00');
  const diffDays = Math.ceil((due - today) / 86400000);

  if (diffDays < 0) return { label:'Overdue', nextDue };
  if (diffDays <= 60) return { label:'Due Soon', nextDue };
  return { label:'Current', nextDue };
}

function fmtDate(v) {
  if (!v) return '—';
  const d = new Date(v + 'T00:00:00');
  return Number.isNaN(d.getTime()) ? v : d.toLocaleDateString('en-US');
}

function statusClass(label) {
  return 'status-' + label.toLowerCase().replaceAll(' ','-');
}

// The register reads procedure records only. Photo Blobs are never loaded here; the photo
// count on each row comes from the step metadata and the storage total from index keys.
async function loadRecords() {
  state.records = await LotoDB.getAll();
  sortRecords();
  render();
  refreshStorageMeter();
}

const SORT_FIELDS = {
  area: p => p.area || '',
  equipmentName: p => p.equipmentName || '',
  lotoId: p => p.lotoId || '',
  nextDue: p => getStatus(p).nextDue || ''
};

function compareText(a, b) {
  return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}

function sortRecords() {
  const field = SORT_FIELDS[state.sort.field] ? state.sort.field : 'area';
  const get = SORT_FIELDS[field];
  const dir = state.sort.dir === -1 ? -1 : 1;
  state.records.sort((a, b) => {
    const va = get(a), vb = get(b);
    // Blank values (e.g. no inspection due date) always sort last.
    if (!va !== !vb) return va ? -1 : 1;
    return dir * compareText(va, vb) ||
      compareText(a.area || '', b.area || '') ||
      compareText(a.equipmentName || '', b.equipmentName || '') ||
      compareText(a.lotoId || '', b.lotoId || '');
  });
}

function loadSortPreference() {
  try {
    const saved = JSON.parse(localStorage.getItem('loto.sort') || 'null');
    if (saved && SORT_FIELDS[saved.field]) state.sort = { field: saved.field, dir: saved.dir === -1 ? -1 : 1 };
  } catch (e) { /* preference is optional */ }
  el('sortField').value = state.sort.field;
  syncSortButton();
}

function syncSortButton() {
  el('sortDirBtn').textContent = state.sort.dir === -1 ? '↓' : '↑';
  el('sortDirBtn').title = state.sort.dir === -1 ? 'Descending — click for ascending' : 'Ascending — click for descending';
}

function applySort() {
  state.sort.field = el('sortField').value;
  try { localStorage.setItem('loto.sort', JSON.stringify(state.sort)); } catch (e) { /* optional */ }
  syncSortButton();
  sortRecords();
  renderList();
}

function photoCount(p) {
  let n = 0;
  (p.steps || []).forEach(s => {
    if (s.photo && s.photo.photoId) n++;
    if (s.verificationPhoto && s.verificationPhoto.photoId) n++;
  });
  return n;
}

async function refreshStorageMeter() {
  const budget = LotoPhotos.BUDGET_BYTES;
  try {
    state.photoStats = await LotoDB.photoStats();
  } catch (err) {
    el('storageText').textContent = 'Photo storage could not be read.';
    return;
  }
  const { count, bytes } = state.photoStats;
  const pct = bytes / budget;
  const bar = el('storageBar');
  bar.style.width = Math.min(100, Math.round(pct * 100)) + '%';
  bar.className = 'storage-bar' + (pct >= 1 ? ' over' : pct >= 0.8 ? ' warn' : '');
  el('storageText').textContent = `${count} photo${count === 1 ? '' : 's'} · ${count ? LotoPhotos.fmtBytes(bytes) : '0 KB'} of ${LotoPhotos.fmtBytes(budget)} budget`;

  const warn = el('storageWarning');
  warn.classList.toggle('hidden', pct < 0.8);
  warn.classList.toggle('over', pct >= 1);
  if (pct >= 1) warn.textContent = `Photo data is over the ${LotoPhotos.fmtBytes(budget)} budget. Make a full backup, then remove or replace photos you no longer need.`;
  else if (pct >= 0.8) warn.textContent = `Photo data is approaching the ${LotoPhotos.fmtBytes(budget)} budget. Make a full backup and consider removing unused photos.`;

  const quota = el('storageQuota');
  quota.textContent = '';
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const est = await navigator.storage.estimate();
      if (est && est.quota) {
        quota.textContent = `Browser estimate: ${LotoPhotos.fmtBytes(est.usage || 0)} used of about ${LotoPhotos.fmtBytes(est.quota)} available to this app. This is an estimate, not a guaranteed limit.`;
      }
    }
  } catch (e) { /* estimate is optional */ }
}

function render() {
  renderFilters();
  renderSummary();
  renderList();
}

function renderFilters() {
  const areaSelect = el('areaFilter');
  const current = areaSelect.value;
  const areas = [...new Set(state.records.map(r => r.area).filter(Boolean))].sort();
  areaSelect.innerHTML = '<option value="">All Areas</option>' + areas.map(a => `<option ${a===current?'selected':''}>${escapeHtml(a)}</option>`).join('');
}

function renderSummary() {
  const statuses = state.records.map(getStatus).map(x => x.label);
  el('summaryTotal').textContent = state.records.length;
  el('summaryCurrent').textContent = statuses.filter(x => x === 'Current').length;
  el('summaryDueSoon').textContent = statuses.filter(x => x === 'Due Soon').length;
  el('summaryOverdue').textContent = statuses.filter(x => x === 'Overdue').length;
}

function renderList() {
  const area = el('areaFilter').value;
  const status = el('statusFilter').value;
  const search = (el('searchInput')?.value || '').trim().toLowerCase();

  const filtered = state.records.filter(p => {
    const s = getStatus(p).label;
    const haystack = `${p.area || ''} ${p.equipmentName || ''} ${p.lotoId || ''}`.toLowerCase();
    return (!area || p.area === area) &&
           (!status || s === status) &&
           (!search || haystack.includes(search));
  });

  el('emptyState').classList.toggle('hidden', state.records.length > 0);

  el('procedureList').innerHTML = filtered.map(p => {
    const stat = getStatus(p);
    const photos = photoCount(p);
    // Flag procedures that are Active but would not pass the activation check today
    // (for example records created before the check existed).
    const issues = (p.lifecycleStatus || 'Active') === 'Active' ? validateSteps(p.steps || [], true) : [];
    const issueCount = issues.reduce((n, i) => n + i.missing.length, 0);
    return `
      <article class="procedure-card">
        <div>
          <h3>${escapeHtml(p.equipmentName)}
            <span class="status-pill ${statusClass(stat.label)}">${stat.label}</span>
            ${issueCount ? `<span class="status-pill status-issues" title="${escapeHtml(issues.map(issueText).join('; '))}">Active — ${issueCount} item${issueCount === 1 ? '' : 's'} to fix</span>` : ''}
          </h3>
          <div class="procedure-meta">
            <span><b>${escapeHtml(p.area)}</b></span>
            <span>${escapeHtml(p.lotoId)}</span>
            <span>Born: ${fmtDate(p.bornDate)}</span>
            <span>Inspection: ${fmtDate(p.annualInspectionDate)}</span>
            <span>Next Due: ${fmtDate(stat.nextDue)}</span>
            <span>${(p.steps||[]).length} step${(p.steps||[]).length===1?'':'s'}</span>
            ${photos ? `<span>${photos} photo${photos === 1 ? '' : 's'}</span>` : ''}
          </div>
        </div>
        <div class="card-actions">
          <button data-action="preview" data-id="${escapeHtml(p.id)}">Preview</button>
          <button data-action="edit" data-id="${escapeHtml(p.id)}">Edit</button>
          <button data-action="history" data-id="${escapeHtml(p.id)}">History</button>
          <button data-action="duplicate" data-id="${escapeHtml(p.id)}">Duplicate</button>
          <button data-action="delete" data-id="${escapeHtml(p.id)}">Delete</button>
        </div>
      </article>`;
  }).join('');

  if (state.records.length && filtered.length === 0) {
    el('procedureList').innerHTML = '<div class="empty-state"><h3>No matching procedures</h3><p>Adjust the search, area or status filter.</p></div>';
  }
}

function escapeHtml(v='') {
  return String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
}

function resetDraft() {
  draft.images.forEach(p => p.then(img => { if (img && img.close) img.close(); }).catch(() => {}));
  draft.extras.clear();
  draft.pending.clear();
  draft.saved.clear();
  draft.images.clear();
  draft.thumbRun++;
}

function draftPhotoRecord(photoId) {
  return draft.pending.get(photoId) || draft.saved.get(photoId) || null;
}

function draftImage(photoId) {
  if (!draft.images.has(photoId)) {
    const rec = draftPhotoRecord(photoId);
    draft.images.set(photoId, rec ? LotoPhotos.decode(rec.blob) : Promise.reject(new Error('Photo not found.')));
  }
  return draft.images.get(photoId);
}

// Photo metadata is only usable in the drawer if its image is actually available.
function usablePhotoMeta(meta) {
  const m = LotoPhotos.normalizeMeta(meta);
  return m && draftPhotoRecord(m.photoId) ? m : null;
}

async function openDrawer(record=null, opts={}) {
  resetDraft();
  if (record?.id) {
    try {
      (await LotoDB.getPhotosForProcedure(record.id)).forEach(r => draft.saved.set(r.id, r));
    } catch (err) {
      alert('The photos for this procedure could not be loaded: ' + err.message);
    }
  }
  state.editingId = record?.id || null;
  el('drawerTitle').textContent = record ? (opts.fromRevision ? `Edit Procedure (from Rev ${opts.fromRevision})` : 'Edit Procedure') : 'New Procedure';
  el('procedureForm').reset();
  clearValidation();
  el('procedureId').value = record?.id || '';
  el('startingSteps').value = record?.steps?.length || 2;

  if (record) {
    el('area').value = record.area || '';
    el('equipmentName').value = record.equipmentName || '';
    el('lotoId').value = record.lotoId || '';
    el('procedureType').value = record.procedureType || 'Full Isolation';
    el('lifecycleStatus').value = record.lifecycleStatus || 'Active';
    el('bornDate').value = record.bornDate || '';
    el('annualInspectionDate').value = record.annualInspectionDate || '';
    el('revisionDate').value = record.revisionDate || '';
    el('reviewedBy').value = record.reviewedBy || '';
    el('specialNotes').value = record.specialNotes || '';
    el('revisionNote').value = opts.fromRevision ? `Restored from Rev ${opts.fromRevision}` : '';
    const missing = (record.steps || []).reduce((n, s) =>
      n + PHOTO_SLOTS.filter(ps => s[ps.key] && s[ps.key].photoId && !draftPhotoRecord(s[ps.key].photoId)).length, 0);
    setSteps(record.steps || []);
    if (missing) {
      setTimeout(() => alert(`${missing} photo${missing === 1 ? '' : 's'} referenced by this version ${missing === 1 ? 'is' : 'are'} no longer stored (replaced or removed in a later save, or not included in the restored backup). Those cards will show the placeholder until a photo is added.`), 50);
    }
  } else {
    const today = new Date().toISOString().slice(0,10);
    el('lifecycleStatus').value = 'Active';
    el('bornDate').value = today;
    el('revisionDate').value = today;
    buildStepCount(2);
  }

  el('procedureDrawer').classList.add('open');
  el('procedureDrawer').setAttribute('aria-hidden','false');
  el('drawerBackdrop').classList.remove('hidden');
}

function closeDrawer() {
  el('procedureDrawer').classList.remove('open');
  el('procedureDrawer').setAttribute('aria-hidden','true');
  el('drawerBackdrop').classList.add('hidden');
  state.editingId = null;
  resetDraft();
}

function defaultStep(index) {
  return {
    stepId: 'E-1',
    energyType: 'Electrical',
    magnitude: '',
    device: '',
    location: '',
    verificationMethod: 'Meter / Try-Out',
    verificationPhotoMode: 'None',
    verificationPhotoOrientation: 'Landscape',
    verificationPhotoLabel: `VERIFY PHOTO ${index+1}`,
    photoLabel: `PHOTO ${index+1}`,
    photoOrientation: 'Landscape',
    uid: uid(),
    photo: null,
    verificationPhoto: null
  };
}

function setSteps(steps) {
  el('stepsContainer').innerHTML = '';
  const seen = new Set();
  steps.forEach((s,i) => {
    // Every step gets a stable id; records saved before V2.4 receive one here.
    let stepUid = s.uid && !seen.has(s.uid) ? s.uid : uid();
    seen.add(stepUid);
    draft.extras.set(stepUid, {
      photo: usablePhotoMeta(s.photo),
      verificationPhoto: usablePhotoMeta(s.verificationPhoto)
    });
    el('stepsContainer').insertAdjacentHTML('beforeend', stepCardHTML({ ...s, uid: stepUid }, i));
  });
  renumberStepCards();
  refreshThumbs();
}

function stepExtras(card) {
  const key = card.dataset.uid;
  if (!draft.extras.has(key)) draft.extras.set(key, { photo: null, verificationPhoto: null });
  return draft.extras.get(key);
}

function currentSteps() {
  return [...el('stepsContainer').querySelectorAll('.step-card')].map((card, idx) => ({
    uid: card.dataset.uid,
    photo: LotoPhotos.normalizeMeta(stepExtras(card).photo),
    verificationPhoto: LotoPhotos.normalizeMeta(stepExtras(card).verificationPhoto),
    stepId: card.querySelector('[data-field="stepId"]').value.trim(),
    energyType: card.querySelector('[data-field="energyType"]').value.trim(),
    magnitude: card.querySelector('[data-field="magnitude"]').value.trim(),
    device: card.querySelector('[data-field="device"]').value.trim(),
    location: card.querySelector('[data-field="location"]').value.trim(),
    verificationMethod: card.querySelector('[data-field="verificationMethod"]').value,
    verificationPhotoMode: card.querySelector('[data-field="verificationPhotoMode"]').value,
    verificationPhotoOrientation: card.querySelector('[data-field="verificationPhotoOrientation"]').value || 'Landscape',
    verificationPhotoLabel: card.querySelector('[data-field="verificationPhotoLabel"]').value.trim() || `VERIFY PHOTO ${idx+1}`,
    photoLabel: card.querySelector('[data-field="photoLabel"]').value.trim() || `PHOTO ${idx+1}`,
    photoOrientation: card.querySelector('[data-field="photoOrientation"]').value || 'Landscape'
  }));
}

function buildStepCount(count) {
  const n = Math.max(1, Math.min(20, Number(count) || 1));
  const existing = currentSteps();
  const next = Array.from({length:n}, (_,i) => existing[i] || defaultStep(i));
  setSteps(next);
}

function stepCardHTML(s, idx) {
  const energyType = s.energyType || 'Electrical';
  const photoOrientation = s.photoOrientation || 'Landscape';

  // Backward compatibility: convert old free-text verification records, and method names
  // from earlier versions that are no longer in the list, to a best-fit current method.
  // (Without this, an unknown saved method silently fell back to the first dropdown option.)
  let verificationMethod = s.verificationMethod;
  if (verificationMethod && !VERIFICATION_METHODS.some(x => x.value === verificationMethod)) {
    verificationMethod = LotoExport.getVerificationMethod(s);
  }
  if (!verificationMethod) {
    const old = String(s.verification || '').toLowerCase();
    if (old.includes('pressure') || old.includes('gauge') || old.includes('bleed')) verificationMethod = 'Bleed / Zero Pressure';
    else if (old.includes('meter') || old.includes('voltage')) verificationMethod = 'Meter / Try-Out';
    else if (old.includes('lower') || old.includes('gravity') || old.includes('block')) verificationMethod = 'Lower / Block / Restrain';
    else if (old.includes('release') || old.includes('restrain')) verificationMethod = 'Release / Restrain';
    else if (old.includes('temperature') || old.includes('thermal')) verificationMethod = 'Safe Temperature';
    else if (old.includes('drain') || old.includes('chemical')) verificationMethod = 'Drain / Isolate';
    else if (old.includes('try') || old.includes('start')) verificationMethod = 'Try-Out';
    else verificationMethod = defaultVerificationForEnergy(energyType);
  }

  const verificationPhotoMode = s.verificationPhotoMode || 'None';
  const verificationPhotoOrientation = s.verificationPhotoOrientation || 'Landscape';

  return `
    <div class="step-card" data-step-index="${idx}" data-uid="${escapeHtml(s.uid || '')}">
      <div class="step-card-header">
        <strong>Step <span class="step-number">${idx+1}</span></strong>
        <div class="step-actions">
          <button type="button" data-step-action="up">↑</button>
          <button type="button" data-step-action="down">↓</button>
          <button type="button" data-step-action="duplicate">Duplicate</button>
          <button type="button" data-step-action="delete" class="danger">Delete</button>
        </div>
      </div>

      <div class="mini-section-label">LOCK HERE</div>

      <div class="field-grid two">
        <label>
          Energy Type
          <select data-field="energyType">
            ${energyOptions(energyType)}
          </select>
        </label>
        <label>
          Isolation ID
          <input data-field="stepId" value="${escapeHtml(s.stepId || '')}" readonly title="Automatically assigned from energy type" />
        </label>
      </div>

      <div class="field-grid two">
        <label>Magnitude<input data-field="magnitude" value="${escapeHtml(s.magnitude || '')}" placeholder="240V" /></label>
        <label>Device<input data-field="device" value="${escapeHtml(s.device || '')}" placeholder="Lock / Hasp" /></label>
      </div>

      <label>Lock Location<input data-field="location" value="${escapeHtml(s.location || '')}" placeholder="Disconnect south of equipment" /></label>

      <div class="field-grid two">
        <label>
          Lock Photo Orientation
          <select data-field="photoOrientation">
            <option value="Landscape" ${photoOrientation === 'Landscape' ? 'selected' : ''}>Landscape</option>
            <option value="Portrait" ${photoOrientation === 'Portrait' ? 'selected' : ''}>Portrait</option>
          </select>
        </label>
        <label>Lock Photo Label<input data-field="photoLabel" value="${escapeHtml(s.photoLabel || `PHOTO ${idx+1}`)}" /></label>
      </div>

      ${photoRowHTML('lock')}

      <div class="mini-section-label verification-label">VERIFICATION METHOD</div>

      <div class="field-grid two">
        <label>
          Method
          <select data-field="verificationMethod">
            ${verificationOptions(verificationMethod)}
          </select>
        </label>
        <label>
          Verification Photo Card
          <select data-field="verificationPhotoMode">
            <option value="None" ${verificationPhotoMode === 'None' ? 'selected' : ''}>No Separate Verification Card</option>
            <option value="Photo + Message" ${verificationPhotoMode === 'Photo + Message' ? 'selected' : ''}>Create Separate Verification Card</option>
          </select>
        </label>
      </div>

      <div class="verification-method-preview">${escapeHtml(verificationText(verificationMethod))}</div>

      <div class="field-grid two verification-photo-fields ${verificationPhotoMode === 'Photo + Message' ? '' : 'hidden'}">
        <label>
          Verification Photo Orientation
          <select data-field="verificationPhotoOrientation">
            <option value="Landscape" ${verificationPhotoOrientation === 'Landscape' ? 'selected' : ''}>Landscape</option>
            <option value="Portrait" ${verificationPhotoOrientation === 'Portrait' ? 'selected' : ''}>Portrait</option>
          </select>
        </label>
        <label>Verification Photo Label<input data-field="verificationPhotoLabel" value="${escapeHtml(s.verificationPhotoLabel || `VERIFY PHOTO ${idx+1}`)}" /></label>
      </div>

      ${photoRowHTML('verify', verificationPhotoMode === 'Photo + Message' ? '' : 'hidden')}
    </div>`;
}

function photoRowHTML(slot, extraClass='') {
  return `
      <div class="photo-row ${slot === 'verify' ? 'verification-photo-fields' : ''} ${extraClass}" data-slot="${slot}">
        <div class="photo-thumb-wrap">No photo</div>
        <div class="photo-row-actions">
          <button type="button" data-photo-action="edit">Add Photo</button>
          <button type="button" data-photo-action="remove" class="danger-text hidden">Remove</button>
          <span class="photo-row-info">${slot === 'verify' ? 'Verification card photo' : 'Lock card photo'} — placeholder prints until a photo is added.</span>
        </div>
      </div>`;
}

// Redraws the small photo previews in the step cards from the draft metadata.
async function refreshThumbs() {
  const run = ++draft.thumbRun;
  for (const card of [...el('stepsContainer').querySelectorAll('.step-card')]) {
    for (const ps of PHOTO_SLOTS) {
      const row = card.querySelector(`.photo-row[data-slot="${ps.slot}"]`);
      if (!row) continue;
      const meta = stepExtras(card)[ps.key];
      const wrap = row.querySelector('.photo-thumb-wrap');
      const editBtn = row.querySelector('[data-photo-action="edit"]');
      const removeBtn = row.querySelector('[data-photo-action="remove"]');
      const info = row.querySelector('.photo-row-info');
      const what = ps.slot === 'verify' ? 'Verification card photo' : 'Lock card photo';
      if (!meta) {
        wrap.textContent = 'No photo';
        editBtn.textContent = 'Add Photo';
        removeBtn.classList.add('hidden');
        info.textContent = `${what} — placeholder prints until a photo is added.`;
        continue;
      }
      editBtn.textContent = 'Edit Photo';
      removeBtn.classList.remove('hidden');
      const rec = draftPhotoRecord(meta.photoId);
      const n = meta.callouts.length;
      info.textContent = [
        what,
        rec ? `${(rec.mime || '').replace('image/', '').toUpperCase()} ${LotoPhotos.fmtBytes(rec.bytes)}` : '',
        `${n} callout${n === 1 ? '' : 's'}`,
        draft.pending.has(meta.photoId) ? 'not saved yet' : ''
      ].filter(Boolean).join(' · ');
      try {
        const img = await draftImage(meta.photoId);
        if (run !== draft.thumbRun) return;
        const orientation = card.querySelector(`[data-field="${ps.orientationField}"]`).value;
        const canvas = LotoPhotos.composeCanvas(img, meta, orientation, 240);
        canvas.className = 'photo-thumb';
        wrap.textContent = '';
        wrap.appendChild(canvas);
      } catch (err) {
        if (run !== draft.thumbRun) return;
        wrap.textContent = 'Photo unavailable';
      }
    }
  }
}

function pendingBytes() {
  let n = 0;
  draft.pending.forEach(p => { n += p.bytes || 0; });
  return n;
}

async function handlePhotoAction(btn) {
  const card = btn.closest('.step-card');
  const row = btn.closest('.photo-row');
  const ps = PHOTO_SLOTS.find(x => x.slot === row.dataset.slot);
  const extras = stepExtras(card);

  if (btn.dataset.photoAction === 'remove') {
    if (!confirm('Remove this photo and its callouts from the card? This takes effect when the procedure is saved.')) return;
    extras[ps.key] = null;
    refreshThumbs();
    return;
  }

  const meta = extras[ps.key];
  let img = null;
  if (meta) {
    try { img = await draftImage(meta.photoId); }
    catch (err) { alert('This photo could not be opened: ' + err.message); }
  }
  const stepId = card.querySelector('[data-field="stepId"]').value;
  const result = await LotoPhotos.openEditor({
    title: `${ps.slot === 'verify' ? 'Verification Photo' : 'Lock Photo'} — ${stepId || 'Step ' + (Number(card.dataset.stepIndex) + 1)}`,
    orientation: card.querySelector(`[data-field="${ps.orientationField}"]`).value,
    meta: img ? meta : null,
    img,
    info: meta ? draftPhotoRecord(meta.photoId) : null,
    storageBytes: state.photoStats.bytes + pendingBytes()
  });
  if (!result) return;
  if (result.newPhoto) draft.pending.set(result.newPhoto.id, result.newPhoto);
  extras[ps.key] = result.meta;
  refreshThumbs();
}

// Gives a duplicated step its own copy of the photo, so later edits stay independent.
function clonePhotoForDuplicate(meta) {
  const m = LotoPhotos.normalizeMeta(meta);
  const rec = m && draftPhotoRecord(m.photoId);
  if (!rec) return null;
  const id = LotoPhotos.newId();
  draft.pending.set(id, { id, blob: rec.blob, mime: rec.mime, width: rec.width, height: rec.height, bytes: rec.bytes });
  return { ...m, photoId: id, callouts: m.callouts.map(k => ({ ...k, id: LotoPhotos.newId() })) };
}

/* ---------- activation check ---------- */

// Returns [{ index, stepId, missing: [{ field, label }] }] for steps that are not complete
// enough for an Active procedure. `raw` = stored records (legacy fields allowed).
function validateSteps(steps, raw=false) {
  const out = [];
  steps.forEach((s, index) => {
    const missing = [];
    if (!String(s.energyType || '').trim()) missing.push({ field: 'energyType', label: 'Energy Type' });
    if (!String(s.device || '').trim()) missing.push({ field: 'device', label: 'Device' });
    if (!String(s.location || '').trim()) missing.push({ field: 'location', label: 'Lock Location' });
    const method = String(s.verificationMethod || (raw ? s.verification : '') || '').trim();
    if (!method) missing.push({ field: 'verificationMethod', label: 'Verification Method' });
    if (missing.length) out.push({ index, stepId: s.stepId || '', missing });
  });
  return out;
}

function issueText(issue) {
  return `Step ${issue.index + 1}${issue.stepId ? ` (${issue.stepId})` : ''}: missing ${issue.missing.map(m => m.label).join(', ')}`;
}

function clearValidation() {
  el('validationPanel').classList.add('hidden');
  el('validationPanel').innerHTML = '';
  el('stepsContainer').querySelectorAll('.field-invalid').forEach(x => x.classList.remove('field-invalid'));
}

function showValidation(issues) {
  const cards = [...el('stepsContainer').querySelectorAll('.step-card')];
  issues.forEach(issue => issue.missing.forEach(m => {
    cards[issue.index]?.querySelector(`[data-field="${m.field}"]`)?.classList.add('field-invalid');
  }));
  const panel = el('validationPanel');
  panel.className = 'validation-panel';
  panel.innerHTML = `
    <strong>This procedure cannot be marked Active yet.</strong>
    Fix the items below, or save it as a Draft and finish it later. Nothing has been saved.
    <ul>${issues.map(i => `<li>${escapeHtml(issueText(i))}</li>`).join('')}</ul>
    <button type="button" id="saveAsDraftBtn">Save as Draft Instead</button>`;
  panel.scrollIntoView({ block: 'center' });
}

function showSaveError(err) {
  const quota = err && (err.name === 'QuotaExceededError' || /quota/i.test(err.message || ''));
  const panel = el('validationPanel');
  panel.className = 'validation-panel save-error';
  panel.innerHTML = `
    <strong>${quota ? 'The browser is out of storage space — the procedure was not saved.' : 'The procedure could not be saved.'}</strong>
    Nothing was changed: the previously saved version of this procedure and all stored photos are intact, and your edits are still open here.
    ${quota ? 'Remove or replace some photos (here or in other procedures), or free up browser storage, then choose Save Procedure again. A full backup first is recommended.' : ''}
    <div class="photo-muted">${escapeHtml((err && (err.message || err.name)) || 'Unknown error')}</div>`;
  panel.scrollIntoView({ block: 'center' });
}

/* ---------- revision history ---------- */

function contentKey(record) {
  const { createdAt, updatedAt, ...rest } = record;
  return JSON.stringify(rest);
}

function makeRevision(record, rev, { savedAt, note }) {
  return {
    id: uid(),
    procedureId: record.id,
    rev,
    savedAt,
    revisionDate: record.revisionDate || '',
    reviewedBy: record.reviewedBy || '',
    lifecycleStatus: record.lifecycleStatus || 'Active',
    note: note || '',
    snapshot: structuredClone(record)
  };
}

function fmtDateTime(iso) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'short' });
}

async function openHistory(p) {
  const revs = (await LotoDB.getRevisions(p.id)).slice().reverse();
  el('historyTitle').textContent = `Revision History — ${p.lotoId || ''} ${p.equipmentName || ''}`;
  const body = el('historyBody');
  if (!revs.length) {
    body.innerHTML = `
      <div class="history-item">
        <div>
          <h4>Current saved version</h4>
          <div class="procedure-meta">
            <span>Saved: ${escapeHtml(fmtDateTime(p.updatedAt || p.createdAt))}</span>
            <span>Revision date: ${fmtDate(p.revisionDate)}</span>
            <span>Reviewed by: ${escapeHtml(p.reviewedBy || '—')}</span>
          </div>
          <div class="history-note">No earlier revisions are recorded. This version is kept as the baseline the next time the procedure is saved with changes.</div>
        </div>
        <div class="history-actions"><button type="button" data-rev-action="view-current">View</button></div>
      </div>`;
  } else {
    body.innerHTML = revs.map((r, i) => `
      <div class="history-item">
        <div>
          <h4>Rev ${r.rev}${i === 0 ? ' <span class="status-pill status-current">Current</span>' : ''}</h4>
          <div class="procedure-meta">
            <span>Saved: ${escapeHtml(fmtDateTime(r.savedAt))}</span>
            <span>Revision date: ${fmtDate(r.revisionDate)}</span>
            <span>Reviewed by: ${escapeHtml(r.reviewedBy || '—')}</span>
            <span>Status: ${escapeHtml(r.lifecycleStatus || '')}</span>
          </div>
          ${r.note ? `<div class="history-note">${escapeHtml(r.note)}</div>` : ''}
        </div>
        <div class="history-actions">
          <button type="button" data-rev-action="view" data-rev-id="${escapeHtml(r.id)}">View</button>
          ${i === 0 ? '' : `<button type="button" data-rev-action="load" data-rev-id="${escapeHtml(r.id)}">Load into Editor</button>`}
        </div>
      </div>`).join('');
  }
  body.onclick = async evt => {
    const btn = evt.target.closest('button[data-rev-action]');
    if (!btn) return;
    const action = btn.dataset.revAction;
    const rev = revs.find(r => r.id === btn.dataset.revId);
    if (action === 'view-current') {
      closeHistory();
      await openPreview(p, { returnTo: p });
    } else if (action === 'view' && rev) {
      closeHistory();
      await openPreview({ ...rev.snapshot, id: p.id }, {
        label: rev === revs[0] ? `Rev ${rev.rev} (current)` : `Viewing Rev ${rev.rev} of ${revs[0].rev} — saved ${fmtDateTime(rev.savedAt)} — not the current version`,
        returnTo: p
      });
    } else if (action === 'load' && rev) {
      closeHistory();
      // Loads the old version into the editor; nothing changes until it is saved,
      // and saving records it as a new revision.
      await openDrawer({ ...rev.snapshot, id: p.id, createdAt: p.createdAt }, { fromRevision: rev.rev });
    }
  };
  el('historyModal').classList.remove('hidden');
}

function closeHistory() {
  el('historyModal').classList.add('hidden');
}

function renumberStepCards() {
  [...el('stepsContainer').children].forEach((card,i) => {
    card.dataset.stepIndex = i;
    card.querySelector('.step-number').textContent = i+1;
    const photo = card.querySelector('[data-field="photoLabel"]');
    if (!photo.value.trim() || /^PHOTO \d+$/i.test(photo.value.trim())) photo.value = `PHOTO ${i+1}`;
    const verifyPhoto = card.querySelector('[data-field="verificationPhotoLabel"]');
    if (verifyPhoto && (!verifyPhoto.value.trim() || /^VERIFY PHOTO \d+$/i.test(verifyPhoto.value.trim()))) {
      verifyPhoto.value = `VERIFY PHOTO ${i+1}`;
    }
  });
  autoNumberIsolationIds();
  el('startingSteps').value = el('stepsContainer').children.length;
}

async function saveProcedure(evt) {
  evt.preventDefault();
  clearValidation();
  const steps = currentSteps();

  // Drafts (and Retired procedures) may be saved incomplete; Active requires complete steps.
  if ((el('lifecycleStatus').value || 'Active') === 'Active') {
    const issues = validateSteps(steps);
    if (issues.length) { showValidation(issues); return; }
  }

  const id = state.editingId || uid();
  let existing = null, priorRevs = [];
  try {
    existing = state.editingId ? await LotoDB.get(id) : null;
    priorRevs = existing ? await LotoDB.getRevisions(id) : [];
  } catch (err) { showSaveError(err); return; }
  const now = new Date().toISOString();

  const record = {
    id,
    area: el('area').value.trim(),
    equipmentName: el('equipmentName').value.trim(),
    lotoId: el('lotoId').value.trim(),
    procedureType: el('procedureType').value,
    bornDate: el('bornDate').value,
    annualInspectionDate: el('annualInspectionDate').value,
    revisionDate: el('revisionDate').value,
    reviewedBy: el('reviewedBy').value.trim(),
    specialNotes: el('specialNotes').value.trim(),
    lifecycleStatus: el('lifecycleStatus').value || 'Active',
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    steps
  };

  // Photos: store newly added assets, keep the ones still referenced, drop the rest.
  const keepPhotoIds = new Set();
  const newPhotos = [];
  steps.forEach(s => PHOTO_SLOTS.forEach(ps => {
    const meta = s[ps.key];
    if (!meta) return;
    keepPhotoIds.add(meta.photoId);
    const pend = draft.pending.get(meta.photoId);
    if (pend && !newPhotos.some(n => n.id === pend.id)) {
      newPhotos.push({
        id: pend.id, procedureId: id, stepUid: s.uid, slot: ps.slot,
        blob: pend.blob, mime: pend.mime, width: pend.width, height: pend.height,
        bytes: pend.bytes, createdAt: now
      });
    }
  }));

  let projected = state.photoStats.bytes + newPhotos.reduce((n, p) => n + p.bytes, 0);
  draft.saved.forEach(rec => { if (!keepPhotoIds.has(rec.id)) projected -= rec.bytes || 0; });
  if (newPhotos.length && projected > LotoPhotos.BUDGET_BYTES) {
    if (!confirm(`After this save, local photo data will be about ${LotoPhotos.fmtBytes(projected)}, above the ${LotoPhotos.fmtBytes(LotoPhotos.BUDGET_BYTES)} budget.\n\nThe browser may still accept it, but a full backup and removing unused photos is recommended.\n\nSave anyway?`)) return;
  }

  // Revision history: every save that changes the procedure adds a revision holding that
  // version. A record from before V2.4 is first kept as a baseline so it is not overwritten.
  const revisions = [];
  let rev = priorRevs.length ? priorRevs[priorRevs.length - 1].rev : 0;
  const note = el('revisionNote').value.trim();
  if (existing && !priorRevs.length) {
    revisions.push(makeRevision(existing, ++rev, {
      savedAt: existing.updatedAt || existing.createdAt || now,
      note: 'Baseline — version saved before revision history was recorded.'
    }));
  }
  if (!existing || note || contentKey(existing) !== contentKey(record)) {
    revisions.push(makeRevision(record, ++rev, { savedAt: now, note: note || (existing ? '' : 'Procedure created.') }));
  }

  try {
    await LotoDB.saveProcedure({ record, newPhotos, keepPhotoIds, revisions });
  } catch (err) {
    showSaveError(err);
    return;
  }
  closeDrawer();
  await loadRecords();
}

// Copies a procedure with its own photo records and step ids, so edits to the copy
// (including photo crops, callouts and replacements) never touch the original.
async function duplicateProcedure(p) {
  const now = new Date().toISOString();
  const copy = structuredClone(p);
  copy.id = uid();
  copy.lotoId = `${copy.lotoId}-COPY`;
  copy.equipmentName = `${copy.equipmentName} Copy`;
  copy.bornDate = now.slice(0,10);
  copy.revisionDate = copy.bornDate;
  copy.annualInspectionDate = '';
  copy.lifecycleStatus = 'Draft';     // a copy is reviewed and activated deliberately
  copy.createdAt = now;
  copy.updatedAt = now;

  const source = new Map((await LotoDB.getPhotosForProcedure(p.id)).map(r => [r.id, r]));
  const newPhotos = [];
  copy.steps = (copy.steps || []).map(s => {
    const step = { ...s, uid: uid() };
    PHOTO_SLOTS.forEach(ps => {
      const meta = LotoPhotos.normalizeMeta(step[ps.key]);
      const rec = meta && source.get(meta.photoId);
      if (!rec) { step[ps.key] = null; return; }
      const photoId = LotoPhotos.newId();
      newPhotos.push({ ...rec, id: photoId, procedureId: copy.id, stepUid: step.uid, slot: ps.slot, createdAt: now });
      step[ps.key] = { ...meta, photoId, callouts: meta.callouts.map(k => ({ ...k, id: LotoPhotos.newId() })) };
    });
    return step;
  });

  await LotoDB.saveProcedure({
    record: copy,
    newPhotos,
    keepPhotoIds: new Set(newPhotos.map(n => n.id)),
    revisions: [makeRevision(copy, 1, { savedAt: now, note: `Duplicated from ${p.lotoId || p.equipmentName || 'another procedure'}.` })]
  });
  return copy;
}

async function handleListClick(evt) {
  const btn = evt.target.closest('button[data-action]');
  if (!btn) return;
  const p = await LotoDB.get(btn.dataset.id);
  if (!p) return;

  if (btn.dataset.action === 'edit') await openDrawer(p);

  if (btn.dataset.action === 'preview') await openPreview(p);

  if (btn.dataset.action === 'history') await openHistory(p);

  if (btn.dataset.action === 'duplicate') {
    try {
      const copy = await duplicateProcedure(p);
      await loadRecords();
      await openDrawer(copy);
    } catch (err) {
      const quota = err && (err.name === 'QuotaExceededError' || /quota/i.test(err.message || ''));
      alert((quota ? 'The browser is out of storage space, so the copy was not created. ' : 'The copy could not be created. ') +
        'Nothing was changed. ' + (err.message || ''));
    }
  }

  if (btn.dataset.action === 'delete') {
    const photos = photoCount(p);
    if (confirm(`Delete ${p.lotoId} — ${p.equipmentName}?` +
        `\n\nThis also deletes its ${photos ? photos + ' photo' + (photos === 1 ? '' : 's') + ' and its ' : ''}revision history. It cannot be undone.`)) {
      await LotoDB.remove(p.id);
      await loadRecords();
    }
  }
}

function handleStepClick(evt) {
  const photoBtn = evt.target.closest('button[data-photo-action]');
  if (photoBtn) { handlePhotoAction(photoBtn); return; }
  const btn = evt.target.closest('button[data-step-action]');
  if (!btn) return;
  const card = btn.closest('.step-card');
  const action = btn.dataset.stepAction;

  if (action === 'delete') {
    if (el('stepsContainer').children.length === 1) {
      alert('A procedure must have at least one step.');
      return;
    }
    card.remove();
  }

  if (action === 'duplicate') {
    const i = [...el('stepsContainer').children].indexOf(card);
    const steps = currentSteps();
    steps.splice(i+1,0,{
      ...steps[i], stepId:'', photoLabel:`PHOTO ${i+2}`,
      uid: uid(),
      photo: clonePhotoForDuplicate(steps[i].photo),
      verificationPhoto: clonePhotoForDuplicate(steps[i].verificationPhoto)
    });
    setSteps(steps);
  }

  if (action === 'up' && card.previousElementSibling) {
    card.parentElement.insertBefore(card, card.previousElementSibling);
  }

  if (action === 'down' && card.nextElementSibling) {
    card.parentElement.insertBefore(card.nextElementSibling, card);
  }

  renumberStepCards();
}

// Loads and composes the photos of ONE procedure for preview / print / PNG / SVG.
//   urls   : "<stepIndex>:<lock|verify>" -> object URL of the composed photo (HTML outputs)
//   images : same key -> { img, meta, orientation } (canvas output and SVG embedding)
async function loadProcedureAssets(p) {
  const assets = { urls: {}, images: {}, decoded: [], missing: 0 };
  const wanted = [];
  (p.steps || []).forEach((s, i) => {
    const lock = LotoPhotos.normalizeMeta(s.photo);
    if (lock) wanted.push({ key: `${i}:lock`, meta: lock, orientation: s.photoOrientation || 'Landscape' });
    const verify = s.verificationPhotoMode === 'Photo + Message' ? LotoPhotos.normalizeMeta(s.verificationPhoto) : null;
    if (verify) wanted.push({ key: `${i}:verify`, meta: verify, orientation: s.verificationPhotoOrientation || 'Landscape' });
  });
  if (!wanted.length || !p.id) return assets;

  const records = new Map((await LotoDB.getPhotosForProcedure(p.id)).map(r => [r.id, r]));
  const decoded = new Map();
  for (const w of wanted) {
    const rec = records.get(w.meta.photoId);
    if (!rec) { assets.missing++; continue; }
    try {
      if (!decoded.has(rec.id)) {
        const img = await LotoPhotos.decode(rec.blob);
        decoded.set(rec.id, img);
        assets.decoded.push(img);
      }
      const img = decoded.get(rec.id);
      assets.images[w.key] = { img, meta: w.meta, orientation: w.orientation };
      assets.urls[w.key] = await LotoPhotos.composeObjectURL(img, w.meta, w.orientation, 1500);
    } catch (err) {
      assets.missing++;
    }
  }
  return assets;
}

function releaseAssets(assets) {
  if (!assets) return;
  Object.values(assets.urls).forEach(u => URL.revokeObjectURL(u));
  assets.decoded.forEach(img => { if (img.close) img.close(); });
}

async function openPreview(p, context={}) {
  let assets;
  try {
    assets = await loadProcedureAssets(p);
  } catch (err) {
    assets = { urls: {}, images: {}, decoded: [], missing: 0 };
    alert('Photos could not be loaded for the preview; placeholders are shown instead. ' + err.message);
  }
  releaseAssets(state.previewAssets);
  state.previewing = p;
  state.previewAssets = assets;
  state.previewReturnsToHistory = context.returnTo || null;
  el('printSheetWrap').innerHTML = LotoExport.sheetHTML(p, assets);

  const notes = [];
  if (context.label) notes.push(context.label);
  if (assets.missing) notes.push(`${assets.missing} photo${assets.missing === 1 ? ' is' : 's are'} no longer stored for this version — placeholder shown`);
  el('previewContext').textContent = notes.join(' · ');
  el('previewContext').classList.toggle('hidden', !notes.length);
  el('previewModal').classList.remove('hidden');
}

function closePreview() {
  el('previewModal').classList.add('hidden');
  el('printSheetWrap').innerHTML = '';
  releaseAssets(state.previewAssets);
  state.previewAssets = null;
  state.previewing = null;
  const back = state.previewReturnsToHistory;
  state.previewReturnsToHistory = null;
  if (back) openHistory(back);
}

/* ---------- backup / restore ---------- */

const PHOTO_EXT = { 'image/webp': 'webp', 'image/jpeg': 'jpg', 'image/png': 'png' };

// Full backup: one ZIP with a manifest, the procedure data (procedures.json, same shape as
// the legacy Backup JSON, including crop settings and callouts), revision history and
// every photo as its own image file.
async function backupZip() {
  const btn = el('backupBtn');
  const label = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Building backup…';
  try {
    const procedures = await LotoDB.getAll();
    const revisions = await LotoDB.getAllRevisions();
    const photoIds = await LotoDB.getAllPhotoKeys();
    const entries = [];
    const photoList = [];
    for (const photoId of photoIds) {             // one photo at a time
      const rec = await LotoDB.getPhoto(photoId);
      if (!rec || !rec.blob) continue;
      const file = `photos/${String(rec.id).replace(/[^\w.-]+/g, '_')}.${PHOTO_EXT[rec.mime] || 'bin'}`;
      entries.push({ name: file, data: rec.blob });
      photoList.push({
        id: rec.id, procedureId: rec.procedureId, stepUid: rec.stepUid || '', slot: rec.slot || '',
        file, mime: rec.mime, width: rec.width, height: rec.height, bytes: rec.bytes, createdAt: rec.createdAt || ''
      });
    }
    const manifest = {
      app: 'LOTO Procedure Manager',
      format: 'loto-full-backup',
      formatVersion: 1,
      appVersion: LotoExport.APP_VERSION,
      exportedAt: new Date().toISOString(),
      counts: { procedures: procedures.length, photos: photoList.length, revisions: revisions.length },
      files: { procedures: 'procedures.json', revisions: 'revisions.json' },
      photos: photoList
    };
    const zip = await LotoZip.create([
      { name: 'manifest.json', data: JSON.stringify(manifest, null, 2) },
      { name: 'procedures.json', data: LotoExport.proceduresPayload(procedures) },
      { name: 'revisions.json', data: JSON.stringify(revisions) },
      ...entries
    ]);
    LotoExport.downloadBlob(zip, `LOTO_Full_Backup_${new Date().toISOString().slice(0,10)}.zip`, 'application/zip');
  } catch (err) {
    alert('Could not create the backup: ' + (err.message || err));
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
}

function cleanProcedures(list) {
  if (!Array.isArray(list)) throw new Error('No procedures array found.');
  return list.filter(r => r && typeof r === 'object').map(r => ({ ...r, id: r.id || uid(), steps: Array.isArray(r.steps) ? r.steps : [] }));
}

async function parseFullBackup(file) {
  const files = await LotoZip.read(file);
  const text = name => {
    if (!files.has(name)) throw new Error(`The backup is missing ${name}.`);
    return new TextDecoder().decode(files.get(name));
  };
  let manifest;
  try { manifest = JSON.parse(text('manifest.json')); }
  catch (err) { throw new Error('This ZIP is not a LOTO Procedure Manager full backup (' + err.message + ').'); }
  if (manifest.format !== 'loto-full-backup') throw new Error('This ZIP is not a LOTO Procedure Manager full backup.');
  if (Number(manifest.formatVersion) > 1) throw new Error('This backup was made by a newer version of the app and cannot be restored here.');

  const procData = JSON.parse(text((manifest.files && manifest.files.procedures) || 'procedures.json'));
  const procedures = cleanProcedures(Array.isArray(procData) ? procData : procData.procedures);
  const revName = (manifest.files && manifest.files.revisions) || 'revisions.json';
  const revisions = files.has(revName) ? JSON.parse(text(revName)).filter(r => r && r.id && r.procedureId) : [];

  const photos = [];
  const missing = [];
  (manifest.photos || []).forEach(m => {
    const data = files.get(m.file);
    if (!data) { missing.push(m.file); return; }
    photos.push({
      id: m.id, procedureId: m.procedureId, stepUid: m.stepUid || '', slot: m.slot || '',
      blob: new Blob([data], { type: m.mime || 'image/jpeg' }),
      mime: m.mime || 'image/jpeg', width: m.width, height: m.height,
      bytes: data.length, createdAt: m.createdAt || ''
    });
  });
  if (missing.length) throw new Error(`The backup is incomplete: ${missing.length} photo file(s) listed in the manifest are missing (first: ${missing[0]}).`);
  return { procedures, photos, revisions, exportedAt: manifest.exportedAt };
}

async function restoreBackup(file) {
  try {
    const head = new Uint8Array(await file.slice(0, 4).arrayBuffer());
    const isZip = head[0] === 0x50 && head[1] === 0x4b;
    const current = `${state.records.length} procedure(s) and ${state.photoStats.count} photo(s)`;

    if (isZip) {
      const data = await parseFullBackup(file);
      if (!confirm(
        `Restore this full backup${data.exportedAt ? ' from ' + fmtDateTime(data.exportedAt) : ''}?\n\n` +
        `It contains ${data.procedures.length} procedure(s), ${data.photos.length} photo(s) and ${data.revisions.length} revision record(s).\n\n` +
        `WARNING: this REPLACES everything stored in this browser — currently ${current}, plus revision history. ` +
        'Anything not in the backup is permanently deleted.\n\nMake a Full Backup first if you may need the current data.\n\nContinue?'
      )) return;
      await LotoDB.restoreAll(data);
    } else {
      const data = JSON.parse(await file.text());
      const records = cleanProcedures(Array.isArray(data) ? data : data.procedures);
      if (!confirm(
        `Restore ${records.length} procedure(s) from this JSON backup?\n\n` +
        `WARNING: this REPLACES the local database — currently ${current}. ` +
        'A JSON backup contains no photos: stored photos that the restored procedures do not reference are permanently deleted, along with revision history for procedures that are not in the backup.\n\n' +
        'Make a Full Backup first if you may need the current data.\n\nContinue?'
      )) return;
      await LotoDB.replaceAll(records);
    }
    await loadRecords();
  } catch (err) {
    const quota = err && (err.name === 'QuotaExceededError' || /quota/i.test(err.message || ''));
    alert('Could not restore backup: ' + (quota ? 'the browser does not have enough storage space. ' : '') + (err.message || err) +
      '\n\nNothing was changed — the existing local data is still in place.');
    try { await loadRecords(); } catch (e) { /* keep the current view */ }
  }
}

function wireEvents() {
  el('newProcedureBtn').addEventListener('click', () => openDrawer());
  el('emptyNewBtn').addEventListener('click', () => openDrawer());
  el('closeDrawerBtn').addEventListener('click', closeDrawer);
  el('cancelBtn').addEventListener('click', closeDrawer);
  el('drawerBackdrop').addEventListener('click', closeDrawer);
  el('procedureForm').addEventListener('submit', saveProcedure);
  el('buildStepsBtn').addEventListener('click', () => {
    if (confirm('Reset the visible step count? Existing step data beyond the selected count may be removed.')) {
      buildStepCount(el('startingSteps').value);
    }
  });
  el('addStepBtn').addEventListener('click', () => {
    const steps = currentSteps();
    steps.push(defaultStep(steps.length));
    setSteps(steps);
  });
  el('stepsContainer').addEventListener('click', handleStepClick);
  el('stepsContainer').addEventListener('input', evt => {
    if (evt.target.classList.contains('field-invalid')) evt.target.classList.remove('field-invalid');
  });
  el('validationPanel').addEventListener('click', evt => {
    if (!evt.target.closest('#saveAsDraftBtn')) return;
    el('lifecycleStatus').value = 'Draft';
    el('procedureForm').requestSubmit();
  });
  el('stepsContainer').addEventListener('change', evt => {
    if (evt.target.matches('[data-field="photoOrientation"], [data-field="verificationPhotoOrientation"]')) {
      refreshThumbs();
    }

    if (evt.target.matches('[data-field="energyType"]')) {
      autoNumberIsolationIds();
      applyDefaultVerification(evt.target.closest('.step-card'));
    }

    if (evt.target.matches('[data-field="verificationMethod"]')) {
      const card = evt.target.closest('.step-card');
      const preview = card.querySelector('.verification-method-preview');
      if (preview) preview.textContent = verificationText(evt.target.value);
    }

    if (evt.target.matches('[data-field="verificationPhotoMode"]')) {
      syncVerificationPhotoFields(evt.target.closest('.step-card'));
    }
  });
  el('procedureList').addEventListener('click', handleListClick);
  el('areaFilter').addEventListener('change', renderList);
  el('statusFilter').addEventListener('change', renderList);
  el('searchInput').addEventListener('input', renderList);
  el('sortField').addEventListener('change', applySort);
  el('sortDirBtn').addEventListener('click', () => {
    state.sort.dir = state.sort.dir === -1 ? 1 : -1;
    applySort();
  });
  el('closeHistoryBtn').addEventListener('click', closeHistory);

  el('exportRegisterBtn').addEventListener('click', () => LotoExport.exportRegisterCSV(state.records, getStatus));
  el('exportStepsBtn').addEventListener('click', () => LotoExport.exportStepsCSV(state.records));
  el('backupBtn').addEventListener('click', backupZip);
  el('restoreInput').addEventListener('change', evt => {
    const f = evt.target.files?.[0];
    if (f) restoreBackup(f);
    evt.target.value = '';
  });

  el('closePreviewBtn').addEventListener('click', closePreview);
  el('printPreviewBtn').addEventListener('click', () => window.print());
  el('downloadPngBtn').addEventListener('click', async () => {
    if (!state.previewing) return;
    try {
      await LotoExport.downloadPNG(state.previewing, state.previewAssets);
    } catch (err) {
      alert('Could not create PNG: ' + err.message);
    }
  });

  el('downloadSvgBtn').addEventListener('click', () => {
    if (state.previewing) LotoExport.downloadSVG(state.previewing, state.previewAssets);
  });
}

wireEvents();
loadSortPreference();
loadRecords().catch(err => {
  alert('The local database could not be opened: ' + (err && err.message ? err.message : err) +
    '\n\nYour data has not been changed. Close other tabs of this app and reload.');
});