LOTO Procedure Manager V2.4

Open index.html in a modern browser (current Chrome, Edge or Firefox).

The app is fully local. It needs no server, no internet connection, no CDN and no
external API. Everything it uses is in this folder.

Structure:
- index.html
- css/app.css
- js/db.js       local database (IndexedDB) and the version migration
- js/zip.js      small built-in ZIP reader/writer for full backups (no external library)
- js/photos.js   photo compression, photo editor, shared photo renderer
- js/export.js   preview / print / PNG / SVG / CSV output
- js/app.js      register, procedure editor, validation, revision history, backup/restore


============================================================
V2.4 — PHOTOS, FULL BACKUP, SORTING, VALIDATION, REVISIONS
============================================================

UPGRADING FROM V2.3
- Replace the old files with this folder and open index.html from the same location as
  before. The browser database is upgraded automatically the first time it opens
  (database version 1 -> 2). The upgrade only ADDS a photo store and a revision store.
  Existing procedures are not changed, moved or reset.
- Old "Backup JSON" files still restore (see BACKUP AND RESTORE).
- Make a Full Backup (ZIP) once the upgrade has opened correctly.
- Close other tabs running the old version before opening the new one.


PHOTOS ON PROCEDURE CARDS
- Each isolation step can have one photo on its lock card, and one on its verification
  card when "Create Separate Verification Card" is selected.
- Photos are optional. A card with no photo prints its text placeholder exactly as before.
- In the procedure editor, each step has a photo row: Add Photo / Edit Photo / Remove.
- The photo area follows the step's existing Photo Orientation setting:
  Landscape = 4:3, Portrait = 3:4. Changing the orientation keeps the photo and callouts.

Photo editor:
- Upload Photo / Replace Photo: choose a JPEG, PNG or WebP image.
  (iPhone HEIC photos must be converted or exported as JPEG first.)
- Reposition: drag the photo inside the frame.
- Zoom: mouse wheel or the Zoom slider (100% to 600%).
- Rotate Left / Rotate Right: 90-degree steps. Reset returns to the default crop.
- Callouts: + Arrow, + Circle, + Number. Drag a callout to move it. Drag the square
  handles to aim an arrow or resize a circle. Select a callout to set an optional short
  label (40 characters), its color, and for number markers the number.
  Delete Callout (or the Delete key) removes the selected callout.
- Callouts are anchored to the photo, so they stay on the equipment if you reposition,
  zoom or rotate the photo later.
- Apply keeps the changes in the open procedure. Nothing is written to the database
  until Save Procedure. Cancel discards the changes made in the editor.
- What you see inside the frame is exactly what appears in the procedure.

Output:
- Preview, Print, PNG and SVG all draw the photo with the same crop and the same
  callouts, using one shared renderer.
- Editor buttons, handles and selection outlines are never part of any output.
- SVG files embed the composed photo, so each SVG file is self-contained.

Compression:
- The original phone image is never stored. On import the photo is resized to at most
  1600 px on the long edge and saved as WebP (JPEG if the browser cannot write WebP).
- Target size is about 350 KB per photo. The editor shows the stored size and the
  stored image itself, so you can judge clarity before applying.
- Quality is not reduced below a fixed floor. If a photo cannot reach the target at
  that floor, the app says so and asks whether to keep it at the larger size or not add
  it. It does not silently produce an unclear image.
- A warning is shown for small source photos (under 800 px) that may print soft.
- Crop, zoom, rotation and callouts are stored as editable settings, not baked into the
  stored image, so they can be adjusted at any time.


STORAGE
- Procedures:  IndexedDB store "procedures" (unchanged).
- Photos:      IndexedDB store "photos" — compressed image Blobs, linked to the procedure
               and step by ID. Image data is not embedded in procedure records.
- Revisions:   IndexedDB store "revisions".
- The register never loads photos. Photos are read only for the one procedure being
  edited, previewed or exported, and for a full backup.
- Deleting a procedure deletes its photos and revision history.
- Duplicating a procedure or a step gives the copy its own photo records, so editing or
  replacing a photo on the copy never changes the original. A duplicated procedure
  starts as a Draft.
- Replacing or removing a photo deletes the old image when the procedure is saved.
- User photos are browser data on this computer. They are not part of the application
  folder and are never added to it. The application folder itself is under 1 MB.

Local Photo Storage meter (left panel):
- Shows the number of photos and their total size against a 24 MB photo-data budget.
- Warns at 80% of the budget and again when over it. The budget is a guide; the app
  asks for confirmation before a save that would go over it, but does not block it.
- "Browser estimate" is what the browser reports for used and available space. It is an
  estimate, not a guaranteed limit.
- If the browser refuses a save (storage full or any other error), the app says so and
  nothing is changed: the previously saved procedure and all stored photos stay intact,
  and the edit stays open so you can remove photos and try again.

Browser data is tied to this browser profile and to the location index.html is opened
from. Clearing site data / browsing data deletes it. Keep Full Backups.


BACKUP AND RESTORE
Full Backup (ZIP):
- One self-contained file: LOTO_Full_Backup_YYYY-MM-DD.zip containing
    manifest.json      backup format, counts, and the list of photo files
    procedures.json    all procedures incl. crop settings and callouts
                       (same layout as the old Backup JSON file)
    revisions.json     revision history
    photos/...         every stored photo as its own .webp / .jpg file
- Created entirely in the browser. Nothing is uploaded.

Restore Backup:
- Accepts a Full Backup ZIP, or a legacy Backup JSON from V2.x.
- A restore REPLACES the local data. The app shows what the backup contains and what
  will be replaced, and asks for confirmation first. Make a Full Backup before restoring
  if the current data may be needed.
- Full Backup ZIP: procedures, photos and revision history are all replaced by the
  backup's contents.
- Legacy JSON: procedures are replaced. A JSON backup has no photos, so stored photos
  that the restored procedures do not reference are deleted.
- The restore is all-or-nothing. If the file is damaged, incomplete or too large for
  the browser, nothing is changed.
- The ZIP is checked (checksums) when read. A ZIP that was unpacked and re-zipped with
  normal OS tools also restores in current Chrome, Edge and Firefox.


REGISTER
- Sort By: Area, Equipment Name, LOTO ID, or Next Inspection Due, ascending or
  descending (arrow button). Blank values sort last. The choice is remembered.
- Search and the Area / Status filters work as before.
- Each row shows its photo count. An Active procedure that would not pass the
  activation check shows an "Active — N items to fix" flag.
- History button: opens the revision history for that procedure.


ACTIVATION CHECK
- A procedure can only be saved as Active when every isolation step has an Energy Type,
  Device, Lock Location and Verification Method.
- If something is missing, the editor lists each step and item to fix, highlights the
  fields, and saves nothing. Fix the items, or choose "Save as Draft Instead".
- Draft and Retired procedures can be saved incomplete.
- Procedure Status (Active / Draft / Retired) and inspection status
  (Current / Due Soon / Overdue) remain separate, as before.


REVISION HISTORY
- Every save that changes a procedure records a revision: when it was saved, the Last
  Revision date, Reviewed By, the procedure status, an optional Revision Note, and a
  full copy of the procedure as saved.
- A procedure saved before V2.4 is kept as "Rev 1 — Baseline" the first time it is
  edited, so the earlier version is not overwritten.
- History > View shows any revision in the normal preview (print/PNG/SVG available).
- History > Load into Editor opens an older revision in the editor. Nothing changes
  until it is saved, and saving records a new revision.
- There is no approval workflow. Update Last Revision and Reviewed By as part of the
  edit; they are recorded with the revision.
- Old revisions keep their own crop and callout settings. If a photo was later replaced
  or removed, the old image is no longer stored and that card shows its placeholder,
  with a note in the preview.


OFFLINE USE
- Copy the whole folder to the computer and open index.html. No installation.
- Works from a local folder (file://) or from any static web host.
- All data stays in the browser on that computer. Use Full Backup (ZIP) to move data to
  another computer or browser, then Restore Backup there.


Other changes in V2.4:
- Steps CSV has two new columns at the end: Lock Photo Attached, Verification Photo
  Attached. Existing columns are unchanged.
- Fix: a step saved with a verification method name from an earlier version (for example
  "Control Panel / Try-Out") now opens in the editor on its closest current method.
  Previously the dropdown silently fell back to its first option.
- "Backup JSON" is replaced by "Full Backup (ZIP)".


============================================================
EARLIER VERSIONS
============================================================

V2 changes:
- Energy Type is now a dropdown.
- Isolation IDs are automatically generated by energy type.
  Example mixed sequence: E-1, G-1, E-2, CC-1.
- Each isolation step has a Landscape / Portrait photo placeholder selection.
- The selected photo orientation carries into preview, print, SVG, JSON, and Steps CSV.


V2 display patch:
- SVG export now measures the complete procedure and expands vertically so no content is clipped.
- A clear black border surrounds the entire finished procedure for easy Snipping Tool capture.
- The in-app preview also shows the finished document boundary.


V2 PNG export patch:
- Added Download 8.5x11 PNG as the primary image export.
- PNG dimensions are fixed at 2550 x 3300 pixels (Letter portrait at 300 DPI).
- This is intended for predictable insertion into Visio at exactly 8.5 x 11 inches.
- SVG export remains available as a secondary option.


V2 local PNG hotfix:
- Replaced SVG-to-canvas PNG conversion with a direct Canvas renderer.
- Fixes Chromium "Tainted canvases may not be exported" when running locally via file://.
- PNG remains fixed at 2550 x 3300 pixels (8.5 x 11 Letter portrait).
- Long procedures are automatically scaled to remain entirely visible on the page.


V2 PNG readability patch:
- Increased PNG text sizes throughout.
- Lockout Application Process now uses two columns.
- Re-Energization Process now uses two columns.
- Reduced vertical space pressure so the fixed 8.5 x 11 PNG does not need to shrink text as aggressively.


V2.1 update:
- Added controlled Verification Method dropdowns:
  Meter; Control Panel / Try-Out; Gauge / Pressure Check; Visual / Physical Check; Meter + Try-Out.
- Verification wording is generated automatically from the selected method.
- Verification can be Message Only or Photo + Message.
- Optional verification photo has independent Portrait / Landscape orientation and label.
- Added explicit Procedure Status: Active / Draft / Retired.
- Added register search for equipment, area, or LOTO ID.
- Existing V2 records remain usable; legacy verification text is mapped to the closest dropdown method when opened.
- CSV exports now include verification method/photo fields and procedure status.


V2.2 pagination update:
- Print/preview/export now uses true multi-page Letter layout.
- Maximum two isolation cards per page.
- Page 1 contains the full procedure header and Lockout Application Process.
- Continuation pages use a compact Area / Equipment / LOTO ID header.
- Verify Zero Energy, Re-Energization, and the authorization footer appear on the final page.
- PNG export creates one fixed 2550 x 3300 image per procedure page instead of shrinking the entire procedure.
- Multi-page PNG files are named Page_1_of_N, Page_2_of_N, etc.
- Magnitude remains a free-text field.


V2.2 PNG text hotfix:
- Fixed overlapping/crushed MAGNITUDE, DEVICE, and LOCK HERE text in downloaded PNG pages.
- Labels and values are now rendered separately with proper first-line spacing and value wrapping.
- Preview/layout/pagination logic is unchanged.


V2.3 output redesign:
- Isolation-step output cards were redesigned to be photo-first and less cramped.
- Main step cards now use a large open photo area with no inner photo box, fill, or outline.
- Step text is compressed into a simpler block:
  magnitude | device, LOCK HERE, and VERIFY.
- If a verification photo card is enabled, it exports as a separate companion card titled:
  VERIFY — [Step ID]
- Companion verification cards keep the photo separate from the main lock card instead of cramming it inside the same box.
- Pagination is now based on output cards, not just isolation steps.
- Verification card pairs are kept together when page space allows.
- Maximum two output cards per page remains in place.


V2.3 photo-placement hotfix:
- Main lock-card text is now anchored to the bottom of the card.
- Verification companion-card text is also anchored to the bottom.
- The open photo area automatically expands into all remaining space above the text.
- No photo fill, outline, or inner border was added.
- PNG rendering now follows the same bottom-anchored layout as the preview.
