RDS Dock Master — V0.2 Prototype
=================================

HOW TO RUN
1. Unzip this folder.
2. Double-click index.html to open in Chrome or Edge.
3. Open "Facility setup" to select equipment policy, responsible roles,
   presentation mode, and which site hazards to emphasize.
4. Choose "Save & start training".
5. Run five scenarios. Choose actions in whatever order makes sense, click
   objects in the picture to inspect them, and click hazards to call them out.

CONTENTS
- index.html: Entire offline application, including SVG illustration and scripts.
- README.txt: These instructions.

FEATURES
- Five visually represented dock scenarios. Mechanical-restraint and
  chock-based sites each get their own versions of Scenarios 2 and 3.
- Judgment-based scoring: actions have prerequisites rather than one fixed
  order. Unsafe choices and premature choices are scored separately, and
  conservative choices (like taking a door out of service) are never penalized.
- Hazard recognition: hazards selected in setup appear in the scenes and
  must be found and called out before work can start.
- Action buttons are shuffled each run, so screen order isn't the answer.
- Instructor-led mode (larger text, group discussion prompts) or individual
  mode (hint button).
- Setup flags contradictory or inactive selections as you change them.
- Local browser storage for facility settings (browser permitting).
  Settings saved by V0 are carried over automatically.
- Import/export facility configuration as JSON.
- Printable practice record with a per-scenario summary and full decision log.
- No external libraries, remote images, CDNs, or internet requirement.

IMPORTANT LIMITATIONS
- Illustrations are schematic and do not represent a specific product or site.
- Some scenario steps are demonstration logic, not a validated safe work procedure.
- Facility configurations MUST be reviewed against approved site procedures,
  regulations, and equipment manufacturer instructions prior to use for training.
- Some combinations of selections are illustrative and may not correspond to
  a legally sufficient securing method. Do not use them to justify work.
- This simulation is not a substitute for site-specific practical evaluation.
- All completion records are PRACTICE records, not certifications.
