RDS Dock Master — V0 Prototype
===============================

HOW TO RUN
1. Unzip this folder.
2. Double-click index.html to open in Chrome or Edge.
3. Open "Facility setup" to select equipment policy, responsible roles,
   presentation mode, and which site hazards to emphasize.
4. Choose "Save & start training".
5. Run five scenarios. Use the action buttons or click certain dock objects.

CONTENTS
- index.html: Entire offline application, including SVG illustration and scripts.
- README.txt: These instructions.

FEATURES
- Five guided, visually represented dock restraint scenarios.
- Local browser storage for facility settings (browser permitting).
- Import/export facility configuration as JSON.
- Instructor-led or individual presentation setting.
- On-screen visual status, action feedback, decision history, and practice record.
- No external libraries, remote images, CDNs, or internet requirement.

IMPORTANT V0 LIMITATIONS
- Illustrations are schematic and do not represent a specific product or site.
- Some scenario steps are demonstration logic, not a validated safe work procedure.
- Facility configurations MUST be reviewed against approved site procedures,
  regulations, and equipment manufacturer instructions prior to use for training.
- Some combinations of selections are illustrative and may not correspond to
  a legally sufficient securing method. Do not use them to justify work.
- This simulation is not a substitute for site-specific practical evaluation.
- All completion records are PRACTICE records, not certifications.
