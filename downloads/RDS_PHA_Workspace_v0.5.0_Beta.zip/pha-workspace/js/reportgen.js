/* reportgen.js: builds the formal PHA report as HTML from the project record. No DOM, no storage, so it is tested in
   tests.html. It never prints an application screen: every line comes from the records.
   Integrity rules: incomplete work is named, draft records are labelled as drafts, and a partly finished study is
   never described as a completed PHA. */
(function () {
  'use strict';
  var PHA = window.PHA, store = PHA.store, R = PHA.review, C = PHA.calc;

  var SECTIONS = [
    { key: 'cover', label: 'Cover page and study identification', on: true },
    { key: 'scope', label: 'Purpose, scope, objectives and exclusions', on: true },
    { key: 'team', label: 'Team members and study dates', on: true },
    { key: 'method', label: 'Methodology and risk matrix', on: true },
    { key: 'nodes', label: 'Node register', on: true },
    { key: 'intent', label: 'Node design intent and parameters', on: true },
    { key: 'devsum', label: 'Deviation review summary', on: true },
    { key: 'detail', label: 'Detailed scenarios', on: true },
    { key: 'risktable', label: 'Consequences, safeguards and risk rankings', on: true },
    { key: 'recs', label: 'Consolidated recommendations', on: true },
    { key: 'completion', label: 'Study completion and outstanding items', on: true },
    { key: 'oplimits', label: 'Operating limits and Process Safety Time (optional)', on: false },
    { key: 'appendix', label: 'Annotated P&ID appendix (optional, landscape pages)', on: false }
  ];

  function vals(o) { return Object.keys(o || {}).map(function (k) { return o[k]; }); }
  function h(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function hp(v) { return h(v).replace(/\r?\n/g, '<br>'); }                 // keeps the line breaks the team typed
  function txt(v) { return String(v == null ? '' : v).trim(); }
  function nr(v, what) { return txt(v) ? hp(v) : '<span class="nr">' + h(what || 'Not recorded') + '</span>'; }
  function date(t) {
    if (!t) return '';
    var d = /^\d{4}-\d{2}-\d{2}$/.test(t) ? new Date(t + 'T12:00:00') : new Date(t);
    return isNaN(d) ? h(t) : d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  }
  function byId(a, b) { return (a.displayId || '').localeCompare(b.displayId || '', undefined, { numeric: true }); }
  function nodesSorted(p) { return vals(p.nodes).sort(byId); }
  function nodeLabel(n) { return n ? h(n.displayId) + (n.name ? ' ' + h(n.name) : '') : 'Unknown node'; }
  function badge(k) { return k ? '<span class="rk" style="background:' + h(k.color) + '">' + h(k.label) + (k.score != null ? ' ' + k.score : '') + '</span>' : '<span class="rk none">Not ranked</span>'; }
  var ST_LABEL = { open: 'DRAFT', verify: 'PENDING VERIFICATION', reviewed: 'REVIEWED' };
  function stBadge(sc) { var s = R.scState(sc); return '<span class="st st-' + s + '">' + ST_LABEL[s] + '</span>'; }
  var DEV_LABEL = { yes: 'Yes: applicable', no: 'No: not applicable', 'not-reviewed': 'NOT REVIEWED' };

  function riskText(p, sc) {
    var n = p.nodes[sc.nodeId];
    if (!C.moduleEnabled(p, n, 'riskMatrix')) return { u: '<span class="nr">Risk matrix not used for this node</span>', m: '' };
    if ((sc.riskStatus || {}).status === 'not-applicable') return { u: 'Not applicable' + (sc.riskStatus.reason ? ': ' + h(sc.riskStatus.reason) : ' <span class="nr">(no reason recorded)</span>'), m: '' };
    return { u: badge(store.scenarioRisk(p, sc, 'unmitigated')), m: badge(store.scenarioRisk(p, sc, 'mitigated')) };
  }

  /* ---------- sections ---------- */

  function cover(p, ctx) {
    var pr = p.project, s = ctx.sum;
    var state = ctx.complete
      ? '<div class="state ok">The recorded analysis is complete: every recorded deviation is decided and every scenario is marked reviewed.' + (s.openRecs ? ' ' + s.openRecs + ' recommendation(s) remain open for follow-up.' : '') + '</div>'
      : '<div class="state draft"><b>DRAFT: STUDY INCOMPLETE.</b> This report is not a completed PHA. ' + ctx.openItems + ' outstanding item(s) are listed in "Study completion and outstanding items".</div>';
    var statusNote = (pr.status === 'completed' && !ctx.complete) ? '<div class="state warn">The project status is set to Completed, but the study records show outstanding work. The records take precedence.</div>' : '';
    return '<section class="cover">' +
      '<div class="cv-kicker">Process Hazard Analysis</div>' +
      '<h1 class="cv-title">' + nr(pr.name, 'Untitled study') + '</h1>' +
      '<table class="kv cv-kv"><tbody>' +
      '<tr><th>Facility</th><td>' + nr(pr.facility) + '</td></tr>' +
      '<tr><th>Study type</th><td>' + nr(pr.studyType) + '</td></tr>' +
      '<tr><th>Methodology</th><td>' + nr(pr.method) + '</td></tr>' +
      '<tr><th>Report revision</th><td>' + nr(pr.revision) + '</td></tr>' +
      '<tr><th>Project status</th><td>' + h((store.PROJECT_STATUSES.filter(function (x) { return x[0] === pr.status; })[0] || [0, pr.status])[1]) + '</td></tr>' +
      '<tr><th>Study ID</th><td class="mono">' + h(pr.id) + '</td></tr>' +
      '<tr><th>Report generated</th><td>' + h(ctx.generated) + '</td></tr>' +
      '<tr><th>Nodes / scenarios</th><td>' + vals(p.nodes).length + ' nodes, ' + s.scenarios + ' scenarios (' + s.reviewed + ' reviewed, ' + s.verify + ' pending verification, ' + s.draft + ' draft)</td></tr>' +
      '</tbody></table>' + state + statusNote +
      '<p class="cv-foot">Generated by PHA Workspace ' + h(store.APP_VERSION) + ' from the study records. Engineering values, limits and rankings are as entered by the study team; the application does not supply or validate them.</p>' +
      '</section>';
  }

  function scopeSec(p, n) {
    var pr = p.project;
    return sec(n, 'Purpose, scope, objectives and exclusions',
      '<h3>Purpose</h3><p>' + nr(pr.purpose) + '</p><h3>Scope</h3><p>' + nr(pr.scope) + '</p>' +
      '<h3>Objectives</h3><p>' + nr(pr.objectives) + '</p><h3>Exclusions</h3><p>' + nr(pr.exclusions) + '</p>' +
      (pr.assumptions.length ? '<h3>Assumptions</h3><table class="grid"><thead><tr><th>Assumption</th><th class="w-st">Status</th></tr></thead><tbody>' +
        pr.assumptions.filter(function (a) { return txt(a.text); }).map(function (a) {
          return '<tr><td>' + hp(a.text) + '</td><td>' + (a.status === 'confirmed' ? 'Confirmed' : a.status === 'closed' ? 'Withdrawn' : '<b class="flag">Open: to be confirmed</b>') + '</td></tr>';
        }).join('') + '</tbody></table>' : ''), 'flow');
  }

  function teamSec(p, n) {
    var team = p.project.team.filter(function (t) { return txt(t.name); });
    var ses = (p.sessions || []).filter(function (s) { return txt(s.date); }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    return sec(n, 'Team members and study dates',
      '<h3>Team</h3>' + (team.length ? '<table class="grid"><thead><tr><th>Name</th><th>Study role</th><th>Discipline / company</th></tr></thead><tbody>' +
        team.map(function (t) { return '<tr><td>' + h(t.name) + '</td><td>' + nr(t.role, '') + '</td><td>' + nr(t.discipline, '') + '</td></tr>'; }).join('') + '</tbody></table>'
        : '<p><span class="nr">No team members recorded.</span></p>') +
      '<h3>Study sessions</h3>' + (ses.length ? '<table class="grid"><thead><tr><th class="w-date">Date</th><th>Notes</th></tr></thead><tbody>' +
        ses.map(function (s) { return '<tr><td>' + date(s.date) + '</td><td>' + nr(s.note, '') + '</td></tr>'; }).join('') + '</tbody></table>'
        : '<p><span class="nr">No session dates recorded.</span></p>'), 'flow');
  }

  function matrixTable(p) {
    var m = p.project.riskMatrix, out = '<table class="matrix"><thead><tr><th>Likelihood \\ Severity</th>' +
      m.severity.map(function (s) { return '<th>' + h(s.label) + '</th>'; }).join('') + '</tr></thead><tbody>';
    for (var li = m.likelihood.length - 1; li >= 0; li--) {
      out += '<tr><th>' + h(m.likelihood[li].label) + '</th>';
      for (var si = 0; si < m.severity.length; si++) {
        var k = store.riskOf(p, { s: m.severity[si].v, l: m.likelihood[li].v });
        out += '<td style="background:' + h(k.color) + '">' + h(k.label) + (k.score != null ? '<br><small>' + k.score + '</small>' : '') + '</td>';
      }
      out += '</tr>';
    }
    return out + '</tbody></table>';
  }

  function methodSec(p, n) {
    var pr = p.project, m = pr.riskMatrix;
    var rule = m.rule === 'table'
      ? 'Each severity and likelihood combination is assigned a risk band directly in the matrix table below. No arithmetic is used.'
      : 'The risk score is the severity value multiplied by the likelihood value, compared with each band\'s lowest score: ' +
        m.bands.slice().sort(function (a, b) { return b.min - a.min; }).map(function (b) { return h(b.label) + ' from ' + h(b.min); }).join(', ') + '.';
    var placeholder = !txt(m.source) ? '<div class="state warn">No source reference is recorded for this risk matrix.' + (m.note ? ' It may still be the application\'s placeholder matrix (' + h(m.note) + ').' : '') + '</div>' : '';
    var bands = m.bands.map(function (b) { return '<tr><td><span class="rk" style="background:' + h(b.color) + '">' + h(b.label) + '</span></td><td>' + nr(b.action, 'No requirement recorded') + '</td></tr>'; }).join('');
    var mods = C.MODULES.map(function (x) { return h(x.label) + ': ' + (pr.modules[x.key] ? 'on' : 'off'); }).join('; ');
    return sec(n, 'Methodology and risk matrix',
      '<table class="kv"><tbody><tr><th>Methodology</th><td>' + nr(pr.method) + '</td></tr>' +
      '<tr><th>Guidewords</th><td>' + h(pr.guidewords.join(', ')) + '</td></tr>' +
      '<tr><th>Process parameters</th><td>' + h(pr.parameters.join(', ')) + '</td></tr>' +
      '<tr><th>Deviation review</th><td>Each deviation considered for a node is recorded as Yes (applicable), No (not applicable, with the technical basis) or Not reviewed (outstanding). An applicable deviation is either analysed as one or more scenarios, or dispositioned with a documented finding that no credible hazardous scenario was identified, or a reference to where it is covered.</td></tr>' +
      '<tr><th>Scenario structure</th><td>Initiating cause, deviation, failure sequence (mechanism), hazardous event (for example loss of containment), then the ultimate consequences with any escalation conditions. A recorded mechanism describes what may happen; it does not assert that each step occurs.</td></tr>' +
      '<tr><th>Quick-Add wording</th><td>Cause and consequence wording may be inserted from template libraries. Inserted wording is marked until the team confirms it; a template does not establish that a cause or consequence is credible.</td></tr>' +
      '<tr><th>Risk ranking</th><td>' + (m.rankBy === 'consequence' ? 'Each consequence is ranked separately; a scenario is shown at its highest ranked consequence.' : 'One ranking per scenario, without and with existing safeguards.') + '</td></tr>' +
      (m.categories.length ? '<tr><th>Consequence categories</th><td>' + h(m.categories.join(', ')) + '</td></tr>' : '') +
      '<tr><th>Matrix source</th><td>' + nr(m.source) + '</td></tr>' +
      '<tr><th>Project module defaults</th><td>' + mods + '</td></tr></tbody></table>' + placeholder +
      '<h3>Ranking rule</h3><p>' + rule + '</p>' + matrixTable(p) +
      '<h3>Risk bands and risk-reduction requirements</h3><table class="grid"><thead><tr><th class="w-band">Band</th><th>Requirement</th></tr></thead><tbody>' + bands + '</tbody></table>' +
      '<p class="note">Safeguards are listed as identified by the team. Listing a safeguard does not by itself establish that it is effective or independent' +
      (pr.modules.safeguardEvaluation ? '; where the safeguard evaluation was recorded it is shown with the safeguard.' : '.') + '</p>');
  }

  function nodeRegister(p, n) {
    var rows = nodesSorted(p).map(function (nd) {
      var dw = {};
      nd.regions.forEach(function (r) { var d = p.drawings[r.drawingId]; if (d) dw[d.id] = (d.number || d.file.name) + (d.revision ? ' Rev ' + d.revision : ''); });
      var tags = nd.equipmentIds.map(function (id) { return p.equipment[id] && p.equipment[id].tag; }).filter(Boolean);
      var s = R.summary(p, nd.id);
      return '<tr><td class="b">' + h(nd.displayId) + '</td><td>' + nr(nd.name, 'Unnamed') + '</td><td>' + (vals(dw).map(h).join('<br>') || '<span class="nr">No region on a drawing</span>') + '</td><td>' + h(tags.join(', ')) +
        '</td><td class="num">' + s.decided + '/' + s.deviations + '</td><td class="num">' + s.reviewed + '/' + s.scenarios + '</td><td>' + (s.complete ? 'Complete' : '<b class="flag">Open</b>') + '</td></tr>';
    }).join('');
    return sec(n, 'Node register', '<table class="grid"><thead><tr><th class="w-id">Node</th><th>Name</th><th>Drawings</th><th>Equipment</th><th class="num">Deviations decided</th><th class="num">Scenarios reviewed</th><th class="w-st">Status</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="7"><span class="nr">No nodes recorded.</span></td></tr>') + '</tbody></table>');
  }

  function intentSec(p, n) {
    var body = nodesSorted(p).map(function (nd) {
      var params = {};
      store.nodeDeviations(p, nd.id).forEach(function (d) { if (d.parameter) params[d.parameter] = true; });
      var ops = store.byNode(p.opParams, nd.id);
      return '<div class="keep blk"><h3>' + nodeLabel(nd) + '</h3><table class="kv"><tbody>' +
        '<tr><th>Design intent</th><td>' + nr(nd.designIntent) + '</td></tr>' +
        '<tr><th>Process parameters reviewed</th><td>' + (Object.keys(params).length ? h(Object.keys(params).join(', ')) : '<span class="nr">No deviations recorded</span>') + '</td></tr>' +
        (ops.length ? '<tr><th>Operating parameters recorded</th><td>' + ops.map(function (o) {
          var v = o.values, rng = (txt(v.normalMin) || txt(v.normalMax)) ? ' normal ' + h(v.normalMin || '?') + ' to ' + h(v.normalMax || '?') + ' ' + h(o.unit) : '';
          return h(o.name || o.measurement || 'Parameter') + (o.tag ? ' (' + h(o.tag) + ')' : '') + rng;
        }).join('<br>') + '</td></tr>' : '') + '</tbody></table></div>';
    }).join('');
    return sec(n, 'Node design intent and parameters', body || '<p><span class="nr">No nodes recorded.</span></p>', 'flow');
  }

  function devSummary(p, n) {
    var body = nodesSorted(p).map(function (nd) {
      var devs = store.nodeDeviations(p, nd.id).sort(function (a, b) { return (a.parameter + a.guideword).localeCompare(b.parameter + b.guideword); });
      if (!devs.length) return '<h3>' + nodeLabel(nd) + '</h3><p><span class="nr">No deviations recorded for this node.</span></p>';
      return '<h3>' + nodeLabel(nd) + '</h3><table class="grid dev"><thead><tr><th class="w-par">Parameter</th><th class="w-gw">Guideword</th><th>Deviation</th><th class="w-dec">Applicable?</th><th>Basis / disposition</th><th class="w-sc">Scenarios</th><th class="w-st">Completion</th></tr></thead><tbody>' +
        devs.map(function (d) {
          var st = R.devState(p, d);
          var basis = d.status === 'no' ? nr(d.reason, 'Basis not recorded') : d.status === 'yes' && !st.scenarios.length ?
            (d.dispositionType ? '<b>' + (d.dispositionType === 'no-credible-scenario' ? 'No credible hazardous scenario identified' : 'Covered elsewhere') + ':</b> ' + nr(d.disposition, 'Finding not written') : '<span class="nr">No disposition recorded</span>') : '';
          if (d.origin === 'upgrade') basis += (basis ? '<br>' : '') + '<i class="small">Record created from an earlier scenario when the project was upgraded; decision not separately recorded.</i>';
          return '<tr class="' + (st.complete ? '' : 'open') + '"><td>' + h(d.parameter) + '</td><td>' + h(d.guideword) + '</td><td class="b">' + nr(d.text, 'No wording') + '</td><td>' +
            (d.status === 'not-reviewed' ? '<b class="flag">NOT REVIEWED</b>' : h(DEV_LABEL[d.status])) + '</td><td>' + basis + '</td><td>' + st.scenarios.map(function (x) { return h(x.displayId); }).join(', ') +
            '</td><td>' + (st.complete ? 'Complete' : '<b class="flag">' + h(st.label) + '</b>') + '</td></tr>';
        }).join('') + '</tbody></table>';
    }).join('');
    var s = R.summary(p, null);
    return sec(n, 'Deviation review summary', '<p>' + R.summaryLines(s).map(h).join(' ') + '</p>' + body);
  }

  /* 0.5.0 */
  function itemFlags(x) {
    var out = '';
    if (x.review) out += ' <i class="flag small">(converted text, flagged for checking)</i>';
    if (x.teamStatus === 'pending') out += ' <i class="flag small">(inserted from the Quick-Add library; not confirmed by the team)</i>';
    var holes = PHA.library ? PHA.library.unfilled(x) : [];
    if (holes.length) out += ' <i class="flag small">(placeholder not filled: ' + holes.map(function (n) { return '[' + h(n) + ']'; }).join(', ') + ')</i>';
    return out;
  }
  function seqHtml(sc) {
    var q = sc.sequence || {};
    if (q.direct && !txt(q.event)) return '<p class="small">No intermediate mechanism: the team recorded that the consequences follow directly from the deviation.</p>';
    if (!txt(q.mechanism) && !txt(q.event)) return '<p><span class="nr">Not recorded</span></p>';
    return (txt(q.mechanism) && !q.direct ? '<p class="seq">' + hp(q.mechanism) + '</p>' : '') +
      (txt(q.event) ? '<p class="seq"><b>' + (q.eventType === 'loc' ? 'Loss of containment' : q.eventType === 'other' ? 'Other hazardous event' : 'Hazardous event') + ':</b> ' + hp(q.event) + '</p>' : '');
  }

  function scenarioBlock(p, sc) {
    var cIdx = {};
    sc.causes.forEach(function (c, i) { cIdx[c.id] = 'C' + (i + 1); });
    var causes = sc.causes.filter(function (c) { return txt(c.text); });
    var csqs = sc.consequences.filter(function (c) { return txt(c.text); });
    var sfgs = sc.safeguardIds.map(function (id) { return p.safeguards[id]; }).filter(Boolean);
    var recs = sc.recommendationIds.map(function (id) { return p.recommendations[id]; }).filter(Boolean);
    var perCsq = p.project.riskMatrix.rankBy === 'consequence';
    var size = (sc.deviation || '').length + (sc.notes || '').length + ((sc.sequence || {}).mechanism || '').length + ((sc.sequence || {}).event || '').length;
    causes.concat(csqs).forEach(function (x) { size += x.text.length + 60; });
    sfgs.forEach(function (g) { size += (g.description || '').length + 60; });
    recs.forEach(function (r) { size += (r.text || '').length + 80; });
    var risk = riskText(p, sc);
    var list = function (arr, f, empty) { return arr.length ? '<ol>' + arr.map(function (x, i) { return '<li>' + f(x, i) + '</li>'; }).join('') + '</ol>' : '<p><span class="nr">' + empty + '</span></p>'; };
    var html = '<div class="scn' + (size < 1400 ? ' keep' : '') + ' scn-' + R.scState(sc) + '">' +
      '<div class="scn-head"><span class="scn-id">' + h(sc.displayId) + '</span><span class="scn-dev">' + nr(sc.deviation, 'No deviation stated') + '</span><span class="scn-pg">' + h([sc.parameter, sc.guideword].filter(Boolean).join(' / ')) + '</span>' + stBadge(sc) + '</div>' +
      '<div class="scn-body"><div class="scn-col"><h4>Initiating causes</h4>' + list(causes, function (c) { return hp(c.text) + itemFlags(c); }, 'No causes recorded') +
      '<h4>Failure sequence</h4>' + seqHtml(sc) +
      '<h4>Consequences</h4>' + list(csqs, function (q) {
        var tags = [];
        if (q.causeIds && q.causeIds.length && causes.length > 1) tags.push('from ' + q.causeIds.map(function (id) { return cIdx[id]; }).filter(Boolean).join(', '));
        if (q.category) tags.push(h(q.category));
        if (txt(q.escalation)) tags.push('if: ' + h(q.escalation));
        var rk = perCsq && q.risk ? ' ' + badge(store.riskOf(p, q.risk.unmitigated)) + ' &rarr; ' + badge(store.riskOf(p, q.risk.mitigated)) : '';
        return hp(q.text) + (tags.length ? ' <span class="tagx">' + tags.join('; ') + '</span>' : '') + rk + itemFlags(q);
      }, 'No consequences recorded') + '</div>' +
      '<div class="scn-col"><h4>Existing safeguards</h4>' + list(sfgs, function (g) {
        var ev = g.evaluation || {}, bits = [];
        if (g.role) bits.push(g.role === 'preventive' ? 'Preventive' : 'Mitigative');
        if (g.type) bits.push(h(g.type));
        if (ev.status === 'applicable') {
          var t = C.criteriaTally(ev);
          bits.push('evaluated: ' + t.yes + ' yes / ' + t.no + ' no / ' + t.open + ' open' + (ev.credited ? '; ' + (ev.credited === 'yes' ? 'credited by the team' : 'not credited') : ''));
        } else if (ev.status === 'not-applicable') bits.push('evaluation not applicable');
        else bits.push('effectiveness not evaluated');
        return nr(g.description, 'No description') + ' <span class="tagx">' + bits.join('; ') + '</span>';
      }, 'No safeguards recorded') +
      '<h4>Risk ranking' + (perCsq ? ' (highest consequence)' : '') + '</h4><p class="rkline">Without safeguards ' + risk.u + (risk.m ? ' &nbsp; With safeguards ' + risk.m : '') + '</p>' +
      (function () { var k = store.scenarioRisk(p, sc, 'mitigated') || store.scenarioRisk(p, sc, 'unmitigated'); return k && txt(k.action) ? '<p class="small">' + h(k.label) + ' requirement: ' + h(k.action) + '</p>' : ''; })() +
      '<h4>Recommendations</h4>' + (recs.length ? '<ul class="recl">' + recs.map(function (r) {
        return '<li><b>' + h(r.displayId) + '</b> ' + nr(r.text, 'No text') + ' <span class="tagx">' + (r.status === 'closed' ? 'Closed' : 'Open') + (r.assignee ? '; ' + h(r.assignee) : '') + (r.due ? '; due ' + date(r.due) : '') + '</span></li>';
      }).join('') + '</ul>' : '<p><span class="muted-p">None</span></p>') + '</div></div>' +
      (txt(sc.notes) ? '<div class="scn-notes"><b>Discussion notes:</b> ' + hp(sc.notes) + '</div>' : '') +
      '</div>';
    return html;
  }

  function detailSec(p, n, opts) {
    var nodes = nodesSorted(p), out = '';
    nodes.forEach(function (nd, i) {
      var scs = store.nodeScenarios(p, nd.id).sort(byId);
      if (opts.reviewedOnly) scs = scs.filter(function (s) { return R.scState(s) === 'reviewed'; });
      var s = R.summary(p, nd.id);
      out += '<div class="node-sec' + (i === 0 ? ' first' : '') + '"><h3 class="node-h" style="border-left-color:' + h(nd.color) + '">' + nodeLabel(nd) + '</h3>' +
        '<p class="small">' + R.summaryLines(s).map(h).join(' ') + '</p>' +
        (txt(nd.designIntent) ? '<p class="small"><b>Design intent:</b> ' + hp(nd.designIntent) + '</p>' : '') +
        (scs.length ? scs.map(function (sc) { return scenarioBlock(p, sc); }).join('') : '<p><span class="nr">No scenarios' + (opts.reviewedOnly ? ' marked reviewed' : '') + ' for this node.</span></p>') + '</div>';
    });
    var excluded = opts.reviewedOnly ? vals(p.scenarios).filter(function (s) { return R.scState(s) !== 'reviewed'; }).length : 0;
    return sec(n, 'Detailed scenarios', (excluded ? '<div class="state warn">' + excluded + ' scenario(s) not yet reviewed are left out of this section by the report option "Reviewed scenarios only". They are listed under outstanding items.</div>' : '') +
      (out || '<p><span class="nr">No nodes recorded.</span></p>'), 'detail');
  }

  function riskTableSec(p, n) {
    var rows = nodesSorted(p).map(function (nd) {
      return store.nodeScenarios(p, nd.id).sort(byId).map(function (sc) {
        var r = riskText(p, sc);
        var sfgs = sc.safeguardIds.map(function (id) { return p.safeguards[id]; }).filter(Boolean);
        return '<tr><td class="b">' + h(sc.displayId) + '</td><td>' + h(nd.displayId) + '</td><td>' + nr(sc.deviation, '') + '</td><td>' +
          sc.consequences.filter(function (q) { return txt(q.text); }).map(function (q) { return hp(q.text); }).join('<br>') + '</td><td>' +
          sfgs.map(function (g) { return h(g.description) + (g.role ? ' (' + (g.role === 'preventive' ? 'P' : 'M') + ')' : ''); }).join('<br>') + '</td><td>' + r.u + '</td><td>' + r.m + '</td><td>' + stBadge(sc) + '</td></tr>';
      }).join('');
    }).join('');
    return sec(n, 'Consequences, safeguards and risk rankings',
      '<p class="small">P = preventive, M = mitigative, as recorded by the team. Rankings use the study matrix described under Methodology.</p>' +
      '<table class="grid small rt"><thead><tr><th class="w-id">Scenario</th><th class="w-id">Node</th><th>Deviation</th><th>Consequences</th><th>Safeguards</th><th class="w-rk">Without safeguards</th><th class="w-rk">With safeguards</th><th class="w-st">Status</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="8"><span class="nr">No scenarios recorded.</span></td></tr>') + '</tbody></table>');
  }

  function recsSec(p, n) {
    var where = {};
    vals(p.scenarios).forEach(function (sc) { sc.recommendationIds.forEach(function (id) { (where[id] = where[id] || []).push(sc); }); });
    var recs = vals(p.recommendations).sort(byId);
    var open = recs.filter(function (r) { return r.status !== 'closed'; }).length;
    return sec(n, 'Consolidated recommendations', '<p>' + recs.length + ' recommendation(s): ' + open + ' open, ' + (recs.length - open) + ' closed.</p>' +
      '<table class="grid small"><thead><tr><th class="w-id">ID</th><th>Recommendation</th><th class="w-src">Scenario / node</th><th class="w-rk">Scenario risk (with safeguards)</th><th>Assigned to</th><th class="w-date">Due</th><th class="w-st">Status</th></tr></thead><tbody>' +
      (recs.map(function (r) {
        var scs = where[r.id] || [];
        return '<tr><td class="b">' + h(r.displayId) + '</td><td>' + nr(r.text, 'No text') + '</td><td>' + (scs.map(function (sc) { return h(sc.displayId) + ' (' + h((p.nodes[sc.nodeId] || {}).displayId || '') + ')'; }).join('<br>') || '<span class="nr">Not linked</span>') +
          '</td><td>' + scs.map(function (sc) { return riskText(p, sc).m || riskText(p, sc).u; }).join('<br>') + '</td><td>' + nr(r.assignee, '') + '</td><td>' + date(r.due) + '</td><td>' + (r.status === 'closed' ? 'Closed' : '<b>Open</b>') + '</td></tr>';
      }).join('') || '<tr><td colspan="7"><span class="nr">No recommendations recorded.</span></td></tr>') + '</tbody></table>');
  }

  var OUT_HEAD = { deviation: 'Deviations not reviewed or without recorded analysis', verify: 'Scenarios awaiting verification', draft: 'Draft scenarios not yet reviewed',
    risk: 'Missing risk rankings', pending: 'Quick-Add items awaiting team confirmation', recommendation: 'Open recommendations', assumption: 'Outstanding assumptions', migration: 'Converted text flagged for checking', info: 'Missing supporting information' };
  function completionSec(p, n, ctx) {
    var s = ctx.sum, groups = {};
    ctx.out.forEach(function (o) { (groups[o.kind] = groups[o.kind] || []).push(o); });
    var body = '<table class="kv"><tbody>' +
      '<tr><th>Analysis state</th><td>' + (ctx.complete ? 'Complete: every recorded deviation is decided and every scenario is reviewed.' : '<b class="flag">Incomplete: see the items below.</b>') + '</td></tr>' +
      '<tr><th>Deviations</th><td>' + s.deviations + ' recorded; ' + s.decided + ' decided (' + s.applicable + ' applicable, ' + s.notApplicable + ' not applicable); ' + s.notReviewed + ' not reviewed.</td></tr>' +
      '<tr><th>Scenarios</th><td>' + s.scenarios + ' recorded; ' + s.reviewed + ' reviewed, ' + s.verify + ' pending verification, ' + s.draft + ' draft.</td></tr>' +
      '<tr><th>Recommendations</th><td>' + s.recs + ' recorded; ' + s.openRecs + ' open.</td></tr>' +
      (s.fromUpgrade ? '<tr><th>Upgraded records</th><td>' + s.fromUpgrade + ' deviation review record(s) were created from earlier scenarios when the project was upgraded and have no separately recorded decision.</td></tr>' : '') +
      '</tbody></table>' +
      '<p class="small">Counts are taken from the study records only. Deviations that were never recorded for a node are not counted; the team is responsible for deciding which deviations each node requires.</p>';
    Object.keys(OUT_HEAD).forEach(function (k) {
      if (!groups[k]) return;
      body += '<h3>' + h(OUT_HEAD[k]) + ' (' + groups[k].length + ')</h3><ul class="olist">' + groups[k].map(function (o) { return '<li>' + h(o.text) + '</li>'; }).join('') + '</ul>';
    });
    if (!ctx.out.length) body += '<p>No outstanding items were found in the records.</p>';
    return sec(n, 'Study completion and outstanding items', body);
  }

  function opSec(p, n) {
    var body = '';
    nodesSorted(p).forEach(function (nd) {
      var ops = store.byNode(p.opParams, nd.id), psts = store.byNode(p.pst, nd.id);
      if (!ops.length && !psts.length) return;
      body += '<h3>' + nodeLabel(nd) + '</h3>';
      if (ops.length) {
        body += '<table class="grid small"><thead><tr><th>Parameter</th><th>Unit</th>' + C.OP_LEVELS.map(function (l) { return '<th class="num">' + h(l.short) + '</th>'; }).join('') + '<th>Source</th></tr></thead><tbody>' +
          ops.map(function (o) {
            var checks = C.checkOpParam(o).filter(function (c) { return c.level !== 'info'; });
            return '<tr><td>' + h(o.name || o.measurement) + (o.tag ? '<br><small>' + h(o.tag) + '</small>' : '') + (checks.length ? '<br><b class="flag small">' + checks.map(function (c) { return h(c.msg); }).join(' ') + '</b>' : '') + '</td><td>' + h(o.unit) + '</td>' +
              C.OP_LEVELS.map(function (l) { return '<td class="num">' + h(o.values[l.key]) + '</td>'; }).join('') + '<td>' + nr(o.source, 'No source') + '</td></tr>';
          }).join('') + '</tbody></table>';
      }
      psts.forEach(function (t) {
        var r = C.pstCalc(t), u = t.unit || 's', sc = t.scenarioId && p.scenarios[t.scenarioId], g = t.safeguardId && p.safeguards[t.safeguardId];
        body += '<div class="keep blk"><h4>Process Safety Time: ' + h(t.title || (sc ? sc.displayId + ' ' + sc.deviation : 'untitled')) + '</h4><table class="kv small"><tbody>' +
          (g ? '<tr><th>Safeguard</th><td>' + h(g.description) + '</td></tr>' : '') +
          C.PST_PARTS.map(function (pt) { return '<tr><th>' + h(pt.label) + '</th><td>' + (txt(t.times[pt.key]) ? h(t.times[pt.key]) + ' ' + h(u) : '<span class="nr">Not entered</span>') + '</td></tr>'; }).join('') +
          '<tr><th>' + h(C.PST_HAZARD.label) + '</th><td>' + (txt(t.times.hazard) ? h(t.times.hazard) + ' ' + h(u) : '<span class="nr">Not entered</span>') + '</td></tr>' +
          '<tr><th>Margin (simplified sum)</th><td>' + (r.complete ? C.fmt(r.margin) + ' ' + h(u) : '<span class="nr">Not calculated: ' + (r.state === 'invalid' ? 'an entry is not a valid time' : 'entries missing') + '</span>') + '</td></tr>' +
          '<tr><th>Basis</th><td>' + nr(t.basis) + '</td></tr><tr><th>Team conclusion</th><td>' + nr(t.conclusion) + '</td></tr></tbody></table>' +
          '<p class="small">The margin is a plain sum of the entered times, not a validated dynamic model. A positive margin does not by itself show that a safeguard is effective.</p></div>';
      });
    });
    return sec(n, 'Operating limits and Process Safety Time', body || '<p><span class="nr">No operating limits or Process Safety Time analyses are recorded.</span></p>');
  }

  function appendixSec(p, n) {
    var drawings = vals(p.drawings).filter(function (d) { return vals(p.nodes).some(function (nd) { return nd.regions.some(function (r) { return r.drawingId === d.id; }); }); });
    var intro = '<section class="rsec appx-intro"><h2><span class="sn">' + n + '</span> Annotated P&amp;ID appendix</h2><p>Each drawing with node boundaries follows on a landscape page. Node boundaries are the study team\'s annotations; the drawings themselves are unchanged.</p>' +
      (drawings.length ? '' : '<p><span class="nr">No drawing has node regions.</span></p>') + '</section>';
    return intro + drawings.map(function (d) {
      var nodes = nodesSorted(p).filter(function (nd) { return nd.regions.some(function (r) { return r.drawingId === d.id; }); });
      return '<section class="appx" data-drawing="' + h(d.id) + '"><div class="appx-head"><b>' + h(d.number || d.file.name) + '</b>' + (d.revision ? ' Rev ' + h(d.revision) : ' <span class="nr">revision not recorded</span>') + (d.title ? ' &mdash; ' + h(d.title) : '') + '</div>' +
        '<div class="appx-img" data-drawing-img="' + h(d.id) + '"><span class="nr">Drawing image is added when the report is shown in the app.</span></div>' +
        '<div class="appx-legend">' + nodes.map(function (nd) { return '<span><i style="background:' + h(nd.color) + '"></i>' + nodeLabel(nd) + '</span>'; }).join('') + '</div></section>';
    }).join('');
  }

  function sec(n, title, body, cls) { return '<section class="rsec' + (cls ? ' ' + cls : '') + '"><h2><span class="sn">' + n + '</span> ' + h(title) + '</h2>' + body + '</section>'; }

  /* opts: { sections: { key: bool }, reviewedOnly: bool, now: Date } */
  function build(p, opts) {
    opts = opts || {};
    var on = {};
    SECTIONS.forEach(function (s) { on[s.key] = opts.sections && opts.sections[s.key] != null ? !!opts.sections[s.key] : s.on; });
    var sum = R.summary(p, null), out = R.outstanding(p);
    var ctx = { sum: sum, out: out, complete: sum.complete, openItems: out.filter(function (o) { return o.kind !== 'info' && o.kind !== 'recommendation'; }).length,
                generated: (opts.now || new Date()).toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) };
    var parts = [], n = 0;
    if (on.cover) parts.push(cover(p, ctx));
    if (on.scope) parts.push(scopeSec(p, ++n));
    if (on.team) parts.push(teamSec(p, ++n));
    if (on.method) parts.push(methodSec(p, ++n));
    if (on.nodes) parts.push(nodeRegister(p, ++n));
    if (on.intent) parts.push(intentSec(p, ++n));
    if (on.devsum) parts.push(devSummary(p, ++n));
    if (on.detail) parts.push(detailSec(p, ++n, opts));
    if (on.risktable) parts.push(riskTableSec(p, ++n));
    if (on.recs) parts.push(recsSec(p, ++n));
    if (on.completion) parts.push(completionSec(p, ++n, ctx));
    if (on.oplimits) parts.push(opSec(p, ++n));
    if (on.appendix) parts.push(appendixSec(p, ++n));
    var header = (p.project.name || 'Untitled study') + (p.project.revision ? ' — ' + p.project.revision : '');
    return {
      html: '<article class="pha-report' + (ctx.complete ? '' : ' is-draft') + '">' + parts.join('') + '</article>',
      header: header, draft: !ctx.complete, complete: ctx.complete, outstanding: out, summary: sum
    };
  }

  /* The printable project-library register, from catalog rows only (no drawings are read). */
  function register(rows, opts) {
    opts = opts || {};
    var gen = (opts.now || new Date()).toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    var STL = {}; store.PROJECT_STATUSES.forEach(function (s) { STL[s[0]] = s[1]; });
    var body = rows.map(function (m) {
      var c = m.completion, comp;
      if (!c) comp = '<span class="nr">Not available (open and save the project once in this version)</span>';
      else comp = (c.complete ? 'Analysis complete' : '<b class="flag">Incomplete</b>') + '<br><small>' + c.reviewed + '/' + c.scenarios + ' scenarios reviewed; ' + c.notReviewed + ' deviation(s) not reviewed; ' + c.openRecs + ' open recommendation(s)</small>';
      return '<tr><td class="b">' + nr(m.name, 'Untitled') + '</td><td>' + h(m.facility) + '</td><td>' + h(m.methodology) + (m.studyType ? '<br><small>' + h(m.studyType) + '</small>' : '') + '</td><td>' + nr(m.revision, '') +
        '</td><td>' + h(STL[m.status] || m.status) + '</td><td>' + date(m.modifiedAt) + '</td><td>' + comp + '</td><td>' + h(opts.backup ? opts.backup(m) : '') + '</td></tr>';
    }).join('');
    return '<article class="pha-report register"><section class="rsec reg"><div class="cv-kicker">PHA Workspace</div><h1 class="reg-title">Project library register</h1>' +
      '<p class="small">' + rows.length + ' project(s) in this browser\'s repository' + (opts.filterNote ? ' (' + h(opts.filterNote) + ')' : '') + '. Generated ' + h(gen) + '. Completion is taken from each project\'s last save.</p>' +
      '<table class="grid small"><thead><tr><th>Study</th><th>Facility</th><th>Methodology</th><th class="w-id">Revision</th><th class="w-st">Status</th><th class="w-date">Last modified</th><th>Completion</th><th>Backup</th></tr></thead><tbody>' +
      (body || '<tr><td colspan="8"><span class="nr">No projects.</span></td></tr>') + '</tbody></table></section></article>';
  }

  PHA.reportgen = { SECTIONS: SECTIONS, build: build, register: register, escape: h };
})();
