/* report.js: the Report Builder screen. Shows the report built by reportgen.js as print pages, lets the facilitator
   choose sections, and prints it with the dedicated print stylesheet (css/report.css). Also prints the repository
   register from the project catalog, and exports annotated drawings as images. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, RG = PHA.reportgen;
  function $(id) { return document.getElementById(id); }

  var mode = null, cameFrom = 'editor', opts = loadOpts(), lastBuild = null, token = 0;

  function loadOpts() {
    var o = { sections: {}, reviewedOnly: false };
    RG.SECTIONS.forEach(function (s) { o.sections[s.key] = s.on; });
    try { var saved = JSON.parse(localStorage.getItem('pha.reportOpts') || 'null'); if (saved) { Object.assign(o.sections, saved.sections || {}); o.reviewedOnly = !!saved.reviewedOnly; } } catch (e) { /* ignore */ }
    return o;
  }
  function saveOpts() { try { localStorage.setItem('pha.reportOpts', JSON.stringify(opts)); } catch (e) { /* ignore */ } }

  /* Page header and footer text for the print margin boxes (Chromium supports @page margin boxes). */
  function cssString(s) { return '"' + String(s || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/[\r\n]+/g, ' ') + '"'; }
  function pageStyle(header, right, footer) {
    var st = $('rbPageStyle');
    st.textContent = '@page { @top-left { content: ' + cssString(header) + '; } @top-right { content: ' + cssString(right) + '; } ' +
      '@bottom-left { content: ' + cssString(footer) + '; } } ' +
      '@page :first { @top-left { content: none; } @top-right { content: none; } }';      // no running header on the cover
  }

  function side() {
    var box = $('rbSide');
    box.textContent = '';
    if (mode === 'register') {
      box.appendChild(el('h3', null, 'Project register'));
      box.appendChild(el('p', { 'class': 'muted' }, 'A one-table index of the projects shown on the repository screen, built from the catalog only. No project drawings are read.'));
      box.appendChild(printTips());
      return;
    }
    var p = store.S.project;
    box.appendChild(el('h3', null, 'Report sections'));
    var list = el('div', { 'class': 'rb-secs' });
    RG.SECTIONS.forEach(function (s) {
      list.appendChild(el('label', { 'class': 'rb-sec' }, el('input', { type: 'checkbox', 'data-sec': s.key, checked: opts.sections[s.key] ? true : null, onchange: function (e) {
        opts.sections[s.key] = e.target.checked; saveOpts(); build();
      } }), s.label));
    });
    box.appendChild(list);
    box.appendChild(el('h3', null, 'Options'));
    box.appendChild(el('label', { 'class': 'rb-sec' }, el('input', { type: 'checkbox', 'data-opt': 'reviewedOnly', checked: opts.reviewedOnly ? true : null, onchange: function (e) {
      opts.reviewedOnly = e.target.checked; saveOpts(); build();
    } }), 'Detailed scenarios: reviewed scenarios only (drafts are still counted and listed as outstanding)'));
    var s = lastBuild;
    if (s) {
      box.appendChild(el('div', { 'class': 'rb-state ' + (s.complete ? 'ok' : 'draft') },
        el('b', null, s.complete ? 'Analysis complete' : 'Draft: study incomplete'),
        el('div', null, s.complete ? 'Every recorded deviation is decided and every scenario is reviewed.' : s.outstanding.filter(function (o) { return o.kind !== 'info' && o.kind !== 'recommendation'; }).length + ' outstanding item(s). The report is marked DRAFT on every page.'),
        el('div', { 'class': 'muted small' }, s.outstanding.filter(function (o) { return o.kind === 'recommendation'; }).length + ' open recommendation(s).'),
        el('div', { 'class': 'muted small' }, s.outstanding.filter(function (o) { return o.kind === 'info'; }).length + ' note(s) on missing supporting information.')));
    }
    box.appendChild(el('button', { 'data-act': 'study-info', onclick: function () { PHA.study.open(); } }, 'Edit study information'));
    box.appendChild(printTips());
    void p;
  }

  function printTips() {
    return el('div', { 'class': 'rb-tips' }, el('h3', null, 'Printing'),
      el('ul', null,
        el('li', null, 'Use Print / Save as PDF, then choose a printer or "Save as PDF".'),
        el('li', null, 'Paper: Letter. Margins: Default. Turn ', el('b', null, 'Headers and footers'), ' off: the report prints its own study name, status and page numbers.'),
        el('li', null, 'Turn ', el('b', null, 'Background graphics'), ' on so risk colors print.'),
        el('li', null, 'The P&ID appendix prints on landscape pages.')));
  }

  async function build() {
    var my = ++token, doc = $('reportDoc');
    if (mode === 'register') return;
    var p = store.S.project;
    lastBuild = RG.build(p, { sections: opts.sections, reviewedOnly: opts.reviewedOnly });
    doc.innerHTML = lastBuild.html;                          // built from escaped record text only
    pageStyle(lastBuild.header, lastBuild.draft ? 'DRAFT \u2014 STUDY INCOMPLETE' : 'PHA report', 'PHA Workspace ' + store.APP_VERSION + ' \u00B7 generated ' + new Date().toLocaleDateString('en-US'));
    side();
    var imgs = doc.querySelectorAll('[data-drawing-img]');
    for (var i = 0; i < imgs.length; i++) {
      if (my !== token) return;
      var holder = imgs[i], d = p.drawings[holder.getAttribute('data-drawing-img')];
      holder.textContent = 'Rendering drawing...';
      try {
        var url = await drawingImage(p, d, 2200);
        if (my !== token) return;
        holder.textContent = '';
        holder.appendChild(el('img', { src: url, alt: 'Annotated drawing ' + (d.number || '') }));
      } catch (e) {
        holder.textContent = '';
        holder.appendChild(el('span', { 'class': 'nr' }, e && e.message === 'MISSING_FILE' ? 'The PDF for this drawing is not stored in the project. Re-import it to include it here.' : 'This drawing could not be rendered: ' + (e && e.message || e)));
      }
    }
  }

  /* A drawing page with the node boundaries and IDs drawn on it, as a PNG data URL. The original PDF is not changed. */
  async function drawingImage(p, d, maxPx) {
    var pdf = await PHA.viewer.docFor(d.file.sha256);
    var pg = await pdf.getPage(d.page);
    var vp1 = pg.getViewport({ scale: 1 }), scale = maxPx / Math.max(vp1.width, vp1.height);
    var vp = pg.getViewport({ scale: scale });
    var c = document.createElement('canvas');
    c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
    var ctx = c.getContext('2d', { alpha: false });
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
    await pg.render({ canvasContext: ctx, viewport: vp }).promise;
    var W = c.width, H = c.height, fs = Math.max(14, Math.round(W / 95));
    Object.keys(p.nodes).map(function (k) { return p.nodes[k]; }).forEach(function (n) {
      n.regions.filter(function (r) { return r.drawingId === d.id; }).forEach(function (r, i) {
        ctx.beginPath();
        r.points.forEach(function (q, j) { if (j) ctx.lineTo(q[0] * W, q[1] * H); else ctx.moveTo(q[0] * W, q[1] * H); });
        ctx.closePath();
        ctx.globalAlpha = 0.16; ctx.fillStyle = n.color; ctx.fill();
        ctx.globalAlpha = 1; ctx.lineWidth = Math.max(2, W / 700); ctx.strokeStyle = n.color; ctx.stroke();
        if (i === 0) {
          var x = Math.min.apply(null, r.points.map(function (q) { return q[0]; })) * W, y = Math.min.apply(null, r.points.map(function (q) { return q[1]; })) * H;
          ctx.font = 'bold ' + fs + 'px Calibri, Carlito, Arial, sans-serif';
          var tw = ctx.measureText(n.displayId).width;
          x = Math.max(0, Math.min(x, W - tw - 8)); y = y - 6 < fs ? y + fs + 6 : y - 6;
          ctx.lineWidth = Math.max(3, fs / 4); ctx.strokeStyle = '#fff'; ctx.strokeText(n.displayId, x, y);
          ctx.fillStyle = n.color; ctx.fillText(n.displayId, x, y);
        }
      });
    });
    return c.toDataURL('image/png');
  }

  /* All annotated drawings as PNG images: one file, or a zip when there are several. */
  async function exportDrawings() {
    var p = store.S.project, ds = Object.keys(p.drawings).map(function (k) { return p.drawings[k]; });
    if (!ds.length) { alert('This project has no drawings.'); return; }
    var files = {}, problems = [];
    for (var i = 0; i < ds.length; i++) {
      try {
        var url = await drawingImage(p, ds[i], 4200);
        var bin = atob(url.split(',')[1]), bytes = new Uint8Array(bin.length);
        for (var j = 0; j < bin.length; j++) bytes[j] = bin.charCodeAt(j);
        files[U.safeName((ds[i].number || ds[i].file.name) + (ds[i].revision ? '-rev-' + ds[i].revision : '')) + '-annotated.png'] = [bytes, { level: 0 }];
      } catch (e) { problems.push((ds[i].number || ds[i].file.name) + ': ' + (e.message === 'MISSING_FILE' ? 'PDF not stored in the project' : e.message)); }
    }
    var names = Object.keys(files);
    if (names.length === 1) U.download(files[names[0]][0], names[0], 'image/png');
    else if (names.length) U.download(fflate.zipSync(files), U.safeName(p.project.name) + '-annotated-drawings.zip', 'application/zip');
    if (problems.length) alert('Some drawings could not be exported:\n\n' + problems.join('\n'));
  }

  function setChrome() {
    $('rbTitle').textContent = mode === 'register' ? 'Project register' : 'Report builder';
    $('rbStudy').hidden = mode === 'register';
    $('rbDrawings').hidden = mode === 'register';
    $('rbBack').textContent = cameFrom === 'dash' ? '\u25C0 Projects' : '\u25C0 Back to workspace';
  }

  function open() {
    mode = 'report'; cameFrom = 'editor';
    document.body.dataset.view = 'report';
    setChrome(); build();
    $('rbPreview').scrollTop = 0;
  }

  /* rows: catalog rows (as on the repository screen). Rows saved before 0.4.0 have no completion summary; for those
     the project record alone is read (never its drawings) to work it out. */
  async function openRegister(rows, note) {
    mode = 'register'; cameFrom = 'dash';
    var filled = [];
    for (var i = 0; i < rows.length; i++) {
      var m = Object.assign({}, rows[i]);
      if (!m.completion && PHA.repo.isOpen()) {
        try { m.completion = PHA.review.catalogCompletion((await PHA.repo.load(m.id, { noFiles: true })).project); } catch (e) { m.completion = null; }
      }
      filled.push(m);
    }
    document.body.dataset.view = 'report';
    setChrome(); side();
    $('reportDoc').innerHTML = RG.register(filled, { filterNote: note, backup: function (m) { return PHA.repo.backupStatus(m).text; } });
    pageStyle('Project library register', '', 'PHA Workspace ' + store.APP_VERSION + ' \u00B7 generated ' + new Date().toLocaleDateString('en-US'));
  }

  function close() {
    token++;
    $('reportDoc').textContent = '';
    if (cameFrom === 'dash') { document.body.dataset.view = 'dash'; return; }
    document.body.dataset.view = 'editor';
    if (PHA.viewer.info().W) PHA.viewer.fit();
  }

  function init() {
    $('rbBack').onclick = close;
    $('rbPrint').onclick = function () { window.print(); };
    $('rbStudy').onclick = function () { PHA.study.open(); };
    $('rbDrawings').onclick = exportDrawings;
    // Edits made while the report is open (study information) show straight away.
    store.on('change', function (e) { if (document.body.dataset.view === 'report' && mode === 'report' && e.kind !== 'field') build(); });
    var dl = $('studyDlg');
    dl.addEventListener('close', function () { if (document.body.dataset.view === 'report' && mode === 'report') build(); });
  }

  PHA.report = { init: init, open: open, openRegister: openRegister, close: close, build: build, drawingImage: drawingImage, exportDrawings: exportDrawings,
                 lastBuild: function () { return lastBuild; } };
})();
