/* autosave.js: keeps the project that is open in the editor saved to the repository.
   States: saved | dirty (Unsaved changes) | saving | failed | volatile (no repository) | idle (no project open).
   "saved" is set only after the repository transaction has completed. No screen code here. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, store = PHA.store, repo = PHA.repo;

  var DELAY = 1000, JOURNAL_KEY = 'pha.journal';
  var session = null;              // { id, baseRev, meta } for the project open in the editor
  var state = { status: 'idle', at: null, error: null };
  var listeners = [], timer = null, inFlight = null;

  function set(status, extra) {
    state = { status: status, at: (extra && extra.at) || state.at, error: (extra && extra.error) || null };
    listeners.forEach(function (f) { f(state); });
  }

  function begin(meta) {
    clearTimeout(timer);
    session = { id: meta.id, baseRev: meta.rev, meta: meta };
    store.S.dirty = false;
    set('saved', { at: meta.savedAt ? new Date(meta.savedAt) : null });
  }
  /* The repository could not be opened: work continues in memory and must be exported to be kept. */
  function beginVolatile() { clearTimeout(timer); session = { volatile: true }; set('volatile'); }
  function end() { clearTimeout(timer); session = null; set('idle'); }

  function schedule() {
    if (!session) return;
    if (session.volatile) { set('volatile'); return; }
    if (state.status !== 'failed' || state.error.code === 'quota' || state.error.code === 'failed' || state.error.code === 'unavailable') set('dirty');
    clearTimeout(timer);
    timer = setTimeout(run, DELAY);
  }

  function run() {
    if (!session || session.volatile) return Promise.resolve(false);
    if (inFlight) return inFlight.then(function () { return store.S.dirty ? run() : true; });
    var S = store.S, p = S.project;
    if (!S.dirty && state.status === 'saved') return Promise.resolve(true);
    // A conflict or a deleted project needs a decision from the user; do not keep retrying over it.
    if (state.status === 'failed' && (state.error.code === 'conflict' || state.error.code === 'missing' || state.error.code === 'identity')) return Promise.resolve(false);
    if (p.project.id !== session.id) {
      set('failed', { error: { code: 'identity', message: 'The open project\'s ID no longer matches the project that was opened. Nothing was saved over it. Export a .phaz file to keep this work.' } });
      return Promise.resolve(false);
    }
    var seq = S.seq, sess = session;
    clearTimeout(timer);
    set('saving');
    inFlight = repo.save({ project: p, files: S.files, baseRev: sess.baseRev, mode: 'update' }).then(function (meta) {
      inFlight = null;
      if (session !== sess) return true;
      sess.baseRev = meta.rev; sess.meta = meta;
      if (S.seq === seq) { S.dirty = false; clearJournal(); set('saved', { at: new Date(meta.savedAt) }); }
      else { set('dirty'); timer = setTimeout(run, DELAY); }       // edited while saving: save again
      return true;
    }, function (e) {
      inFlight = null;
      if (session === sess) set('failed', { error: repo.classify(e) });
      return false;
    });
    return inFlight;
  }

  /* Save now and wait. Resolves true only when everything on screen is in the repository. */
  async function flush() {
    clearTimeout(timer);
    if (!session) return true;
    if (session.volatile) return false;
    for (var i = 0; i < 4; i++) {
      var ok = await run();
      if (!ok) return false;
      if (!store.S.dirty) return true;
    }
    return !store.S.dirty;
  }

  function retry() {
    if (state.status === 'failed' && ['conflict', 'missing', 'identity'].indexOf(state.error.code) < 0) { set('dirty'); return run(); }
    return run();
  }

  /* After a conflict: keep this window's version, either as a separate project or over the other one. */
  async function resolve(how) {
    if (!session || session.volatile) return false;
    var S = store.S, p = S.project, meta;
    try {
      if (how === 'copy' || state.error && state.error.code === 'missing') {
        if (how === 'copy') {
          p.project.source = { type: 'conflict-copy', projectId: session.id, at: new Date().toISOString() };
          p.project.id = U.uid('prj');
          p.project.name = (p.project.name || 'Untitled') + ' (my copy)';
        }
        meta = await repo.save({ project: p, files: S.files, mode: 'create', clearBackup: true });
      } else {
        meta = await repo.save({ project: p, files: S.files, mode: 'update', force: true });
      }
    } catch (e) { set('failed', { error: repo.classify(e) }); return false; }
    session = { id: meta.id, baseRev: meta.rev, meta: meta };
    S.dirty = false; clearJournal();
    set('saved', { at: new Date(meta.savedAt) });
    return true;
  }

  /* ---- close-time journal ----
     IndexedDB writes are asynchronous and may not finish while a window is closing. If the window goes away with
     unsaved edits, the project JSON is also written synchronously to localStorage so it can be offered back. */
  function writeJournal() {
    if (!session || session.volatile || !store.S.dirty) return false;
    try {
      localStorage.setItem(JOURNAL_KEY, JSON.stringify({ id: session.id, baseRev: session.baseRev, at: Date.now(),
        name: store.S.project.project.name || '', json: JSON.stringify(store.S.project) }));
      return true;
    } catch (e) { return false; }
  }
  function clearJournal() { try { localStorage.removeItem(JOURNAL_KEY); } catch (e) { /* ignore */ } }
  function readJournal() {
    try { var j = JSON.parse(localStorage.getItem(JOURNAL_KEY) || 'null'); return j && j.id && j.json ? j : null; } catch (e) { return null; }
  }
  /* Decide what a journal found at startup means. Pure, so it is covered by the tests. */
  function judgeJournal(j, meta) {
    if (!j) return 'none';
    if (!meta) return 'orphan';                       // its project is not in the repository
    if (meta.rev > j.baseRev) return 'stale';         // a later save reached the repository after all
    return 'apply';
  }
  async function applyJournal(j) {
    var project = store.migrate(JSON.parse(j.json));
    var meta = await repo.getMeta(j.id);
    var out = meta ? await repo.save({ project: project, baseRev: j.baseRev, mode: 'update' })
                   : await repo.save({ project: project, mode: 'create', clearBackup: true });
    clearJournal();
    return out;
  }

  function onPageHide() {
    if (!session || session.volatile || !store.S.dirty) return;
    writeJournal();
    run();
  }

  PHA.autosave = {
    begin: begin, beginVolatile: beginVolatile, end: end, schedule: schedule, flush: flush, retry: retry, resolve: resolve,
    state: function () { return state; }, session: function () { return session; },
    onState: function (f) { listeners.push(f); },
    readJournal: readJournal, clearJournal: clearJournal, writeJournal: writeJournal, judgeJournal: judgeJournal, applyJournal: applyJournal,
    onPageHide: onPageHide, DELAY: DELAY, JOURNAL_KEY: JOURNAL_KEY
  };
})();
