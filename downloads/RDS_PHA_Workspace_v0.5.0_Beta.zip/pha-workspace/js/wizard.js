/* wizard.js: the guided scenario wizard, and the individual-item list editor it shares with the full scenario editor.
   The wizard keeps no data of its own. Every step reads and writes the same deviation and scenario records the
   full editor and the Node Board use; only the current step number is view state (store.S.ui.wizard). */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, R = PHA.review;

  /* 0.5.0: eight steps, in the order a facilitator leads the discussion. Steps 3 to 8 work on a scenario record. */
  var STEPS = [
    { n: 1, label: 'Deviation' }, { n: 2, label: 'Applicable?' }, { n: 3, label: 'Causes' }, { n: 4, label: 'Failure sequence' },
    { n: 5, label: 'Consequences' }, { n: 6, label: 'Safeguards' }, { n: 7, label: 'Risk' }, { n: 8, label: 'Review' }];
  var CAUSES = 3, LAST = 8;

  function ui() { return store.S.ui; }
  function grow(t) { t.style.height = 'auto'; t.style.height = Math.min(320, t.scrollHeight + 2) + 'px'; }
  function txt(v) { return String(v == null ? '' : v).trim(); }

  /* ---------- individual item list (causes, consequences, new safeguards) ----------
     o: { key, items, tag ('C'), placeholder, addLabel, onAdd(text), onRemove(item), onMove(item, dir), extra(item, i),
          onQuick() (Quick Add button), onTemplate(item) (save the wording as a template), noDuplicates }
     Each item is its own record with a permanent id: edited, moved or removed on its own. Enter adds (Shift+Enter for a new line).
     Items inserted from the Quick-Add library are "pending team confirmation" until someone presses Confirm. */
  function itemList(o) {
    var box = el('div', { 'class': 'items', 'data-list': o.key });
    if (!o.items.length) box.appendChild(el('div', { 'class': 'muted items-empty' }, o.empty || 'None recorded yet.'));
    o.items.forEach(function (it, i) {
      var t = el('textarea', { rows: 1, 'class': 'item-text', 'data-focus': o.key + ':' + it.id, 'aria-label': o.tag + (i + 1) });
      t.value = it.text || '';
      var holes = PHA.library.unfilled(it), pending = it.teamStatus === 'pending';
      var holeFlag = el('div', { 'class': 'item-flag', 'data-holes': it.id });
      function paintHoles() {
        var hs = PHA.library.unfilled(it);
        holeFlag.textContent = hs.length ? 'Fill in or remove: ' + hs.map(function (h) { return '[' + h + ']'; }).join(', ') : '';
        holeFlag.hidden = !hs.length;
      }
      paintHoles();
      t.addEventListener('input', function () { grow(t); var v = t.value; store.change(function () { it.text = v; }, 'field'); paintHoles(); });
      t.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); var a = box.querySelector('[data-add]'); if (a) a.focus(); }
      });
      setTimeout(function () { grow(t); }, 0);
      var row = el('div', { 'class': 'item' + (it.review ? ' flagged' : '') + (pending ? ' pending' : ''), 'data-item': it.id },
        el('span', { 'class': 'item-tag' }, o.tag + (i + 1)),
        el('div', { 'class': 'item-main' }, t,
          it.review ? el('div', { 'class': 'item-flag' }, it.review) : null,
          holeFlag,
          pending ? el('div', { 'class': 'item-pending' }, el('span', null, 'Inserted from Quick Add: not yet confirmed by the team as credible.'),
            el('button', { 'class': 'mini-btn', 'data-confirm': it.id, title: 'The team agrees this item applies to this scenario', onclick: function () {
              store.change(function () { it.teamStatus = 'agreed'; it.confirmedAt = new Date().toISOString(); });
            } }, 'Confirm')) : null,
          o.extra ? o.extra(it, i) : null),
        el('div', { 'class': 'item-btns' },
          o.onMove ? el('button', { 'class': 'mini', title: 'Move up', disabled: i === 0 ? true : null, onclick: function () { o.onMove(it, -1); } }, '▲') : null,
          o.onMove ? el('button', { 'class': 'mini', title: 'Move down', disabled: i === o.items.length - 1 ? true : null, onclick: function () { o.onMove(it, 1); } }, '▼') : null,
          o.onTemplate ? el('button', { 'class': 'mini', title: 'Save this wording as a Quick-Add template', 'data-tpl': it.id, onclick: function () { o.onTemplate(it); } }, '\u2606') : null,
          el('button', { 'class': 'x', title: 'Remove ' + o.tag + (i + 1), 'data-remove': it.id, onclick: function () { o.onRemove(it); } }, '×')));
      box.appendChild(row);
    });
    var add = el('textarea', { rows: 1, 'class': 'item-add', 'data-add': o.key, 'data-focus': 'add:' + o.key, placeholder: o.placeholder });
    var msg = el('div', { 'class': 'item-msg', 'data-msg': o.key, role: 'status' });
    function doAdd() {
      var v = add.value;
      if (!txt(v)) return;
      if (o.noDuplicates) {
        var dup = o.items.map(function (x, k) { return PHA.library.sameText(x.text, v) ? o.tag + (k + 1) : null; }).filter(Boolean)[0];
        if (dup) { msg.textContent = 'Already recorded as ' + dup + '. Edit that item instead of adding the same text twice.'; add.classList.add('invalid'); return; }
      }
      add.value = '';
      o.onAdd(v);
      PHA.panel.focus('add:' + o.key);
    }
    add.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doAdd(); } });
    add.addEventListener('input', function () { grow(add); msg.textContent = ''; add.classList.remove('invalid'); });
    box.appendChild(el('div', { 'class': 'item-new' }, add, el('button', { 'class': 'add-btn', 'data-addbtn': o.key, onclick: doAdd }, o.addLabel || 'Add'),
      o.onQuick ? el('button', { 'class': 'quick-btn', 'data-quick': o.key, title: 'Insert wording from the Quick-Add library', onclick: o.onQuick }, 'Quick Add\u2026') : null));
    box.appendChild(msg);
    return box;
  }

  function causeList(p, sc) {
    return itemList({
      key: 'causes:' + sc.id, items: sc.causes, tag: 'C', placeholder: 'Type a cause and press Enter, e.g. LIC-101 level controller fails high', addLabel: 'Add cause',
      empty: 'No initiating causes recorded yet.', noDuplicates: true,
      onAdd: function (v) { store.change(function () { store.addCause(sc, v); }); },
      onQuick: function () { PHA.quickadd.open('cause', sc); },
      onTemplate: function (it) { PHA.quickadd.saveAsTemplate('cause', it.text); },
      onRemove: function (it) {
        if (txt(it.text) && !confirm('Remove cause "' + it.text + '"? You can undo this.')) return;
        store.change(function () { store.removeCause(sc, it.id); });
      },
      onMove: function (it, d) { store.change(function () { store.moveItem(sc.causes, it.id, d); }); },
      extra: function (it) {
        if (sc.causes.length < 2) return null;
        return el('button', { 'class': 'link', title: 'Use when this cause leads to different consequences or safeguards. The cause moves to a new scenario under the same deviation.',
          onclick: function () {
            var ns;
            store.change(function (proj) { ns = store.splitCause(proj, sc, it.id); });
            if (ns) PHA.panel.flash('Cause moved to new scenario ' + ns.displayId + ' under the same deviation.');
          } }, 'Give this cause its own scenario');
      }
    });
  }

  function consequenceList(p, sc) {
    var cats = p.project.riskMatrix.categories || [];
    return itemList({
      key: 'csq:' + sc.id, items: sc.consequences, tag: 'Q', placeholder: 'Type one ultimate consequence and press Enter, e.g. Pool fire at the pump bay', addLabel: 'Add consequence',
      empty: 'No consequences recorded yet.', noDuplicates: true,
      onAdd: function (v) { store.change(function () { store.addConsequence(sc, v); }); },
      onQuick: function () { PHA.quickadd.open('consequence', sc); },
      onTemplate: function (it) { PHA.quickadd.saveAsTemplate('consequence', it.text, it.category); },
      onRemove: function (it) {
        if (txt(it.text) && !confirm('Remove consequence "' + it.text + '"? You can undo this.')) return;
        store.change(function () { store.removeConsequence(sc, it.id); });
      },
      onMove: function (it, d) { store.change(function () { store.moveItem(sc.consequences, it.id, d); }); },
      extra: function (q) {
        var bits = [];
        if (sc.causes.length > 1) {
          var chips = el('div', { 'class': 'links-row' }, el('span', { 'class': 'muted' }, 'Follows from: '));
          sc.causes.forEach(function (c, ci) {
            var on = q.causeIds.indexOf(c.id) >= 0;
            chips.appendChild(el('button', { 'class': 'cchip' + (on ? ' on' : ''), title: c.text, 'aria-pressed': on ? 'true' : 'false', onclick: function () {
              store.change(function () {
                if (on) q.causeIds = q.causeIds.filter(function (x) { return x !== c.id; }); else q.causeIds.push(c.id);
              });
            } }, 'C' + (ci + 1)));
          });
          chips.appendChild(el('span', { 'class': 'muted small' }, q.causeIds.length ? '' : ' (all causes)'));
          bits.push(chips);
        }
        if (cats.length) {
          bits.push(PHA.ui.select(q.category, cats, function (e) { var v = e.target.value; store.change(function () { q.category = v; }, 'field'); }, 'Consequence category'));
        }
        bits.push(PHA.ui.text(q.escalation, function (v) { q.escalation = v; }, { 'class': 'esc', 'data-esc': q.id, placeholder: 'Escalation conditions (optional), e.g. if ignition occurs', title: 'What must also happen for this outcome' }));
        return el('div', { 'class': 'item-extra' }, bits);
      }
    });
  }

  /* Safeguards: the existing safeguard records, associated with the scenario. One record can serve several scenarios. */
  function safeguardList(p, n, sc) {
    var box = el('div', { 'class': 'items' });
    var mine = sc.safeguardIds.filter(function (id) { return p.safeguards[id]; });
    if (!mine.length) box.appendChild(el('div', { 'class': 'muted items-empty' }, 'No safeguards associated with this scenario yet.'));
    mine.forEach(function (id, i) {
      var g = p.safeguards[id], uses = store.safeguardUse(p, id);
      var t = el('textarea', { rows: 1, 'class': 'item-text', 'data-focus': 'sfg:' + id, placeholder: 'e.g. LAH-101 high level alarm with operator response' });
      t.value = g.description || '';
      t.addEventListener('input', function () { grow(t); var v = t.value; store.change(function () { g.description = v; }, 'field'); });
      setTimeout(function () { grow(t); }, 0);
      var role = PHA.ui.select(g.role, [['preventive', 'Preventive'], ['mitigative', 'Mitigative']], function (e) {
        var v = e.target.value; store.change(function () { g.role = v; }, 'field');
      }, 'Preventive or mitigative?');
      var ev = PHA.modules.sfgEval(p, n, sc, g);
      box.appendChild(el('div', { 'class': 'item', 'data-item': id },
        el('span', { 'class': 'item-tag' }, 'G' + (i + 1)),
        el('div', { 'class': 'item-main' }, t,
          el('div', { 'class': 'item-extra' }, role,
            uses > 1 ? el('span', { 'class': 'tag', title: 'This is one safeguard record. Editing it changes it in every scenario that uses it.' }, 'Used in ' + uses + ' scenarios') : null,
            g.evaluation && g.evaluation.status === 'not-evaluated' ? el('span', { 'class': 'muted small' }, 'Effectiveness not evaluated') : null),
          ev),
        el('div', { 'class': 'item-btns' },
          el('button', { 'class': 'x', title: uses > 1 ? 'Remove from this scenario (the record stays with the other scenarios)' : 'Remove', 'data-remove': id, onclick: function () {
            store.change(function (proj) { store.removeSafeguard(proj, sc, id); });
          } }, '×'))));
    });
    var add = el('textarea', { rows: 1, 'class': 'item-add', 'data-add': 'sfg:' + sc.id, 'data-focus': 'add:sfg:' + sc.id, placeholder: 'Type a new safeguard and press Enter' });
    function doAdd() {
      var v = add.value; if (!txt(v)) return; add.value = '';
      store.change(function (proj) { store.createSafeguard(proj, sc).description = v; });
      PHA.panel.focus('add:sfg:' + sc.id);
    }
    add.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doAdd(); } });
    box.appendChild(el('div', { 'class': 'item-new' }, add, el('button', { 'class': 'add-btn', onclick: doAdd }, 'Add safeguard')));
    // pick an existing safeguard record (same node first)
    var others = Object.keys(p.safeguards).filter(function (id) { return sc.safeguardIds.indexOf(id) < 0 && txt(p.safeguards[id].description); });
    if (others.length) {
      var nodeOf = {};
      Object.keys(p.scenarios).forEach(function (k) { p.scenarios[k].safeguardIds.forEach(function (g) { nodeOf[g] = nodeOf[g] || p.scenarios[k].nodeId; }); });
      others.sort(function (a, b) { return (nodeOf[a] === n.id ? 0 : 1) - (nodeOf[b] === n.id ? 0 : 1); });
      var pick = el('select', { 'class': 'pick-sfg', 'aria-label': 'Select an existing safeguard' }, [el('option', { value: '' }, 'Select an existing safeguard...')].concat(others.map(function (id) {
        var nn = p.nodes[nodeOf[id]];
        return el('option', { value: id }, p.safeguards[id].description + (nn && nn.id !== n.id ? '  (' + nn.displayId + ')' : ''));
      })));
      pick.addEventListener('change', function () {
        var id = pick.value; if (!id) return;
        store.change(function () { store.attachSafeguard(sc, id); });
      });
      box.appendChild(el('div', { 'class': 'item-new' }, pick));
    }
    return box;
  }

  function recommendationList(p, sc) {
    var box = el('div', { 'class': 'items' });
    var mine = sc.recommendationIds.filter(function (id) { return p.recommendations[id]; });
    if (!mine.length) box.appendChild(el('div', { 'class': 'muted items-empty' }, 'No recommendations for this scenario.'));
    mine.forEach(function (id) {
      var r = p.recommendations[id];
      var t = el('textarea', { rows: 1, 'class': 'item-text', 'data-focus': 'rec:' + id, placeholder: 'What should be done' });
      t.value = r.text || '';
      t.addEventListener('input', function () { grow(t); var v = t.value; store.change(function () { r.text = v; }, 'field'); });
      setTimeout(function () { grow(t); }, 0);
      box.appendChild(el('div', { 'class': 'item rec-item', 'data-item': id },
        el('span', { 'class': 'item-tag rec-id' }, r.displayId),
        el('div', { 'class': 'item-main' }, t,
          el('div', { 'class': 'item-extra' },
            PHA.ui.text(r.assignee, function (v) { r.assignee = v; }, { placeholder: 'Assigned to' }),
            el('input', { type: 'date', value: r.due || '', title: 'Due date', oninput: PHA.ui.setField(function (v) { r.due = v; }) }),
            PHA.ui.select(r.status, [['open', 'Open'], ['closed', 'Closed']], function (e) {
              var v = e.target.value || 'open'; store.change(function () { r.status = v; }, 'field');
            }, 'Status'))),
        el('div', { 'class': 'item-btns' }, el('button', { 'class': 'x', title: 'Remove', 'data-remove': id, onclick: function () {
          if (txt(r.text) && !confirm('Remove recommendation ' + r.displayId + '? You can undo this.')) return;
          store.change(function (proj) { sc.recommendationIds = sc.recommendationIds.filter(function (x) { return x !== id; }); delete proj.recommendations[id]; });
        } }, '×'))));
    });
    var add = el('textarea', { rows: 1, 'class': 'item-add', 'data-add': 'rec:' + sc.id, 'data-focus': 'add:rec:' + sc.id, placeholder: 'Type a recommendation and press Enter' });
    function doAdd() {
      var v = add.value; if (!txt(v)) return; add.value = '';
      store.change(function (proj) { store.createRecommendation(proj, sc).text = v; });
      PHA.panel.focus('add:rec:' + sc.id);
    }
    add.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doAdd(); } });
    box.appendChild(el('div', { 'class': 'item-new' }, add, el('button', { 'class': 'add-btn', onclick: doAdd }, 'Add recommendation')));
    return box;
  }

  /* Scenario status buttons, with the completeness check in front of "Reviewed". */
  function statusControl(p, sc, after) {
    var chk = R.scenarioCheck(p, sc), st = R.scState(sc);
    var wrap = el('div', { 'class': 'sc-status' });
    var seg = el('div', { 'class': 'seg status-seg' });
    store.SCENARIO_STATUSES.forEach(function (s) {
      var blocked = s[0] === 'reviewed' && !chk.canReview && st !== 'reviewed';
      seg.appendChild(el('button', { 'class': (st === s[0] ? 'on ' : '') + 'st-' + s[0], 'data-status': s[0], disabled: blocked ? true : null,
        title: blocked ? 'Complete the items listed below first' : '',
        onclick: function () { store.change(function () { sc.status = s[0]; if (s[0] === 'reviewed') sc.reviewedAt = new Date().toISOString(); }); if (after) after(s[0]); } }, s[1]));
    });
    wrap.appendChild(el('div', { 'class': 'row' }, el('span', { 'class': 'flabel' }, 'Review status'), seg));
    if (chk.blocking.length) wrap.appendChild(el('div', { 'class': 'chk error' }, el('b', null, 'Before this can be marked Reviewed: '), el('ul', null, chk.blocking.map(function (b) { return el('li', null, b); }))));
    if (chk.warnings.length) wrap.appendChild(el('div', { 'class': 'chk info' }, el('ul', null, chk.warnings.map(function (b) { return el('li', null, b); }))));
    return wrap;
  }

  /* ---------- the wizard ---------- */

  function start(nodeId, opts) {
    opts = opts || {};
    var w = { nodeId: nodeId, step: opts.step || 1, devId: null, scenarioId: null, draft: { parameter: '', guideword: '' }, mode: '' };
    if (opts.scenarioId) { var sc = store.S.project.scenarios[opts.scenarioId]; w.scenarioId = sc.id; w.devId = sc.deviationId; }
    if (opts.devId) w.devId = opts.devId;
    ui().wizard = w;
    store.select(nodeId, w.scenarioId);
  }
  function close() { ui().wizard = null; PHA.panel.render(); if (PHA.board) PHA.board.refresh(); }
  function go(step) { var w = ui().wizard; if (!w) return; w.step = step; PHA.panel.render(); var r = document.getElementById('panel'); if (r) r.scrollTop = 0; }

  /* Make sure the wizard has a scenario to work on: an existing one for the deviation, or a new one. */
  function ensureScenario(p, w, forceNew) {
    if (w.scenarioId && p.scenarios[w.scenarioId] && !forceNew) return p.scenarios[w.scenarioId];
    var id;
    store.change(function (proj) { id = store.createScenario(proj, w.nodeId, w.devId).id; });
    w.scenarioId = id;
    store.S.sel.scenarioId = id;
    return store.S.project.scenarios[id];
  }

  function stepBar(w, hasDev, hasScenario) {
    var bar = el('ol', { 'class': 'wsteps' });
    STEPS.forEach(function (s) {
      var can = s.n === 1 || (s.n === 2 && hasDev) || hasScenario;
      bar.appendChild(el('li', null, el('button', { 'class': (w.step === s.n ? 'on' : '') + (s.n < w.step ? ' done' : ''), 'data-step': s.n,
        disabled: can ? null : true, onclick: function () { go(s.n); } }, el('span', { 'class': 'wnum' }, String(s.n)), el('span', { 'class': 'wlab' }, s.label))));
      bar.lastChild.firstChild.title = s.n + '. ' + s.label;
    });
    return bar;
  }

  /* Step 1: which deviation. Nothing is recorded until the team decides applicability in step 2. */
  function stepDeviation(p, n, w, body) {
    var d = w.devId && p.deviations[w.devId];
    var cur = d ? { parameter: d.parameter, guideword: d.guideword } : w.draft;
    body.appendChild(el('p', { 'class': 'wq' }, 'Which deviation is the team considering?'));
    function pick(key) {
      return function (e) {
        var v = e.target.value;
        if (d) {
          var other = store.findDeviation(p, n.id, key === 'parameter' ? v : d.parameter, key === 'guideword' ? v : d.guideword);
          if (other && other.id !== d.id) { alert('This node already has a review record for "' + other.text + '". Choose a different combination.'); e.target.value = d[key]; return; }
          store.change(function (proj) {
            var patch = {}; patch[key] = v;
            var nextP = key === 'parameter' ? v : d.parameter, nextG = key === 'guideword' ? v : d.guideword;
            if (d.text === store.deviationText(d.parameter, d.guideword) || !d.text) patch.text = store.deviationText(nextP, nextG);
            store.setDeviationFields(proj, d, patch);
          });
        } else {
          w.draft[key] = v;
          var found = store.findDeviation(p, n.id, w.draft.parameter, w.draft.guideword);
          if (found) { w.devId = found.id; var scs = store.deviationScenarios(p, found.id); if (scs.length === 1) { w.scenarioId = scs[0].id; } }
          PHA.panel.render();
        }
      };
    }
    body.appendChild(el('div', { 'class': 'row' },
      PHA.ui.field('Process parameter', PHA.ui.select(cur.parameter, p.project.parameters, pick('parameter'), 'Choose'), 'grow'),
      PHA.ui.field('Guideword', PHA.ui.select(cur.guideword, p.project.guidewords, pick('guideword'), 'Choose'), 'grow')));
    var devText = d ? d.text : store.deviationText(w.draft.parameter, w.draft.guideword);
    if (d) {
      body.appendChild(PHA.ui.field('Deviation (edit the wording if needed)', PHA.ui.text(d.text, function (v, proj) { store.setDeviationFields(proj, d, { text: v }); }, { 'class': 'dev-big', 'data-focus': 'devtext' })));
      body.appendChild(el('div', { 'class': 'muted' }, 'Already recorded for this node: ' + R.devState(p, d).label + '.'));
    } else {
      body.appendChild(el('div', { 'class': 'dev-show' + (devText ? '' : ' empty') }, devText || 'Choose a parameter and a guideword.'));
    }
  }

  /* Step 2: is it applicable? Yes / No / Not reviewed, and for Yes, how it is dispositioned. Yes never creates a scenario
     by itself: the team chooses to analyse it, or documents that no credible hazardous scenario was found. */
  function stepApplicability(p, n, w, body) {
    var d = w.devId && p.deviations[w.devId];
    var text = d ? d.text : store.deviationText(w.draft.parameter, w.draft.guideword);
    body.appendChild(el('div', { 'class': 'dev-show' }, text));
    body.appendChild(el('p', { 'class': 'wq' }, 'Is this deviation applicable to ', el('b', null, n.displayId + (n.name ? ' ' + n.name : '')), '?'));
    if (d && d.origin === 'upgrade') body.appendChild(el('div', { 'class': 'chk info' }, 'This review record was created when the project was upgraded, from a scenario recorded earlier. The earlier version did not record an explicit decision; confirm it with the team.'));
    var status = d ? d.status : null, scs = d ? store.deviationScenarios(p, d.id) : [];
    function decide(v) {
      if (v === 'no' && scs.length) { alert('This deviation has ' + scs.length + ' scenario(s). Delete them, or keep the deviation applicable.'); return; }
      store.change(function (proj) {
        var rec = w.devId && proj.deviations[w.devId];
        if (!rec) { rec = store.createDeviation(proj, n.id, { parameter: w.draft.parameter, guideword: w.draft.guideword, text: store.deviationText(w.draft.parameter, w.draft.guideword) }); w.devId = rec.id; }
        rec.status = v; rec.reviewedAt = v === 'not-reviewed' ? null : new Date().toISOString();
        if (rec.origin === 'upgrade') rec.origin = 'upgrade-confirmed';
      });
      if (v === 'no') PHA.panel.focus('devreason');
    }
    var seg = el('div', { 'class': 'decide' });
    [['yes', 'Yes', 'Applicable: evaluate it'], ['no', 'No', 'Not applicable: record the technical basis'], ['not-reviewed', 'Not reviewed', 'Leave it outstanding']].forEach(function (o) {
      seg.appendChild(el('button', { 'class': 'dec dec-' + o[0] + (status === o[0] ? ' on' : ''), 'data-decide': o[0], onclick: function () { decide(o[0]); } },
        el('b', null, o[1]), el('span', null, o[2])));
    });
    body.appendChild(seg);

    if (status === 'no') {
      var reason = PHA.ui.area(d.reason, function (v) { d.reason = v; }, { placeholder: 'Technical basis, e.g. "No pump or pressure source can reverse flow in this line"', 'data-focus': 'devreason' });
      reason.addEventListener('input', function () { var b = document.querySelector('[data-next]'); if (b) b.disabled = !txt(reason.value); });
      body.appendChild(PHA.ui.field('Why is it not applicable? (required)', reason));
      body.appendChild(el('div', { 'class': 'muted' }, 'A deviation marked No does not create a scenario. The decision and its basis are kept in the study record.'));
    }
    if (status === 'not-reviewed') body.appendChild(el('div', { 'class': 'muted' }, 'The deviation stays on the list as outstanding and the study is not shown as complete until it is decided.'));
    if (status !== 'yes') return;

    body.appendChild(el('div', { 'class': 'muted' }, 'Applicable does not mean a hazardous consequence exists. Choose how the team will disposition it.'));
    var mode = scs.length ? 'analyse' : (w.mode || (d.dispositionType ? d.dispositionType : ''));
    w.mode = mode;
    var opts = el('div', { 'class': 'decide disp' });
    [['analyse', 'Analyse as a scenario', 'Causes, failure sequence, consequences, safeguards and risk'],
     ['no-credible-scenario', 'No credible hazardous scenario', 'Document the finding and why'],
     ['covered-elsewhere', 'Covered elsewhere', 'Reference where the analysis is recorded']].forEach(function (o) {
      var blocked = o[0] !== 'analyse' && scs.length;
      opts.appendChild(el('button', { 'class': 'dec dec-disp' + (mode === o[0] ? ' on' : ''), 'data-disp': o[0], disabled: blocked ? true : null,
        title: blocked ? 'This deviation already has scenarios' : '',
        onclick: function () {
          w.mode = o[0];
          if (o[0] === 'analyse') PHA.panel.render();
          else store.change(function () { d.dispositionType = o[0]; });
          if (o[0] !== 'analyse') PHA.panel.focus('disptext');
        } }, el('b', null, o[1]), el('span', null, o[2])));
    });
    body.appendChild(opts);
    if (mode === 'no-credible-scenario' || mode === 'covered-elsewhere') {
      var area = PHA.ui.area(d.disposition, function (v) { d.disposition = v; }, { 'data-focus': 'disptext',
        placeholder: mode === 'no-credible-scenario' ? 'Finding, e.g. "Pump deadhead is limited by the minimum-flow recirculation line; no loss of containment is credible."' : 'Reference, e.g. "Analysed under N-02, scenario S-004"' });
      area.addEventListener('input', function () { var b = document.querySelector('[data-next]'); if (b) b.disabled = !txt(area.value); });
      body.appendChild(PHA.ui.field(mode === 'no-credible-scenario' ? 'Documented finding (required)' : 'Where it is covered (required)', area));
    }
    if (mode === 'analyse' && scs.length > 1) {
      body.appendChild(el('p', { 'class': 'wq' }, 'This deviation has ' + scs.length + ' scenarios. Which one?'));
      scs.forEach(function (s) {
        body.appendChild(el('button', { 'class': 'pick-sc' + (w.scenarioId === s.id ? ' on' : ''), 'data-pick': s.id, onclick: function () { w.scenarioId = s.id; store.S.sel.scenarioId = s.id; go(CAUSES); } },
          el('b', null, s.displayId), ' ', (s.causes[0] && s.causes[0].text) || 'no cause yet'));
      });
    }
  }

  /* Step 4: how the deviation could escalate, kept separate from the causes and from the ultimate consequences. */
  function stepSequence(p, n, sc, body) {
    var q = sc.sequence;
    body.appendChild(el('p', { 'class': 'wq' }, 'How could ', el('b', null, sc.deviation || 'the deviation'), ' escalate?'));
    body.appendChild(chain(p, sc, 'sequence'));
    body.appendChild(el('p', { 'class': 'muted' }, 'Describe the physical failure sequence between the deviation and the hazardous event. Write it conditionally ("may", "if"): recording a mechanism does not mean each step will occur.'));
    body.appendChild(PHA.ui.field('Failure sequence / mechanism', PHA.ui.area(q.mechanism, function (v) { q.mechanism = v; },
      { 'data-focus': 'seq-mech', placeholder: 'e.g. Pump deadheads; prolonged operation may overheat the pump and damage the mechanical seal.' })));
    body.appendChild(el('div', { 'class': 'row' },
      PHA.ui.field('Hazardous event', PHA.ui.select(q.eventType, [['loc', 'Loss of containment'], ['other', 'Other hazardous event']], function (e) {
        var v = e.target.value; store.change(function () { q.eventType = v; }, 'field');
      }, 'Type of event'), 'w-evtype'),
      PHA.ui.field('Event description', PHA.ui.text(q.event, function (v) { q.event = v; },
        { 'data-focus': 'seq-event', placeholder: 'e.g. Mechanical seal loses integrity and releases toluene' }), 'grow')));
    body.appendChild(el('label', { 'class': 'chk-inline' }, el('input', { type: 'checkbox', 'data-seq-direct': '1', checked: q.direct ? true : null, onchange: function (e) {
      var v = e.target.checked; store.change(function () { q.direct = v; });
    } }), 'No intermediate mechanism: the consequences follow directly from the deviation'));
  }

  /* The reasoning chain for the scenario so far: cause > deviation > mechanism > hazardous event > consequences. */
  function chain(p, sc, here) {
    var q = sc.sequence || {}, box = el('div', { 'class': 'chain' });
    function link(label, content, key) {
      box.appendChild(el('div', { 'class': 'chain-step' + (key === here ? ' here' : '') + (content ? '' : ' empty') }, el('span', { 'class': 'chain-l' }, label),
        el('span', { 'class': 'chain-v' }, content || 'not recorded yet')));
    }
    link('Initiating cause', sc.causes.filter(function (c) { return txt(c.text); }).map(function (c) { return c.text; }).join('; '), 'causes');
    link('Deviation', sc.deviation, 'deviation');
    link('Failure sequence', q.direct ? 'None: consequences follow directly' : q.mechanism, 'sequence');
    link(q.eventType === 'loc' ? 'Loss of containment' : 'Hazardous event', q.event, 'sequence');
    link('Consequences', sc.consequences.filter(function (c) { return txt(c.text); }).map(function (c) { return c.text + (txt(c.escalation) ? ' (' + c.escalation + ')' : ''); }).join('; '), 'consequences');
    return box;
  }

  function render(root) {
    var S = store.S, p = S.project, w = ui().wizard, n = p.nodes[w.nodeId];
    if (!n) { ui().wizard = null; return false; }
    if (w.scenarioId && !p.scenarios[w.scenarioId]) w.scenarioId = null;
    if (w.devId && !p.deviations[w.devId]) w.devId = null;
    var sc = w.scenarioId && p.scenarios[w.scenarioId];
    var d = w.devId && p.deviations[w.devId];
    var hasDev = !!(d || (w.draft.parameter && w.draft.guideword));
    if (w.step >= CAUSES && !sc) w.step = hasDev ? 2 : 1;
    if (w.step === 2 && !hasDev) w.step = 1;
    var large = false;
    try { large = localStorage.getItem('pha.wizLarge') === '1'; } catch (e) { /* ignore */ }

    var box = el('div', { 'class': 'wizard' + (large ? ' large' : ''), 'data-step': w.step });
    box.appendChild(el('div', { 'class': 'wiz-head', style: { borderTopColor: n.color } },
      el('div', { 'class': 'wiz-title' }, el('span', { 'class': 'flabel' }, 'Scenario wizard'),
        el('div', null, el('b', null, n.displayId), ' ', n.name || '', sc ? el('span', { 'class': 'tag' }, sc.displayId) : null,
          d && d.text ? el('span', { 'class': 'wiz-dev' }, d.text) : null)),
      el('div', { 'class': 'grow' }),
      el('button', { 'data-act': 'wiz-large', title: 'Larger text for a meeting-room screen', 'aria-pressed': large ? 'true' : 'false', onclick: function () {
        try { localStorage.setItem('pha.wizLarge', large ? '0' : '1'); } catch (e) { /* ignore */ }
        PHA.panel.render();
      } }, large ? 'A−' : 'A+'),
      sc ? el('button', { title: 'Show every field of this scenario at once', onclick: function () { ui().wizard = null; store.select(n.id, sc.id); } }, 'Full editor') : null,
      el('button', { 'data-act': 'wiz-close', onclick: close }, 'Close')));
    box.appendChild(stepBar(w, hasDev, !!sc));
    var body = el('div', { 'class': 'wiz-body' });
    var nextOk = true, nextLabel = 'Next', nextFn = function () { go(w.step + 1); };

    if (w.step === 1) {
      stepDeviation(p, n, w, body);
      nextOk = hasDev; nextLabel = 'Next: applicability';
    } else if (w.step === 2) {
      stepApplicability(p, n, w, body);
      var st = d && d.status;
      if (st === 'yes') {
        var scs = store.deviationScenarios(p, d.id);
        if (w.mode === 'analyse') {
          if (sc) nextLabel = 'Next: causes';
          else if (scs.length === 1) { nextLabel = 'Next: causes'; nextFn = function () { w.scenarioId = scs[0].id; store.S.sel.scenarioId = scs[0].id; go(CAUSES); }; }
          else if (scs.length > 1) nextOk = false;
          else { nextLabel = 'Create scenario and continue'; nextFn = function () { ensureScenario(store.S.project, w); go(CAUSES); }; }
        } else if (w.mode === 'no-credible-scenario' || w.mode === 'covered-elsewhere') {
          nextLabel = 'Save disposition'; nextOk = !!txt(d.disposition);
          nextFn = function () {
            var dd = store.S.project.deviations[w.devId];
            if (!txt(dd.disposition)) return;
            PHA.panel.flash('Recorded: ' + dd.text + ': ' + R.devState(store.S.project, dd).label + '.'); close();
          };
        } else nextOk = false;
      } else if (st === 'no') {
        nextLabel = 'Save decision'; nextOk = !!txt(d.reason);
        nextFn = function () { if (!txt(store.S.project.deviations[w.devId].reason)) return; PHA.panel.flash('Recorded: ' + d.text + ' is not applicable.'); close(); };
      } else if (st === 'not-reviewed') {
        nextLabel = 'Save as outstanding'; nextFn = function () { PHA.panel.flash(d.text + ' is recorded as not reviewed.'); close(); };
      } else nextOk = false;
    } else if (w.step === 3) {
      body.appendChild(el('p', { 'class': 'wq' }, 'What could cause ', el('b', null, sc.deviation || 'this deviation'), '?'));
      body.appendChild(el('p', { 'class': 'muted' }, 'Add each initiating cause separately, typed or from Quick Add. If one cause leads to clearly different consequences or safeguards, give it its own scenario.'));
      body.appendChild(causeList(p, sc));
    } else if (w.step === 4) {
      stepSequence(p, n, sc, body);
    } else if (w.step === 5) {
      body.appendChild(el('p', { 'class': 'wq' }, 'What are the credible ultimate consequences?'));
      body.appendChild(chain(p, sc, 'consequences'));
      body.appendChild(el('p', { 'class': 'muted' }, 'Record each outcome separately (exposure, environmental release, fire...). Put what must also happen, such as ignition, in its escalation conditions.' + (sc.causes.length > 1 ? ' Mark which causes a consequence follows from if it does not follow from all of them.' : '')));
      body.appendChild(consequenceList(p, sc));
    } else if (w.step === 6) {
      body.appendChild(el('p', { 'class': 'wq' }, 'What existing safeguards apply?'));
      body.appendChild(el('div', { 'class': 'caution' }, 'Listing a safeguard does not mean it is effective or independent. Note whether it prevents the consequence or mitigates it.' +
        (PHA.modules.enabled(p, n, 'safeguardEvaluation') ? '' : ' Turn on Safeguard evaluation in Modules to record independence and dependability.')));
      body.appendChild(safeguardList(p, n, sc));
    } else if (w.step === 7) {
      body.appendChild(el('p', { 'class': 'wq' }, 'How does the team rank the risk?'));
      var rm = p.project.riskMatrix;
      body.appendChild(el('p', { 'class': 'muted' }, 'Using the study\'s ' + (rm.rule === 'table' ? 'cell-table' : 'severity x likelihood') + ' risk matrix' + (rm.source ? ' (' + rm.source + ')' : ' (no source reference recorded)') +
        (rm.rankBy === 'consequence' ? ', ranking each consequence separately.' : '.')));
      var rb = PHA.modules.riskBlock(p, n, sc, null);
      body.appendChild(rb || el('div', { 'class': 'muted pad' }, 'The Risk matrix module is turned off for this node. Turn it on in Modules to rank risk.'));
    } else if (w.step === 8) {
      body.appendChild(el('p', { 'class': 'wq' }, 'Recommendations'));
      body.appendChild(recommendationList(p, sc));
      body.appendChild(el('p', { 'class': 'wq' }, 'Summary'));
      body.appendChild(PHA.board ? PHA.board.card(p, sc, { static: true, expanded: true }) : el('div'));
      body.appendChild(statusControl(p, sc));
      nextLabel = 'Finish'; nextFn = close;
      body.appendChild(el('div', { 'class': 'row end' },
        el('button', { title: 'Another scenario for the same deviation, for a cause with different consequences', onclick: function () { ensureScenario(store.S.project, w, true); go(CAUSES); } }, '+ Another scenario for this deviation'),
        el('button', { onclick: function () { start(n.id); } }, '+ Review another deviation')));
    }
    box.appendChild(body);
    box.appendChild(el('div', { 'class': 'wiz-foot' },
      el('button', { 'data-act': 'wiz-back', disabled: w.step === 1 ? true : null, onclick: function () { go(w.step - 1); } }, '◀ Back'),
      el('div', { 'class': 'grow' }),
      el('span', { 'class': 'muted small' }, 'Step ' + w.step + ' of ' + LAST + '. Entries are saved as you type.'),
      el('button', { 'class': 'primary', 'data-next': '1', disabled: nextOk ? null : true, onclick: nextFn }, nextLabel)));
    root.appendChild(box);
    return true;
  }

  PHA.wizard = { STEPS: STEPS, CAUSES: CAUSES, chain: chain, start: start, close: close, go: go, render: render, active: function () { return !!(store.S.ui && store.S.ui.wizard); } };
  PHA.items = { itemList: itemList, causeList: causeList, consequenceList: consequenceList, safeguardList: safeguardList,
                recommendationList: recommendationList, statusControl: statusControl };
})();
