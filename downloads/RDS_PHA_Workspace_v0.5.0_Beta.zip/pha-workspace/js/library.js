/* library.js: Quick-Add libraries of reusable cause and consequence wording (0.5.0).
   Three sources, merged for the picker:
     built-in  generic wording written for this application (read-only; copy it to change it)
     project   p.library.templates: travels with the project in .phaz files
     personal  this browser's own templates, kept in the repository's settings store (IndexedDB 'kv')
   Inserting a template only inserts editable text. It does not establish that the cause or consequence is
   credible: inserted items start as "pending team confirmation". Placeholders such as [Material] are filled only
   with values the user types or picks; suggestions come from project records and are never filled in automatically. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util;

  var STANDARD = ['Material', 'Equipment', 'Tag', 'Location', 'Operation', 'Failure Event'];
  var TOKEN = /\[([A-Za-z][A-Za-z ]{0,30}[A-Za-z]|[A-Za-z])\]/g;

  /* Original, generic wording. Not taken from any commercial template library. */
  var BUILTIN = [
    { id: 'b-cau-01', kind: 'cause', category: 'Valve position', text: 'Manual isolation valve [Tag] remains closed during [Operation].' },
    { id: 'b-cau-02', kind: 'cause', category: 'Valve position', text: 'Manual valve [Tag] left open after [Operation].' },
    { id: 'b-cau-03', kind: 'cause', category: 'Control failure', text: 'Control valve [Tag] fails closed.' },
    { id: 'b-cau-04', kind: 'cause', category: 'Control failure', text: 'Control valve [Tag] fails open.' },
    { id: 'b-cau-05', kind: 'cause', category: 'Instrument', text: 'Instrument [Tag] provides an incorrect indication.' },
    { id: 'b-cau-06', kind: 'cause', category: 'Rotating equipment', text: 'Pump [Tag] fails to start.' },
    { id: 'b-cau-07', kind: 'cause', category: 'Rotating equipment', text: 'Pump [Tag] stops while running.' },
    { id: 'b-cau-08', kind: 'cause', category: 'Utility loss', text: 'Loss of electrical power to [Equipment].' },
    { id: 'b-cau-09', kind: 'cause', category: 'Utility loss', text: 'Loss of instrument air to [Equipment].' },
    { id: 'b-cau-10', kind: 'cause', category: 'Human action', text: 'Operator lines up the wrong tank or line during [Operation].' },
    { id: 'b-cau-11', kind: 'cause', category: 'Human action', text: 'Step omitted or performed out of sequence during [Operation].' },
    { id: 'b-cau-12', kind: 'cause', category: 'Material', text: 'Wrong material delivered: [Material] received instead of the intended material.' },
    { id: 'b-cau-13', kind: 'cause', category: 'Mechanical', text: 'Blockage or plugging of the line at [Location].' },
    { id: 'b-cau-14', kind: 'cause', category: 'Mechanical', text: 'Check valve [Tag] fails to close.' },
    { id: 'b-cau-15', kind: 'cause', category: 'Mechanical', text: 'Corrosion or erosion of [Equipment].' },
    { id: 'b-cau-16', kind: 'cause', category: 'External', text: 'External fire near [Equipment].' },
    { id: 'b-cau-17', kind: 'cause', category: 'Maintenance', text: '[Equipment] returned to service out of its normal configuration after maintenance.' },
    { id: 'b-csq-01', kind: 'consequence', category: 'Personnel exposure', text: 'Potential personnel injury from exposure to [Material].' },
    { id: 'b-csq-02', kind: 'consequence', category: 'Environmental release', text: 'Potential environmental release of [Material].' },
    { id: 'b-csq-03', kind: 'consequence', category: 'Fire', text: 'Potential fire following ignition of released [Material].' },
    { id: 'b-csq-04', kind: 'consequence', category: 'Explosion', text: 'Potential explosion if a flammable atmosphere of [Material] forms at [Location] and is ignited.' },
    { id: 'b-csq-05', kind: 'consequence', category: 'Equipment damage', text: 'Potential damage to [Equipment] following [Failure Event].' },
    { id: 'b-csq-06', kind: 'consequence', category: 'Overpressure', text: 'Potential overpressure of [Equipment], with possible loss of containment.' },
    { id: 'b-csq-07', kind: 'consequence', category: 'Overflow', text: 'Potential overflow of [Equipment] to [Location].' },
    { id: 'b-csq-08', kind: 'consequence', category: 'Business interruption', text: 'Potential interruption of [Operation].' },
    { id: 'b-csq-09', kind: 'consequence', category: 'Product quality', text: 'Potential off-specification product in [Equipment].' }
  ];

  /* ---------- placeholders ---------- */
  function placeholders(text) {
    var seen = {}, out = [], m;
    TOKEN.lastIndex = 0;
    while ((m = TOKEN.exec(String(text || '')))) { if (!seen[m[1]]) { seen[m[1]] = 1; out.push(m[1]); } }
    return out;
  }
  /* Replace each placeholder that has a non-blank value. Blank values leave the [Placeholder] in the text, visibly. */
  function fill(text, values) {
    values = values || {};
    return String(text || '').replace(TOKEN, function (all, name) {
      var v = values[name];
      return v != null && String(v).trim() ? String(v).trim() : all;
    });
  }
  /* Placeholders still in a library-inserted item. Only items that came from a template are checked, so typed
     engineering text that happens to contain brackets is never flagged. */
  function unfilled(item) {
    if (!item || !item.source || item.source.kind !== 'library') return [];
    var tpl = placeholders(item.source.template || '');
    return placeholders(item.text).filter(function (n) { return tpl.indexOf(n) >= 0; });
  }

  /* Suggested values from existing project records. Never fills anything in; never invents a value. */
  function suggestions(p, sc, name) {
    var out = [], seen = {};
    function add(v, from) { v = String(v || '').trim(); if (v && !seen[v.toLowerCase()]) { seen[v.toLowerCase()] = 1; out.push({ value: v, from: from }); } }
    var n = sc && p.nodes[sc.nodeId];
    var key = name.toLowerCase();
    if (n && (key === 'tag' || key === 'equipment')) {
      (n.equipmentIds || []).forEach(function (id) {
        var e = p.equipment[id]; if (!e) return;
        if (key === 'tag') add(e.tag, 'node equipment');
        else add(e.tag + (e.description ? ' ' + e.description : ''), 'node equipment');
      });
    }
    if (key === 'failure event' && sc && sc.sequence) add(sc.sequence.event, 'this scenario\'s hazardous event');
    if (key === 'location' && n && n.name) add(n.name, 'node name');
    ((p.library && p.library.values && p.library.values[name]) || []).forEach(function (v) { add(v, 'used before in this project'); });
    return out;
  }
  /* Remember the values the team typed, so they are offered again in this project. Call inside store.change. */
  function remember(p, values) {
    p.library = p.library || { templates: [], values: {} };
    Object.keys(values || {}).forEach(function (k) {
      var v = String(values[k] || '').trim(); if (!v) return;
      var arr = (p.library.values[k] = p.library.values[k] || []);
      var i = arr.map(function (x) { return x.toLowerCase(); }).indexOf(v.toLowerCase());
      if (i >= 0) arr.splice(i, 1);
      arr.unshift(v);
      if (arr.length > 12) arr.length = 12;
    });
  }

  /* ---------- personal library (this browser) ---------- */
  var personal = { templates: [], favorites: [] }, personalState = 'not-loaded', listeners = [];
  function normalizePersonal(v) {
    v = v && typeof v === 'object' ? v : {};
    return { templates: Array.isArray(v.templates) ? v.templates : [], favorites: Array.isArray(v.favorites) ? v.favorites : [] };
  }
  async function loadPersonal() {
    try {
      if (!PHA.repo || !PHA.repo.isOpen()) { personalState = 'unavailable'; return personal; }
      personal = normalizePersonal(await PHA.repo.kvGet('library.personal'));
      personalState = 'loaded';
    } catch (e) { personalState = 'unavailable'; }
    listeners.forEach(function (f) { f(); });
    return personal;
  }
  /* Saves a changed copy; the in-memory library only changes once the save has succeeded. */
  async function savePersonal(next) {
    if (!PHA.repo || !PHA.repo.isOpen()) throw new Error('The browser storage is not available, so personal templates cannot be saved. Save the template to the project instead.');
    await PHA.repo.kvSet('library.personal', next);
    personal = normalizePersonal(next);
    personalState = 'loaded';
    listeners.forEach(function (f) { f(); });
  }
  function copyPersonal() { return JSON.parse(JSON.stringify(personal)); }

  /* ---------- merged view ---------- */
  function all(p, kind) {
    var favP = personal.favorites || [];
    var out = [];
    ((p.library && p.library.templates) || []).forEach(function (t) { out.push(Object.assign({}, t, { scope: 'project', fav: !!t.favorite })); });
    (personal.templates || []).forEach(function (t) { out.push(Object.assign({}, t, { scope: 'personal', fav: favP.indexOf(t.id) >= 0 })); });
    BUILTIN.forEach(function (t) { out.push(Object.assign({}, t, { scope: 'builtin', fav: favP.indexOf(t.id) >= 0 })); });
    return out.filter(function (t) { return !kind || t.kind === kind; });
  }
  function newTemplate(kind, text, category) { return { id: U.uid('tpl'), kind: kind, category: category || '', text: String(text || ''), favorite: false }; }

  /* Normalized text for duplicate checks: case, spacing and a final full stop do not make a different cause. */
  function sameText(a, b) {
    function k(s) { return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim().replace(/[.\s]+$/, ''); }
    return k(a) !== '' && k(a) === k(b);
  }

  PHA.library = {
    BUILTIN: BUILTIN, STANDARD: STANDARD, placeholders: placeholders, fill: fill, unfilled: unfilled, suggestions: suggestions,
    remember: remember, loadPersonal: loadPersonal, savePersonal: savePersonal, copyPersonal: copyPersonal,
    personalState: function () { return personalState; }, onChange: function (f) { listeners.push(f); },
    all: all, newTemplate: newTemplate, sameText: sameText
  };
})();
