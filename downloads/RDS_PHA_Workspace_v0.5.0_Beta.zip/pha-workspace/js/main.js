/* main.js: starts the app and wires the toolbar, keyboard and events between modules. Loaded last. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, V = PHA.viewer, A = PHA.annotate, P = PHA.persist;
  function $(id) { return document.getElementById(id); }

  function fillDrawings() {
    var sel = $('drawingSel'), p = store.S.project;
    sel.textContent = '';
    var ids = Object.keys(p.drawings);
    if (!ids.length) sel.appendChild(el('option', { value: '' }, 'No drawings'));
    ids.forEach(function (id, i) {
      var d = p.drawings[id];
      sel.appendChild(el('option', { value: id }, (i + 1) + '/' + ids.length + '  ' + (d.number || d.file.name) + (d.revision ? '  Rev ' + d.revision : '')));
    });
    sel.value = store.S.drawingId || '';
    sel.disabled = ids.length === 0;
    $('btnPrev').disabled = $('btnNext').disabled = ids.length < 2;
  }

  function stepDrawing(dir) {
    var ids = Object.keys(store.S.project.drawings), i = ids.indexOf(store.S.drawingId);
    if (ids.length < 2) return;
    store.setDrawing(ids[(i + dir + ids.length) % ids.length]);
  }

  /* Local save status. "Saved locally" appears only after the repository transaction has completed. */
  function updateState() {
    var S = store.S, st = PHA.autosave.state(), pill = $('saveState'), cls = '', msg = '', tip = 'Local save status';
    if (st.status === 'saving') { cls = 'saving'; msg = 'Saving...'; }
    else if (st.status === 'failed') { cls = 'failed'; msg = 'Save failed'; tip = ((st.error && st.error.message) || '') + ' Click for options.'; }
    else if (st.status === 'volatile') { cls = 'failed'; msg = 'Not saved locally'; tip = 'The repository is unavailable. Export a .phaz file to keep this work.'; }
    else if (st.status === 'dirty' || S.dirty) { cls = 'dirty'; msg = 'Unsaved changes'; }
    else if (st.status === 'saved') { cls = 'saved'; msg = 'Saved locally' + (st.at ? ' ' + U.clock(st.at) : ''); tip = 'Saved in this browser\'s repository. Export a .phaz file for a permanent copy.'; }
    pill.className = 'pill ' + cls;
    pill.textContent = msg;
    pill.title = tip;
    pill.hidden = !msg;
    if (document.body.dataset.view === 'editor') document.title = (S.dirty ? '* ' : '') + (S.project.project.name || 'Untitled') + ' - PHA Workspace';
  }

  /* Backup status, from what the repository knows about the last export. */
  function updateBackup() {
    var sess = PHA.autosave.session(), pill = $('backupState');
    if (!sess || sess.volatile || !sess.meta) { pill.hidden = true; return; }
    var bs = PHA.repo.backupStatus(sess.meta);
    pill.hidden = false;
    pill.className = 'pill bk-' + bs.level;
    pill.textContent = bs.level === 'ok' ? 'Exported' : bs.level === 'imported' ? 'Matches import' : bs.level === 'unconfirmed' ? 'Download started' : bs.level === 'changed' ? 'Export out of date' : 'Not exported';
    pill.title = bs.text + '.';
  }

  async function saveProblem() {
    var st = PHA.autosave.state(), D = PHA.dashboard;
    if (st.status !== 'failed') { if (st.status === 'volatile') D.tell('Not saved locally', 'The repository is unavailable in this browser. Use Export .phaz to keep this work.'); return; }
    var code = st.error.code, k;
    if (code === 'conflict') {
      k = await D.ask('This project was changed in another window', st.error.message + ' Choose what to do with the version in this window.', [
        { key: null, label: 'Decide later' }, { key: 'overwrite', label: 'Overwrite the other version', cls: 'danger' }, { key: 'copy', label: 'Save mine as a separate project', cls: 'primary' }]);
      if (k) await PHA.autosave.resolve(k);
    } else if (code === 'missing') {
      k = await D.ask('This project is no longer in the repository', st.error.message, [{ key: null, label: 'Decide later' }, { key: 'recreate', label: 'Put it back from this window', cls: 'primary' }]);
      if (k) await PHA.autosave.resolve('recreate');
    } else {
      k = await D.ask('The local save failed', st.error.message, [{ key: null, label: 'Close' }, { key: 'export', label: 'Export .phaz now' }, { key: 'retry', label: 'Try again', cls: 'primary' }]);
      if (k === 'retry') await PHA.autosave.retry();
      if (k === 'export') await P.save(true);
    }
    $('projName').value = store.S.project.project.name || '';
  }

  function updateZoom() {
    var vi = V.info();
    $('zoomPct').textContent = vi.W ? Math.round(vi.k / vi.fitK * 100) + '%' : '–';
  }

  function updateHistory() {
    $('btnUndo').disabled = !store.canUndo();
    $('btnRedo').disabled = !store.canRedo();
  }

  function showNotice(text) {
    var b = $('banner');
    b.textContent = '';
    b.appendChild(el('span', null, text));
    b.appendChild(el('button', { id: 'btnNoticeOk', onclick: function () { b.hidden = true; } }, 'OK'));
    b.hidden = false;
  }

  function wire() {
    /* store -> views */
    store.on('project', function () {
      $('projName').value = store.S.project.project.name || '';
      fillDrawings(); V.show(); PHA.panel.render(); A.setMode('select'); updateState(); PHA.board.refresh();
    });
    store.on('change', function (d) {
      if (d.kind === 'struct') { fillDrawings(); PHA.panel.render(); }
      else if (d.kind === 'field') PHA.panel.refreshChips();
      A.render(); PHA.autosave.schedule(); updateState();
      PHA.modules.refreshConfig(d.kind);
      if (d.kind === 'field') PHA.board.refreshSoon(); else PHA.board.refresh();
    });
    /* undo / redo replaced the whole project object: redraw everything from it */
    store.on('restore', function (d) {
      $('projName').value = store.S.project.project.name || '';
      fillDrawings();
      if (d && d.drawingChanged) V.show(); else if (!V.info().W && store.S.drawingId) V.show();
      PHA.panel.render(); A.render(); PHA.autosave.schedule(); updateState();
      PHA.modules.refreshConfig('struct');
      PHA.board.refresh();
    });
    store.on('history', updateHistory);
    store.on('select', function () { PHA.panel.render(); A.render(); PHA.board.refresh(); });
    store.on('drawing', function () { $('drawingSel').value = store.S.drawingId || ''; V.show(); PHA.panel.render(); });
    PHA.autosave.onState(function () { updateState(); updateBackup(); });
    P.onEvent(function (d) {
      updateBackup();
      if (d && d.exported && !d.exported.confirmed) {
        showNotice('A download was started as ' + d.exported.fileName + '. The browser does not report whether it finished: check your Downloads folder before relying on it.');
      }
    });
    V.onView(function () { A.render(); updateZoom(); });
    A.onMode(function (m) {
      Array.prototype.forEach.call(document.querySelectorAll('#tools button'), function (b) { b.classList.toggle('on', b.dataset.mode === m); });
    });

    /* top bar */
    $('projName').addEventListener('input', function (e) {
      var v = e.target.value;
      store.change(function (p) { p.project.name = v; }, 'field');
    });
    $('btnRepo').onclick = function () { PHA.dashboard.leaveEditor(); };
    $('btnDetails').onclick = function () { PHA.dashboard.editDetails(); };
    $('btnStudy').onclick = function () { PHA.study.open(); };
    $('btnReport').onclick = function () { PHA.report.open(); };
    $('saveState').onclick = saveProblem;
    $('btnSave').onclick = function () { P.save(false); };
    $('btnSaveAs').onclick = function () { P.save(true); };
    $('btnExport').onclick = function () { P.exportJson(); };
    $('btnDiag').onclick = function () { PHA.diag.open(); };
    $('btnUndo').onclick = function () { store.undo(); };
    $('btnRedo').onclick = function () { store.redo(); };
    $('btnModules').onclick = function () { PHA.modules.openConfig(); };

    /* viewer toolbar */
    function pickPdf() { $('pdfInput').click(); }
    $('btnImport').onclick = pickPdf;
    $('btnImport2').onclick = pickPdf;
    $('pdfInput').addEventListener('change', function (e) {
      if (e.target.files.length) P.importPdfs(e.target.files);
      e.target.value = '';
    });
    $('drawingSel').addEventListener('change', function (e) { if (e.target.value) store.setDrawing(e.target.value); });
    $('btnPrev').onclick = function () { stepDrawing(-1); };
    $('btnNext').onclick = function () { stepDrawing(1); };
    $('tools').addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) return;
      if ((b.dataset.mode === 'polygon' || b.dataset.mode === 'rect') && !V.info().W) { alert('Import a P&ID first.'); return; }
      A.setMode(b.dataset.mode);
    });
    $('btnZoomIn').onclick = function () { V.zoomAt(1.4); };
    $('btnZoomOut').onclick = function () { V.zoomAt(1 / 1.4); };
    $('btnFit').onclick = function () { V.fit(); };
    $('btnLabels').onclick = function () { A.cycleLabels(); };
    A.onLabels(function (m) { $('btnLabels').textContent = m === 'name' ? 'Labels: ID + name' : 'Labels: ID'; });

    /* drag and drop: on the repository screen project files are imported; in the editor PDFs become drawings */
    document.addEventListener('dragover', function (e) { e.preventDefault(); });
    document.addEventListener('drop', function (e) {
      e.preventDefault();
      var files = Array.prototype.slice.call(e.dataTransfer.files || []);
      var pdfs = files.filter(function (f) { return /\.pdf$/i.test(f.name); });
      var proj = files.filter(function (f) { return /\.(phaz|zip|json)$/i.test(f.name); });
      if (document.body.dataset.view === 'dash') { if (proj.length) PHA.dashboard.importFiles(proj); }
      else if (pdfs.length) P.importPdfs(pdfs);
      else if (proj.length) PHA.dashboard.tell('Import from the repository screen', 'Go back to Projects to import a project file. It will be added as its own project.');
    });

    /* keyboard */
    document.addEventListener('keydown', function (e) {
      var mod = e.ctrlKey || e.metaKey;
      if (document.body.dataset.view === 'report' && mod && e.key.toLowerCase() === 'p') { e.preventDefault(); window.print(); return; }
      if (document.body.dataset.view !== 'editor') return;
      if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); P.save(e.shiftKey); return; }
      // Inside a text box, Ctrl+Z stays the browser's own text undo. Elsewhere it undoes the last project change.
      if (mod && !U.isTyping(e) && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) store.redo(); else store.undo(); return; }
      if (mod && !U.isTyping(e) && e.key.toLowerCase() === 'y') { e.preventDefault(); store.redo(); return; }
      if (mod || e.altKey || U.isTyping(e)) return;
      if (document.querySelector('dialog[open]')) return;
      if (PHA.board.isVisible()) return;                    // drawing keys only act when the P&ID is shown
      var k = e.key.toLowerCase();
      if (k === 'v') A.setMode('select');
      else if (k === 'h') A.setMode('pan');
      else if (k === 'p' && V.info().W) A.setMode('polygon');
      else if (k === 'r' && V.info().W) A.setMode('rect');
      else if (k === '+' || k === '=') V.zoomAt(1.4);
      else if (k === '-') V.zoomAt(1 / 1.4);
      else if (k === '0') V.fit();
    });

    /* Leaving with edits not yet in the repository: ask first, and keep a synchronous copy in case the save cannot finish. */
    window.addEventListener('beforeunload', function (e) {
      if (store.S.dirty && PHA.autosave.session()) { PHA.autosave.onPageHide(); e.preventDefault(); e.returnValue = ''; }
    });
    window.addEventListener('pagehide', function () { PHA.autosave.onPageHide(); });
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') PHA.autosave.onPageHide(); });

    /* splitter */
    var sp = $('splitter'), panel = $('panel');
    try { var w = localStorage.getItem('pha.panelW'); if (w) panel.style.width = w + 'px'; } catch (e) { /* ignore */ }
    sp.addEventListener('pointerdown', function (e) {
      sp.setPointerCapture(e.pointerId);
      function move(ev) { panel.style.width = U.clamp(ev.clientX, 320, window.innerWidth - 360) + 'px'; }
      function up(ev) {
        sp.releasePointerCapture(ev.pointerId);
        sp.removeEventListener('pointermove', move); sp.removeEventListener('pointerup', up);
        try { localStorage.setItem('pha.panelW', parseInt(panel.style.width, 10)); } catch (err) { /* ignore */ }
      }
      sp.addEventListener('pointermove', move); sp.addEventListener('pointerup', up);
    });
  }

  function start() {
    if (!window.pdfjsLib || !window.fflate) {
      document.body.textContent = 'A library file failed to load. Keep index.html together with its css, js and lib folders.';
      return;
    }
    V.init(); A.init(); PHA.panel.init(); PHA.board.init(); PHA.report.init();
    wire();
    store.newProject();
    updateHistory();
    PHA.repo.open().then(function () { PHA.library.loadPersonal(); return PHA.dashboard.init(null); }, function (e) { return PHA.dashboard.init(e); });
  }

  PHA.main = { fillDrawings: fillDrawings, refreshPills: function () { updateState(); updateBackup(); } };
  start();
})();
