/* repo.js: the local project repository (IndexedDB). No screen code.

   Database "pha-workspace", schema version 2:
     projects  one small catalog row per project (name, status, counts, dates, revision, backup info)
     docs      the full project record as JSON text, one per project
     files     the original PDF bytes, keyed by SHA-256, shared between projects that use the same drawing
     kv        settings, and anything kept from older app versions

   The dashboard reads only "projects". PDFs are read only when a project is opened or exported.
   Every save is one transaction over projects + docs + files, so a project is never half written,
   and a save is reported as done only after that transaction has completed. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util;

  var DB_NAME = 'pha-workspace', DB_VERSION = 2;
  var db = null, dbName = null, listeners = [];
  var api = {};

  function RepoError(code, message, extra) {
    var e = new Error(message);
    e.code = code;
    if (extra) Object.keys(extra).forEach(function (k) { e[k] = extra[k]; });
    return e;
  }

  /* Turn any failure into a code and a plain sentence for the user. */
  function classify(e) {
    var name = (e && e.name) || '', code = (e && e.code) || '', msg = (e && e.message) || String(e);
    if (typeof code === 'string' && ['conflict', 'missing', 'exists', 'identity', 'unavailable', 'newer', 'blocked', 'invalid'].indexOf(code) >= 0) return { code: code, message: msg };
    if (name === 'QuotaExceededError' || /quota/i.test(msg)) {
      return { code: 'quota', message: 'The browser\'s storage is full, so this change was not saved locally. Export the project to a .phaz file now, then free space by exporting and deleting projects you no longer need here.' };
    }
    if (name === 'VersionError') return { code: 'newer', message: 'This browser\'s project repository was created by a newer version of PHA Workspace. Open it with that version.' };
    if (name === 'InvalidStateError' || name === 'SecurityError' || name === 'UnknownError') {
      return { code: 'unavailable', message: 'The browser is not allowing local storage right now (' + name + '). Export the project to a .phaz file to keep your work.' };
    }
    return { code: 'failed', message: 'The local save did not complete (' + (name || 'error') + ': ' + msg + ').' };
  }

  function req(r) {
    return new Promise(function (res, rej) {
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
  }

  /* Compact copy: a typed array that is a window onto a bigger buffer would otherwise be stored with the whole buffer. */
  function compact(b) {
    if (!(b instanceof Uint8Array)) b = new Uint8Array(b);
    return (b.byteOffset === 0 && b.byteLength === b.buffer.byteLength) ? b : b.slice();
  }

  /* ---------- catalog row ---------- */

  /* 0.4.0: a small completion summary kept on the catalog row for the printable register. */
  function completionOf(project) {
    try { return (PHA.review && project.deviations) ? PHA.review.catalogCompletion(project) : null; } catch (e) { return null; }
  }
  function metaFrom(project, prev) {
    var pr = project.project || {}, shas = {}, fileBytes = 0;
    Object.keys(project.drawings || {}).forEach(function (k) {
      var f = project.drawings[k].file || {};
      if (f.sha256 && !shas[f.sha256]) { shas[f.sha256] = true; fileBytes += f.bytes || 0; }
    });
    var recs = Object.keys(project.recommendations || {}).map(function (k) { return project.recommendations[k]; });
    return {
      id: pr.id,
      name: pr.name || '',
      facility: pr.facility || '',
      studyType: pr.studyType || '',
      methodology: pr.method || '',
      status: pr.status || 'draft',
      createdAt: pr.createdAt || null,
      modifiedAt: pr.modifiedAt || pr.createdAt || null,
      nodeCount: Object.keys(project.nodes || {}).length,
      scenarioCount: Object.keys(project.scenarios || {}).length,
      drawingCount: Object.keys(project.drawings || {}).length,
      openRecommendations: recs.filter(function (r) { return r.status !== 'closed'; }).length,
      revision: pr.revision || '',
      completion: completionOf(project),
      fileShas: Object.keys(shas),
      fileBytes: fileBytes,
      schemaVersion: project.schemaVersion,
      source: pr.source || null,
      rev: prev ? prev.rev : 0,
      savedAt: prev ? prev.savedAt : null,
      lastExport: prev ? (prev.lastExport || null) : null,
      importedFrom: prev ? (prev.importedFrom || null) : null,
      missingFiles: []
    };
  }

  /* What is known about a project's backup. Never claims more than the browser confirmed. */
  function backupStatus(meta) {
    var le = meta.lastExport, im = meta.importedFrom;
    function d(t) { return new Date(t).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); }
    if (le) {
      if (meta.rev > le.rev) return { level: 'changed', needs: true, text: 'Changed since the last export (' + d(le.at) + ')' };
      if (!le.confirmed) return { level: 'unconfirmed', needs: false, text: 'Download started ' + d(le.at) + '. The browser does not confirm it reached the disk' };
      return { level: 'ok', needs: false, text: 'Exported ' + d(le.at) + (le.fileName ? ' to ' + le.fileName : '') };
    }
    if (im) {
      if (meta.rev > im.rev) return { level: 'changed', needs: true, text: 'Changed since it was imported; not exported' };
      return { level: 'imported', needs: false, text: 'Matches the imported file ' + (im.fileName || '') };
    }
    return { level: 'none', needs: true, text: 'Only in this browser\'s storage. Never exported' };
  }

  /* ---------- schema and migrations ---------- */

  /* One step per schema version. A step only adds stores or moves data forward; it never drops user data. */
  var MIGRATIONS = {
    1: function (d) {
      if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
    },
    2: function (d, t) {
      d.createObjectStore('projects', { keyPath: 'id' });
      d.createObjectStore('docs', { keyPath: 'id' });
      d.createObjectStore('files', { keyPath: 'sha' });
      // Versions 0.1 and 0.2 kept one unsaved "recovery copy" in kv. Bring it into the repository as a project.
      var kv = t.objectStore('kv');
      kv.get('project').onsuccess = function (ev) {
        var rec = ev.target.result;
        if (!rec || !rec.json) return;
        try {
          var project = PHA.store.migrate(JSON.parse(rec.json));
          if (!Object.keys(project.drawings).length && !Object.keys(project.nodes).length) return;
          if (!project.project.name) project.project.name = 'Recovered work';
          project.project.source = project.project.source || { type: 'legacy-recovery', at: new Date().toISOString(), fileName: rec.fileName || null };
          var meta = metaFrom(project, null);
          meta.rev = 1; meta.savedAt = new Date().toISOString();
          t.objectStore('docs').put({ id: meta.id, json: JSON.stringify(project), rev: 1 });
          t.objectStore('projects').put(meta);
          kv.put(rec, 'legacy:project');          // the original record is kept, renamed
          kv.delete('project');
        } catch (e) {
          kv.put({ at: new Date().toISOString(), error: String(e && e.message || e) }, 'legacy:error');   // leave the old record where it is
        }
      };
      kv.openCursor(IDBKeyRange.bound('file:', 'file:￿')).onsuccess = function (ev) {
        var c = ev.target.result;
        if (!c) return;
        var bytes = compact(c.value);
        t.objectStore('files').put({ sha: String(c.key).slice(5), bytes: bytes, size: bytes.length });
        c.delete();
        c.continue();
      };
    }
  };

  function emit(evt, d) { listeners.forEach(function (f) { f(evt, d); }); }

  function open(name, version) {
    close();
    dbName = name || DB_NAME;
    version = version || DB_VERSION;
    return new Promise(function (res, rej) {
      if (!window.indexedDB) { rej(RepoError('unavailable', 'This browser does not provide IndexedDB storage.')); return; }
      var r;
      try { r = indexedDB.open(dbName, version); } catch (e) { rej(RepoError('unavailable', classify(e).message)); return; }
      r.onupgradeneeded = function (ev) {
        var d = r.result, t = r.transaction;
        for (var v = ev.oldVersion + 1; v <= version; v++) if (MIGRATIONS[v]) MIGRATIONS[v](d, t);
        t.objectStore('kv').put({ schema: version, from: ev.oldVersion, at: new Date().toISOString(), app: PHA.store.APP_VERSION }, 'dbInfo');
      };
      r.onblocked = function () { emit('blocked'); };
      r.onerror = function () { var c = classify(r.error); rej(RepoError(c.code, c.message)); };
      r.onsuccess = function () {
        db = r.result;
        db.onversionchange = function () { close(); emit('stale'); };    // another tab is upgrading the database
        res();
      };
    });
  }
  function close() { if (db) { try { db.close(); } catch (e) { /* ignore */ } db = null; } }
  function isOpen() { return !!db; }

  /* Run fn inside one transaction. Resolves only when the transaction has COMPLETED; rejects if it aborts. */
  function run(stores, mode, fn) {
    return new Promise(function (res, rej) {
      if (!db) { rej(RepoError('unavailable', 'The project repository is not open.')); return; }
      var t, out, failed = null;
      // 'strict' asks the browser to flush a write to disk before reporting it complete.
      try { t = mode === 'readwrite' ? db.transaction(stores, mode, { durability: 'strict' }) : db.transaction(stores, mode); }
      catch (e) { try { t = db.transaction(stores, mode); } catch (e2) { rej(e2); return; } }
      t.oncomplete = function () { res(out); };
      t.onabort = function () { rej(failed || t.error || RepoError('failed', 'The storage transaction was aborted.')); };
      t.onerror = function (ev) { if (!failed) failed = (ev.target && ev.target.error) || t.error; };
      Promise.resolve().then(function () { return fn(t); }).then(function (v) { out = v; }, function (e) {
        failed = e;
        try { t.abort(); } catch (x) { rej(e); }
      });
    });
  }

  /* ---------- reading ---------- */

  function list() { return run(['projects'], 'readonly', function (t) { return req(t.objectStore('projects').getAll()); }); }
  function getMeta(id) { return run(['projects'], 'readonly', function (t) { return req(t.objectStore('projects').get(id)); }); }

  async function load(id, opts) {
    var got = await run(['projects', 'docs'], 'readonly', async function (t) {
      return { meta: await req(t.objectStore('projects').get(id)), doc: await req(t.objectStore('docs').get(id)) };
    });
    if (!got.meta || !got.doc) throw RepoError('missing', 'This project is no longer in the repository.');
    var project = PHA.store.migrate(JSON.parse(got.doc.json));
    var files = new Map(), missing = [];
    if (!(opts && opts.noFiles)) {
      var shas = metaFrom(project, null).fileShas;
      await run(['files'], 'readonly', async function (t) {
        for (var i = 0; i < shas.length; i++) {
          var f = await req(t.objectStore('files').get(shas[i]));
          if (f && f.bytes) files.set(shas[i], compact(f.bytes)); else missing.push(shas[i]);
        }
      });
    }
    return { meta: got.meta, project: project, files: files, missing: missing };
  }

  /* ---------- writing ---------- */

  /* opts: project (object), files (Map sha -> bytes, optional), mode 'create' | 'update',
           baseRev (the revision the caller last saw), force, importedFrom, clearBackup.
     The revision check is what stops one window, or one project, from silently overwriting another. */
  function save(opts) {
    var project = opts.project, id = project && project.project && project.project.id;
    if (!id) return Promise.reject(RepoError('invalid', 'The project has no ID.'));
    var draft, json;
    try { draft = metaFrom(project, null); json = opts.json || JSON.stringify(project); }     // snapshot now, before anything is awaited
    catch (e) { return Promise.reject(e); }
    return run(['projects', 'docs', 'files'], 'readwrite', async function (t) {
      var metas = t.objectStore('projects'), files = t.objectStore('files');
      var prev = await req(metas.get(id));
      if (opts.mode === 'create') {
        if (prev) throw RepoError('exists', 'A project with this ID is already in the repository.', { current: prev });
      } else {
        if (!prev) throw RepoError('missing', 'This project is no longer in the repository. It may have been deleted in another window.');
        if (!opts.force && prev.rev !== opts.baseRev) {
          throw RepoError('conflict', 'This project was changed in another window after you opened it. Your version was not saved over it.', { current: prev });
        }
      }
      var meta = draft;
      meta.rev = (prev ? prev.rev : 0) + 1;
      meta.savedAt = new Date().toISOString();
      meta.lastExport = (prev && !opts.clearBackup) ? (prev.lastExport || null) : null;
      meta.importedFrom = (prev && !opts.clearBackup) ? (prev.importedFrom || null) : null;
      if (opts.importedFrom) meta.importedFrom = Object.assign({}, opts.importedFrom, { rev: meta.rev });
      for (var i = 0; i < meta.fileShas.length; i++) {
        var sha = meta.fileShas[i];
        if ((await req(files.getKey(sha))) !== undefined) continue;          // already stored (shared by fingerprint)
        var b = opts.files && opts.files.get(sha);
        if (b) { var c = compact(b); files.put({ sha: sha, bytes: c, size: c.length }); }
        else meta.missingFiles.push(sha);
      }
      t.objectStore('docs').put({ id: id, json: json, rev: meta.rev });
      metas.put(meta);
      if (api._fault) api._fault(t, meta);                                  // test hook: lets the tests make a save fail
      return meta;
    });
  }

  function create(project, files, extra) { return save(Object.assign({ project: project, files: files, mode: 'create' }, extra || {})); }

  /* Change a stored project without opening it in the editor (status, archive, restore). */
  async function update(id, fn) {
    var got = await load(id, { noFiles: true });
    fn(got.project);
    got.project.project.modifiedAt = new Date().toISOString();
    return save({ project: got.project, baseRev: got.meta.rev, mode: 'update' });
  }

  function setStatus(id, status) {
    return update(id, function (p) {
      var pr = p.project;
      if (status === 'archived') { if (pr.status !== 'archived') pr.statusBeforeArchive = pr.status; pr.status = 'archived'; pr.archivedAt = new Date().toISOString(); }
      else { pr.status = status; delete pr.archivedAt; delete pr.statusBeforeArchive; }
    });
  }
  function archive(id) { return setStatus(id, 'archived'); }
  function restore(id) {
    return update(id, function (p) {
      var pr = p.project;
      pr.status = pr.statusBeforeArchive || 'draft';
      delete pr.archivedAt; delete pr.statusBeforeArchive;
    });
  }

  /* A new study that starts as a copy of another. New project ID, a note of where it came from, drawings shared. */
  async function duplicate(id) {
    var got = await load(id, { noFiles: true });
    var p = got.project, now = new Date().toISOString();
    p.project.source = { type: 'duplicate', projectId: got.meta.id, projectName: got.meta.name, sourceRev: got.meta.rev, at: now };
    p.project.id = U.uid('prj');
    p.project.name = 'Copy of ' + (got.meta.name || 'untitled project');
    p.project.createdAt = now; p.project.modifiedAt = now;
    p.project.status = 'draft';
    delete p.project.archivedAt; delete p.project.statusBeforeArchive;
    return save({ project: p, mode: 'create', clearBackup: true });
  }

  /* Add a parsed .phaz to the repository. how: 'new' (ID not present), 'copy' (keep both), 'replace' (explicit overwrite). */
  async function importParsed(parsed, info, how) {
    var p = parsed.project, now = new Date().toISOString();
    if (!p.project.id) p.project.id = U.uid('prj');
    var importedFrom = { fileName: (info && info.fileName) || null, fileModified: (info && info.fileModified) || null, at: now, fromFormat: parsed.fromVersion };
    if (how === 'copy') {
      p.project.source = { type: 'import-copy', projectId: p.project.id, fileName: importedFrom.fileName, at: now };
      p.project.id = U.uid('prj');
      return save({ project: p, files: parsed.files, mode: 'create', importedFrom: importedFrom, clearBackup: true });
    }
    if (how === 'replace') return save({ project: p, files: parsed.files, mode: 'update', force: true, importedFrom: importedFrom, clearBackup: true });
    return save({ project: p, files: parsed.files, mode: 'create', importedFrom: importedFrom, clearBackup: true });
  }

  /* Record an export. Meta-only: it does not change the project revision. */
  function recordExport(id, info) {
    return run(['projects'], 'readwrite', async function (t) {
      var s = t.objectStore('projects'), m = await req(s.get(id));
      if (!m) return null;
      m.lastExport = { at: new Date().toISOString(), rev: info.rev, confirmed: !!info.confirmed, method: info.method, fileName: info.fileName || null };
      s.put(m);
      return m;
    });
  }

  /* Permanently delete a project. Its PDFs go too, unless another project still uses the same drawing. */
  function remove(id) {
    return run(['projects', 'docs', 'files'], 'readwrite', async function (t) {
      var metas = t.objectStore('projects'), m = await req(metas.get(id));
      metas.delete(id);
      t.objectStore('docs').delete(id);
      var rest = await req(metas.getAll()), used = {};
      rest.forEach(function (x) { if (x.id !== id) (x.fileShas || []).forEach(function (s) { used[s] = true; }); });
      ((m && m.fileShas) || []).forEach(function (s) { if (!used[s]) t.objectStore('files').delete(s); });
      return !!m;
    });
  }

  /* Remove PDFs that no project refers to any more (left behind when a drawing is removed from a project). */
  function cleanup() {
    return run(['projects', 'files'], 'readwrite', async function (t) {
      var metas = await req(t.objectStore('projects').getAll()), used = {}, removed = 0;
      metas.forEach(function (x) { (x.fileShas || []).forEach(function (s) { used[s] = true; }); });
      var keys = await req(t.objectStore('files').getAllKeys());
      keys.forEach(function (k) { if (!used[k]) { t.objectStore('files').delete(k); removed++; } });
      return removed;
    });
  }

  function fileKeys() { return run(['files'], 'readonly', function (t) { return req(t.objectStore('files').getAllKeys()); }); }
  function kvGet(k) { return run(['kv'], 'readonly', function (t) { return req(t.objectStore('kv').get(k)); }); }
  function kvSet(k, v) { return run(['kv'], 'readwrite', function (t) { t.objectStore('kv').put(v, k); }); }
  function kvDel(k) { return run(['kv'], 'readwrite', function (t) { t.objectStore('kv').delete(k); }); }

  /* What the browser says about space and durability. Either can be missing or approximate, especially on file://. */
  async function storageInfo() {
    var out = { usage: null, quota: null, persisted: null };
    try { if (navigator.storage && navigator.storage.estimate) { var e = await navigator.storage.estimate(); out.usage = e.usage; out.quota = e.quota; } } catch (e) { /* unknown */ }
    try { if (navigator.storage && navigator.storage.persisted) out.persisted = await navigator.storage.persisted(); } catch (e) { /* unknown */ }
    return out;
  }
  async function requestPersistence() {
    try { if (navigator.storage && navigator.storage.persist) return await navigator.storage.persist(); } catch (e) { /* ignore */ }
    return false;
  }

  function destroy(name) {
    return new Promise(function (res) {
      var r = indexedDB.deleteDatabase(name);
      r.onsuccess = r.onerror = r.onblocked = function () { res(); };
    });
  }

  api = {
    DB_NAME: DB_NAME, DB_VERSION: DB_VERSION, MIGRATIONS: MIGRATIONS,
    open: open, close: close, isOpen: isOpen, on: function (f) { listeners.push(f); },
    list: list, getMeta: getMeta, load: load, save: save, create: create, update: update,
    setStatus: setStatus, archive: archive, restore: restore, duplicate: duplicate, importParsed: importParsed,
    recordExport: recordExport, remove: remove, cleanup: cleanup, fileKeys: fileKeys,
    kvGet: kvGet, kvSet: kvSet, kvDel: kvDel, storageInfo: storageInfo, requestPersistence: requestPersistence,
    metaFrom: metaFrom, backupStatus: backupStatus, classify: classify, destroy: destroy, _fault: null
  };
  PHA.repo = api;
})();
