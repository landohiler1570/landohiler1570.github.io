/* humanfactors.js: human factors prompts for a node. Each prompt is Not evaluated, Applicable or Not applicable,
   with notes and an optional link to a scenario when it applies. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, C = PHA.calc, M = PHA.modules;
  var KEY = 'humanFactors';

  function item(n, id) {
    n.humanFactors.items[id] = n.humanFactors.items[id] || { status: 'not-evaluated', notes: '', scenarioId: null };
    return n.humanFactors.items[id];
  }
  function peek(n, id) { return n.humanFactors.items[id] || { status: 'not-evaluated', notes: '', scenarioId: null }; }

  function row(p, n, prompt, custom) {
    var ui = PHA.ui, it = peek(n, prompt.id);
    var box = el('div', { 'class': 'hf-item ' + it.status, 'data-hf': prompt.id });
    var head = el('div', { 'class': 'hf-head' });
    if (custom) {
      head.appendChild(ui.text(prompt.text, function (v) { prompt.text = v; }, { placeholder: 'Describe the human factors item', 'data-focus': 'hf:' + prompt.id }));
    } else {
      head.appendChild(el('span', { 'class': 'hf-text' }, prompt.text));
    }
    head.appendChild(M.triState(it.status, function (v) {
      store.change(function (proj) { item(n, prompt.id).status = v; M.markApplicable(proj.nodes[n.id], KEY); });
    }));
    if (custom) {
      head.appendChild(el('button', { 'class': 'x', title: 'Remove this item', onclick: function () {
        store.change(function () {
          n.humanFactors.custom = n.humanFactors.custom.filter(function (c) { return c.id !== prompt.id; });
          delete n.humanFactors.items[prompt.id];
        });
      } }, '×'));
    }
    box.appendChild(head);
    if (it.status === 'applicable') {
      var scenarios = store.nodeScenarios(p, n.id).map(function (sc) { return [sc.id, sc.deviation || 'Unnamed deviation']; });
      box.appendChild(el('div', { 'class': 'hf-body' },
        ui.area(it.notes, function (v) { item(n, prompt.id).notes = v; }, { placeholder: 'What the team observed and why it matters here', rows: 1 }),
        ui.select(it.scenarioId || '', scenarios, function (e) {
          var v = e.target.value || null; store.change(function () { item(n, prompt.id).scenarioId = v; }, 'field');
        }, 'Not linked to a scenario')));
    } else if (it.status === 'not-applicable' && it.notes) {
      box.appendChild(el('div', { 'class': 'muted small hf-body' }, 'Notes entered earlier are kept.'));
    }
    return box;
  }

  function render(p, n) {
    var sec = el('div');
    sec.appendChild(el('div', { 'class': 'sec-head' }, el('h3', null, 'Human factors prompts'),
      el('button', { onclick: function () {
        var id = U.uid('hfc');
        store.change(function (proj) { n.humanFactors.custom.push({ id: id, text: '' }); M.markApplicable(proj.nodes[n.id], KEY); });
        PHA.panel.focus('hf:' + id);
      } }, '+ Custom item')));
    p.project.humanFactorPrompts.forEach(function (pr) { sec.appendChild(row(p, n, pr, false)); });
    n.humanFactors.custom.forEach(function (pr) { sec.appendChild(row(p, n, pr, true)); });
    return sec;
  }

  function count(p, n) {
    var items = n.humanFactors.items;
    return Object.keys(items).filter(function (k) { return items[k].status === 'applicable'; }).length;
  }

  M.register(KEY, { count: count, render: render });
})();
