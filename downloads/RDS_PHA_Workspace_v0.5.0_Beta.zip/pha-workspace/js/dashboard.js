/* dashboard.js: the project repository screen shown when the app starts.
   It lists catalog rows only. A project's record and drawings are read when it is opened, exported or duplicated. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, repo = PHA.repo, P = PHA.persist, AS = PHA.autosave;
  function $(id) { return document.getElementById(id); }

  var metas = [], repoError = null, notices = [];
  var filter = { q: '', status: 'active', method: '', facility: '', sort: 'modified' };
  var backupDir = null;      // optional folder handle for one-click backups (Chromium only)
  var STUDY_TYPES = ['Initial PHA', 'Revalidation', 'Management of change review', 'Pre-startup review', 'Incident follow-up'];
  var METHODS = ['HAZOP', 'What-If', 'What-If / Checklist', 'FMEA', 'LOPA', 'Checklist'];
  var STATUS_LABEL = {};
  store.PROJECT_STATUSES.forEach(function (s) { STATUS_LABEL[s[0]] = s[1]; });

  function fmtDate(t) { return t ? new Date(t).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : 'unknown'; }
  function fmtDateTime(t) { return t ? new Date(t).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'unknown'; }
  function fmtBytes(n) {
    if (n == null) return 'unknown';
    if (n < 1024 * 1024) return Math.max(1, Math.round(n / 1024)) + ' KB';
    if (n < 1024 * 1024 * 1024) return (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + ' MB';
    return (n / 1073741824).toFixed(1) + ' GB';
  }
  function plural(n, w) { return n + ' ' + w + (n === 1 ? '' : 's'); }

  /* ---------- small dialog helper ---------- */

  /* Shows a modal with the given body and buttons; resolves with the key of the button pressed (or null on Esc). */
  function ask(title, body, buttons) {
    return new Promise(function (res) {
      var dlg = $('askDlg'), done = false;
      function finish(k) { if (done) return; done = true; dlg.close ? dlg.close() : dlg.removeAttribute('open'); res(k); }
      dlg.textContent = '';
      dlg.appendChild(el('h2', null, title));
      dlg.appendChild(typeof body === 'string' ? el('p', null, body) : body);
      var row = el('div', { 'class': 'row end' });
      buttons.forEach(function (b) {
        var btn = el('button', { 'class': b.cls || '', 'data-key': b.key, disabled: b.disabled ? true : null, onclick: function () { finish(b.key); } }, b.label);
        if (b.ref) b.ref(btn);
        row.appendChild(btn);
      });
      dlg.appendChild(row);
      dlg.oncancel = function () { finish(null); };
      if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
    });
  }
  function tell(title, text) { return ask(title, text, [{ key: 'ok', label: 'OK', cls: 'primary' }]); }

  function notice(kind, content, actions, key) {
    if (key) notices = notices.filter(function (n) { return n.key !== key; });
    notices.push({ kind: kind, content: content, actions: actions || [], key: key || U.uid('n') });
    renderNotices();
  }
  function dropNotice(key) { notices = notices.filter(function (n) { return n.key !== key; }); renderNotices(); }
  function renderNotices() {
    var box = $('dashNotices');
    box.textContent = '';
    notices.forEach(function (n) {
      var row = el('div', { 'class': 'dnotice ' + n.kind, 'data-key': n.key }, el('span', null, n.content));
      n.actions.forEach(function (a) { row.appendChild(el('button', { 'class': a.cls || '', onclick: a.fn }, a.label)); });
      row.appendChild(el('button', { 'class': 'x', title: 'Dismiss', onclick: function () { dropNotice(n.key); } }, '×'));
      box.appendChild(row);
    });
  }

  /* ---------- project form (new project, and details in the editor) ---------- */

  function projectForm(values, withStatus) {
    var f = {};
    function input(key, label, attrs) {
      f[key] = el('input', Object.assign({ type: 'text', value: values[key] || '', 'data-field': key }, attrs || {}));
      return el('label', { 'class': 'field' }, el('span', { 'class': 'flabel' }, label), f[key]);
    }
    var body = el('div', { 'class': 'pform' },
      el('datalist', { id: 'dlStudy' }, STUDY_TYPES.map(function (t) { return el('option', { value: t }); })),
      el('datalist', { id: 'dlMethod' }, METHODS.map(function (t) { return el('option', { value: t }); })),
      input('name', 'Project name', { placeholder: 'e.g. Unit 200 reactor section PHA' }),
      input('facility', 'Facility', { placeholder: 'Site or unit' }),
      el('div', { 'class': 'row two' },
        input('studyType', 'Study type', { list: 'dlStudy', placeholder: 'Initial PHA, Revalidation, ...' }),
        input('method', 'Methodology', { list: 'dlMethod', placeholder: 'HAZOP' })));
    if (withStatus) {
      f.status = el('select', { 'data-field': 'status', value: values.status || 'draft' }, store.PROJECT_STATUSES.map(function (s) { return el('option', { value: s[0] }, s[1]); }));
      body.appendChild(el('label', { 'class': 'field' }, el('span', { 'class': 'flabel' }, 'Status'), f.status));
    }
    return { body: body, read: function () {
      var out = {};
      Object.keys(f).forEach(function (k) { out[k] = f[k].value.trim(); });
      return out;
    }, fields: f };
  }

  async function newProject() {
    var form = projectForm({ method: 'HAZOP' }, false);
    var k = await ask('New project', form.body, [{ key: null, label: 'Cancel' }, { key: 'create', label: 'Create and open', cls: 'primary' }]);
    if (k !== 'create') return;
    var v = form.read();
    var project = store.makeProject({ name: v.name || 'Untitled study', facility: v.facility, studyType: v.studyType, method: v.method || 'HAZOP', status: 'draft' });
    if (!repo.isOpen()) { enterEditor(project, new Map(), null); return; }
    try {
      var meta = await repo.create(project, new Map());
      enterEditor(project, new Map(), meta);
    } catch (e) { tell('Could not create the project', repo.classify(e).message); }
  }

  /* Edit name, facility, study type, methodology and status of the project open in the editor. */
  async function editDetails() {
    var pr = store.S.project.project;
    var form = projectForm(pr, true);
    var k = await ask('Project details', form.body, [{ key: null, label: 'Cancel' }, { key: 'ok', label: 'Apply', cls: 'primary' }]);
    if (k !== 'ok') return;
    var v = form.read();
    store.change(function (p) {
      var q = p.project;
      q.name = v.name; q.facility = v.facility; q.studyType = v.studyType; q.method = v.method || 'HAZOP';
      if (v.status !== q.status) {
        if (v.status === 'archived') { q.statusBeforeArchive = q.status; q.archivedAt = new Date().toISOString(); }
        else { delete q.statusBeforeArchive; delete q.archivedAt; }
        q.status = v.status;
      }
    });
    $('projName').value = v.name;
  }

  /* ---------- open / leave the editor ---------- */

  function setView(v) { document.body.dataset.view = v; }

  function enterEditor(project, files, meta) {
    setView('editor');                       // the editor must be visible before the drawing is laid out
    PHA.viewer.resetDocs();
    P.resetExportTarget();
    store.load(project, files, {});
    if (meta) AS.begin(meta); else AS.beginVolatile();
    if (PHA.main) PHA.main.refreshPills();
  }

  async function openProject(id) {
    try {
      var got = await repo.load(id);
      enterEditor(got.project, got.files, got.meta);
      if (got.missing.length) {
        tell('Drawing files missing', plural(got.missing.length, 'drawing file') + ' could not be found in the repository. The analysis is intact. Use Import P&ID with the same PDF to re-attach a drawing.');
      }
    } catch (e) { tell('Could not open the project', repo.classify(e).message); refresh(); }
  }

  /* Back to the repository. Leaves only when the work is safely stored, or the user says to leave anyway. */
  async function leaveEditor() {
    var sess = AS.session();
    if (sess && sess.volatile) {
      if (!confirm('The repository is unavailable, so this project exists only in this window. Leave without exporting a .phaz file?')) return false;
    } else if (sess) {
      var ok = await AS.flush();
      if (!ok) {
        var st = AS.state();
        if (!confirm('The latest changes could not be saved locally.\n\n' + ((st.error && st.error.message) || '') + '\n\nLeave anyway and lose them? Choose Cancel to stay and export a .phaz file.')) return false;
      }
    }
    AS.end();
    PHA.viewer.resetDocs();
    store.newProject();
    await show();
    return true;
  }

  /* ---------- export from the dashboard ---------- */

  function backupFileName(m) { return U.safeName(m.name || 'project') + '-' + m.id.slice(-6) + '.phaz'; }

  async function exportProject(id, quiet) {
    try {
      var got = await repo.load(id);
      if (got.missing.length && !quiet && !confirm(plural(got.missing.length, 'drawing file') + ' are missing from the repository and will not be in the export. Export anyway?')) return null;
      var bytes = P.zipOf(got.project, got.files), res;
      if (backupDir && await dirReady(false)) {
        var fh = await backupDir.getFileHandle(backupFileName(got.meta), { create: true });
        await P.writeHandle(fh, bytes);
        res = { confirmed: true, method: 'folder', fileName: backupDir.name + '/' + fh.name };
      } else {
        res = await P.writeOut(bytes, P.fileNameFor(got.meta.name || 'project'), null);
      }
      if (!res) return null;
      await repo.recordExport(id, { rev: got.meta.rev, confirmed: res.confirmed, method: res.method, fileName: res.fileName });
      if (!quiet) {
        notice(res.confirmed ? 'ok' : 'warn', res.confirmed
          ? '"' + (got.meta.name || 'Project') + '" was written to ' + res.fileName + '.'
          : 'A download of "' + (got.meta.name || 'Project') + '" was started as ' + res.fileName + '. The browser does not report whether it finished: check your Downloads folder.', [], 'export');
        refresh();
      }
      return res;
    } catch (e) {
      if (!quiet) tell('Export failed', repo.classify(e).message);
      return null;
    }
  }

  /* ---------- optional backup folder (File System Access API) ---------- */

  var canPickDir = typeof window.showDirectoryPicker === 'function';
  async function dirReady(askUser) {
    if (!backupDir) return false;
    try {
      var q = backupDir.queryPermission ? await backupDir.queryPermission({ mode: 'readwrite' }) : 'granted';
      if (q === 'granted') return true;
      if (askUser && backupDir.requestPermission) return (await backupDir.requestPermission({ mode: 'readwrite' })) === 'granted';
    } catch (e) { /* treat as not ready */ }
    return false;
  }
  async function chooseBackupDir() {
    if (!canPickDir) { tell('Backup folder', 'This browser cannot write to a folder directly. Use Export on each project; the file goes to your Downloads folder.'); return; }
    try {
      backupDir = await window.showDirectoryPicker({ mode: 'readwrite', id: 'pha-backups' });
      try { await repo.kvSet('backupDir', backupDir); } catch (e) { /* remembered for this session only */ }
      renderBar();
    } catch (e) { if (!e || e.name !== 'AbortError') tell('Backup folder', 'The folder could not be opened: ' + (e && e.message)); }
  }
  async function backupAll() {
    if (!backupDir) { await chooseBackupDir(); if (!backupDir) return; }
    if (!(await dirReady(true))) { tell('Backup folder', 'Permission to write to "' + backupDir.name + '" was not granted. Nothing was backed up.'); return; }
    var todo = metas.filter(function (m) { return repo.backupStatus(m).needs; }), done = 0, failed = [];
    for (var i = 0; i < todo.length; i++) {
      var r = await exportProject(todo[i].id, true);
      if (r && r.confirmed) done++; else failed.push(todo[i].name || todo[i].id);
    }
    notice(failed.length ? 'warn' : 'ok', plural(done, 'project') + ' written to the folder "' + backupDir.name + '".' +
      (failed.length ? ' Not written: ' + failed.join(', ') + '.' : (todo.length ? '' : ' Every project was already up to date.')), [], 'backup');
    refresh();
  }

  /* ---------- import ---------- */

  function summaryOf(m) {
    return el('div', { 'class': 'cmp' }, el('b', null, m.name || 'Untitled'), el('div', { 'class': 'muted' },
      plural(m.nodeCount, 'node') + ', ' + plural(m.scenarioCount, 'scenario') + ', ' + plural(m.drawingCount, 'drawing') + '. Last modified ' + fmtDateTime(m.modifiedAt)));
  }

  async function importFiles(fileList) {
    var files = Array.prototype.slice.call(fileList), added = 0, problems = [], notes = [];
    for (var i = 0; i < files.length; i++) {
      var f = files[i], parsed;
      try {
        parsed = await P.parseProject(new Uint8Array(await f.arrayBuffer()));     // fully validated before anything is written
      } catch (e) { problems.push(f.name + ': ' + (e && e.message ? e.message : e)); continue; }
      try {
        if (!repo.isOpen()) { enterEditor(parsed.project, parsed.files, null); return; }
        var info = { fileName: f.name, fileModified: f.lastModified ? new Date(f.lastModified).toISOString() : null };
        var incoming = repo.metaFrom(parsed.project, null);
        var existing = incoming.id ? await repo.getMeta(incoming.id) : null, how = 'new';
        if (existing) {
          var body = el('div', null,
            el('p', null, 'The file "' + f.name + '" has the same project ID as a project already in the repository.'),
            el('div', { 'class': 'cmp-row' }, el('div', null, el('span', { 'class': 'flabel' }, 'In the repository'), summaryOf(existing)),
              el('div', null, el('span', { 'class': 'flabel' }, 'In the file'), summaryOf(incoming))),
            el('p', { 'class': 'muted' }, 'Keep both adds the file as a separate project. Replace overwrites the repository copy with the file and cannot be undone.'));
          how = await ask('This project is already here', body, [
            { key: null, label: 'Skip this file' }, { key: 'replace', label: 'Replace the repository copy', cls: 'danger' }, { key: 'copy', label: 'Keep both', cls: 'primary' }]);
          if (!how) continue;
          if (how === 'replace' && !confirm('Replace "' + (existing.name || 'Untitled') + '" in the repository with the contents of ' + f.name + '?')) continue;
        }
        await repo.importParsed(parsed, info, how);
        added++;
        if (parsed.migrated) notes.push(f.name + ' was upgraded from file format ' + parsed.fromVersion + '; the file itself was not changed.');
        parsed.warnings.forEach(function (w) { notes.push(f.name + ': ' + w); });
      } catch (e) { problems.push(f.name + ': ' + repo.classify(e).message); }
    }
    if (added) notice('ok', plural(added, 'project') + ' imported.' + (notes.length ? ' ' + notes.join(' ') : ''), [], 'import');
    if (problems.length) notice('bad', 'Not imported. ' + problems.join(' | '), [], 'import-bad');
    refresh();
  }

  /* ---------- row actions ---------- */

  async function act(fn, failTitle) {
    try { await fn(); } catch (e) { await tell(failTitle, repo.classify(e).message); }
    refresh();
  }

  async function deleteProject(m) {
    var bs = repo.backupStatus(m), okBtn;
    var check = el('input', { type: 'checkbox', id: 'delSure', onchange: function (e) { okBtn.disabled = !e.target.checked; } });
    var body = el('div', null,
      el('p', null, 'This permanently removes the project from this browser\'s repository: ', el('b', null, m.name || 'Untitled'), '.'),
      el('p', { 'class': 'muted' }, plural(m.nodeCount, 'node') + ', ' + plural(m.scenarioCount, 'scenario') + ', ' + plural(m.drawingCount, 'drawing') + '.'),
      el('div', { 'class': 'dnotice ' + (bs.needs ? 'bad' : 'warn') }, el('span', null, 'Backup: ' + bs.text + '. ' +
        (bs.needs ? 'If you delete it now, this work cannot be recovered.' : 'Make sure you still have that file.'))),
      el('label', { 'class': 'modrow' }, check, el('div', null, 'I understand this cannot be undone.')));
    var k = await ask('Delete project permanently?', body, [
      { key: null, label: 'Cancel' }, { key: 'archive', label: 'Archive instead' },
      { key: 'delete', label: 'Delete permanently', cls: 'danger', disabled: true, ref: function (b) { okBtn = b; } }]);
    if (k === 'archive') return act(function () { return repo.archive(m.id); }, 'Could not archive');
    if (k === 'delete') return act(function () { return repo.remove(m.id); }, 'Could not delete');
  }

  var openMenu = null;
  function closeMenu() { if (openMenu) { openMenu.remove(); openMenu = null; } }
  function menuFor(m, anchor) {
    closeMenu();
    var items = [['Duplicate', function () { act(function () { return repo.duplicate(m.id); }, 'Could not duplicate'); }]];
    if (m.status !== 'archived') {
      store.PROJECT_STATUSES.forEach(function (s) {
        if (s[0] !== 'archived' && s[0] !== m.status) items.push(['Mark as ' + s[1], function () { act(function () { return repo.setStatus(m.id, s[0]); }, 'Could not change status'); }]);
      });
      items.push(['Archive', function () { act(function () { return repo.archive(m.id); }, 'Could not archive'); }]);
    } else {
      items.push(['Restore to worklist', function () { act(function () { return repo.restore(m.id); }, 'Could not restore'); }]);
    }
    items.push(['Delete...', function () { deleteProject(m); }, 'danger']);
    openMenu = el('div', { 'class': 'pmenu' }, items.map(function (it) {
      return el('button', { 'class': it[2] || '', onclick: function () { closeMenu(); it[1](); } }, it[0]);
    }));
    anchor.parentNode.appendChild(openMenu);
  }

  /* ---------- rendering ---------- */

  function visible() {
    var q = filter.q.trim().toLowerCase();
    var out = metas.filter(function (m) {
      if (filter.status === 'active') { if (m.status === 'archived') return false; }
      else if (filter.status === 'needs-backup') { if (!repo.backupStatus(m).needs) return false; }
      else if (filter.status !== 'all' && m.status !== filter.status) return false;
      if (filter.method && m.methodology !== filter.method) return false;
      if (filter.facility && m.facility !== filter.facility) return false;
      if (q && [m.name, m.facility, m.methodology, m.studyType].join(' ').toLowerCase().indexOf(q) < 0) return false;
      return true;
    });
    out.sort(function (a, b) {
      if (filter.sort === 'name') return (a.name || '').localeCompare(b.name || '');
      if (filter.sort === 'created') return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
      return String(b.modifiedAt || '').localeCompare(String(a.modifiedAt || ''));
    });
    return out;
  }

  function card(m) {
    var bs = repo.backupStatus(m);
    var sub = [m.facility, m.studyType, m.methodology].filter(Boolean).join('  ·  ') || 'No facility or study type entered';
    var src = m.source && m.source.type === 'duplicate' ? 'Duplicated from "' + (m.source.projectName || m.source.projectId) + '" on ' + fmtDate(m.source.at)
      : m.source && m.source.type === 'import-copy' ? 'Imported as a second copy from ' + (m.source.fileName || 'a file')
      : m.source && m.source.type === 'legacy-recovery' ? 'Recovered from an earlier version of the app'
      : m.source && m.source.type === 'conflict-copy' ? 'Saved as a separate copy after an edit conflict' : null;
    return el('div', { 'class': 'pcard st-' + m.status, 'data-id': m.id },
      el('div', { 'class': 'pc-main' },
        el('div', { 'class': 'pc-title' }, el('span', { 'class': 'badge st-' + m.status }, STATUS_LABEL[m.status] || m.status), el('b', null, m.name || 'Untitled study')),
        el('div', { 'class': 'pc-sub' }, sub),
        el('div', { 'class': 'pc-backup bk-' + bs.level }, el('i'), bs.text),
        src ? el('div', { 'class': 'muted small' }, src) : null,
        (m.missingFiles && m.missingFiles.length) ? el('div', { 'class': 'pc-backup bk-none' }, el('i'), plural(m.missingFiles.length, 'drawing file') + ' missing: re-import the PDF inside the project') : null),
      el('div', { 'class': 'pc-stats' },
        el('div', null, el('b', null, String(m.nodeCount)), m.nodeCount === 1 ? ' node' : ' nodes'), el('div', null, el('b', null, String(m.scenarioCount)), m.scenarioCount === 1 ? ' scenario' : ' scenarios'),
        el('div', null, el('b', null, String(m.drawingCount)), m.drawingCount === 1 ? ' drawing' : ' drawings')),
      el('div', { 'class': 'pc-dates' },
        el('div', null, el('span', { 'class': 'muted' }, 'Modified '), fmtDateTime(m.modifiedAt)),
        el('div', null, el('span', { 'class': 'muted' }, 'Created '), fmtDate(m.createdAt))),
      el('div', { 'class': 'pc-actions' },
        el('button', { 'class': 'primary', 'data-act': 'open', onclick: function () { openProject(m.id); } }, 'Open'),
        el('button', { 'data-act': 'export', title: 'Save a complete .phaz file to this computer', onclick: function () { exportProject(m.id); } }, 'Export'),
        el('button', { 'data-act': 'more', title: 'Duplicate, status, archive, delete', onclick: function (e) { e.stopPropagation(); if (openMenu) closeMenu(); else menuFor(m, e.currentTarget); } }, 'More')));
  }

  function fillSelect(sel, first, values, current) {
    sel.textContent = '';
    sel.appendChild(el('option', { value: '' }, first));
    values.forEach(function (v) { sel.appendChild(el('option', { value: v }, v)); });
    sel.value = values.indexOf(current) >= 0 ? current : '';
  }

  function renderBar() {
    var b = $('dBackup');
    b.textContent = backupDir ? 'Back up to "' + backupDir.name + '"' : 'Backup folder';
    b.title = canPickDir ? (backupDir ? 'Write every project that needs a backup into this folder' : 'Choose a folder on this computer for one-click backups (optional)')
      : 'Not available in this browser. Use Export on each project.';
    $('dBackupChange').hidden = !backupDir;
  }

  function renderList() {
    closeMenu();
    var uniq = function (k) { var s = {}; metas.forEach(function (m) { if (m[k]) s[m[k]] = true; }); return Object.keys(s).sort(); };
    fillSelect($('dMethod'), 'All methodologies', uniq('methodology'), filter.method); filter.method = $('dMethod').value;
    fillSelect($('dFacility'), 'All facilities', uniq('facility'), filter.facility); filter.facility = $('dFacility').value;
    var list = visible(), box = $('dashList');
    box.textContent = '';
    var archived = metas.filter(function (m) { return m.status === 'archived'; }).length;
    $('dashCount').textContent = repoError ? '' : metas.length
      ? 'Showing ' + list.length + ' of ' + plural(metas.length, 'project') + (archived && filter.status === 'active' ? ' (' + archived + ' archived, hidden)' : '')
      : '';
    if (repoError) return;
    if (!metas.length) {
      box.appendChild(el('div', { 'class': 'dempty' }, el('h2', null, 'No projects yet'),
        el('p', null, 'Create a study, or import an existing .phaz project file. Projects are kept in this browser\'s storage on this computer and saved automatically as you work.'),
        el('div', { 'class': 'row', style: { justifyContent: 'center' } },
          el('button', { 'class': 'primary big', onclick: newProject }, '+ New project'),
          el('button', { 'class': 'big', onclick: function () { $('phazInput').click(); } }, 'Import .phaz'))));
      return;
    }
    if (!list.length) { box.appendChild(el('div', { 'class': 'dempty' }, el('p', null, 'No projects match the search and filters.'))); return; }
    var frag = document.createDocumentFragment();
    list.forEach(function (m) { frag.appendChild(card(m)); });
    box.appendChild(frag);
  }

  async function renderStorage() {
    var foot = $('dashStorage');
    foot.textContent = '';
    if (repoError) return;
    var si = await repo.storageInfo();
    var parts = ['Projects are stored by this browser, on this computer, in this browser profile.'];
    if (si.usage != null && si.quota) parts.push('Using ' + fmtBytes(si.usage) + ' of about ' + fmtBytes(si.quota) + ' the browser allows.');
    parts.push(si.persisted === true ? 'The browser has marked this storage as persistent.'
      : si.persisted === false ? 'The browser treats this storage as best-effort: it can be removed by "clear browsing data", by IT policy, or if the disk runs very low.'
      : 'The browser does not say whether this storage is protected from clearing.');
    parts.push('A .phaz export is the only permanent copy.');
    foot.appendChild(el('span', null, parts.join(' ')));
    if (si.quota && si.usage / si.quota > 0.8) notice('warn', 'Browser storage is ' + Math.round(si.usage / si.quota * 100) + '% full. Export and delete projects you no longer need here before saves start to fail.', [], 'quota');
  }

  async function refresh() {
    if (!repoError) {
      try { metas = await repo.list(); } catch (e) { repoError = repo.classify(e); }
    }
    if (repoError) {
      metas = [];
      notice('bad', 'The project repository could not be opened. ' + repoError.message + ' You can still work: create or import a project and export a .phaz file before closing, because nothing will be kept in this browser.', [], 'repo');
    } else {
      var need = metas.filter(function (m) { return m.status !== 'archived' && repo.backupStatus(m).needs; });
      if (need.length) {
        notice('warn', plural(need.length, 'active project') + (need.length === 1 ? ' has' : ' have') + ' work that exists only in this browser\'s storage or has changed since its last export. Export a .phaz file to keep a permanent copy.',
          [{ label: 'Show them', fn: function () { filter.status = 'needs-backup'; $('dStatus').value = 'needs-backup'; renderList(); } }], 'backup-reminder');
      } else dropNotice('backup-reminder');
    }
    renderBar(); renderList(); renderStorage();
  }

  /* Unsaved edits written to the close-time journal by a window that was closed mid-save. */
  async function checkJournal() {
    var j = AS.readJournal();
    if (!j || repoError) return;
    var meta = null;
    try { meta = await repo.getMeta(j.id); } catch (e) { return; }
    var verdict = AS.judgeJournal(j, meta);
    if (verdict === 'stale') { AS.clearJournal(); return; }
    notice('warn', 'The browser closed before the last edits to "' + (j.name || 'a project') + '" (' + fmtDateTime(j.at) + ') were saved. They were kept separately' +
      (verdict === 'orphan' ? ', but that project is no longer in the repository.' : '.'),
      [{ label: verdict === 'orphan' ? 'Restore as a project' : 'Apply the recovered edits', cls: 'primary', fn: async function () {
          try { await AS.applyJournal(j); dropNotice('journal'); notice('ok', 'Recovered edits were saved to "' + (j.name || 'the project') + '".', [], 'journal-ok'); }
          catch (e) { tell('Could not apply the recovered edits', repo.classify(e).message); }
          refresh();
        } },
       { label: 'Discard them', fn: function () { if (confirm('Discard the recovered edits for good?')) { AS.clearJournal(); dropNotice('journal'); } } }], 'journal');
  }

  async function show() {
    setView('dash');
    document.title = 'Projects - PHA Workspace';
    await refresh();
  }

  async function init(err) {
    repoError = err ? repo.classify(err) : null;
    $('dNew').onclick = newProject;
    $('dImport').onclick = function () { $('phazInput').click(); };
    $('phazInput').addEventListener('change', function (e) { if (e.target.files.length) importFiles(e.target.files); e.target.value = ''; });
    $('dSearch').addEventListener('input', function (e) { filter.q = e.target.value; renderList(); });
    $('dStatus').addEventListener('change', function (e) { filter.status = e.target.value; renderList(); });
    $('dMethod').addEventListener('change', function (e) { filter.method = e.target.value; renderList(); });
    $('dFacility').addEventListener('change', function (e) { filter.facility = e.target.value; renderList(); });
    $('dSort').addEventListener('change', function (e) { filter.sort = e.target.value; renderList(); });
    $('dBackup').onclick = backupAll;
    $('dBackupChange').onclick = chooseBackupDir;
    $('dDiag').onclick = function () { PHA.diag.open(); };
    $('dRegister').onclick = function () {
      var rows = visible(), sel = $('dStatus');
      PHA.report.openRegister(rows, sel.options[sel.selectedIndex].text + (filter.q ? ', search "' + filter.q + '"' : ''));
    };
    document.addEventListener('click', closeMenu);
    repo.on(function (evt) {
      if (evt === 'stale') notice('bad', 'The repository was upgraded by a newer copy of the app in another window. Close this window and reopen the app.', [], 'stale');
      if (evt === 'blocked') notice('warn', 'Another PHA Workspace window is open with an older version. Close it so the repository can be upgraded.', [], 'blocked');
    });
    if (!repoError) {
      try { backupDir = (await repo.kvGet('backupDir')) || null; } catch (e) { backupDir = null; }
      try { await repo.cleanup(); } catch (e) { /* housekeeping only */ }
      repo.requestPersistence();
      var info = null;
      try { info = await repo.kvGet('dbInfo'); } catch (e) { /* ignore */ }
      if (info && info.from === 1 && !(await repo.kvGet('legacyNoticeShown'))) {
        notice('ok', 'The repository was set up from an earlier version of the app. Any unsaved recovery copy it held is now listed as a project.', [], 'legacy');
        repo.kvSet('legacyNoticeShown', true).catch(function () {});
      }
    }
    await show();
    checkJournal();
  }

  PHA.dashboard = { visibleRows: function () { return visible(); }, init: init, show: show, refresh: refresh, openProject: openProject, leaveEditor: leaveEditor, newProject: newProject,
    importFiles: importFiles, exportProject: exportProject, editDetails: editDetails, ask: ask, tell: tell, visible: visible, filter: filter };
})();
