/* study.js: study information used by the report: purpose, scope, objectives, exclusions, revision,
   team members, session dates and assumptions. Blank means "not recorded", and the report says so. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store;
  var ASSUMPTION_STATUS = [['open', 'Open: to be confirmed'], ['confirmed', 'Confirmed'], ['closed', 'Withdrawn / not needed']];

  function dlg() { return document.getElementById('studyDlg'); }

  function rows(title, arr, cols, make, addLabel) {
    var box = el('div', { 'class': 'field' }, el('span', { 'class': 'flabel' }, title));
    var tbl = el('div', { 'class': 'srows' });
    if (!arr.length) tbl.appendChild(el('div', { 'class': 'muted' }, 'None recorded.'));
    arr.forEach(function (r, i) {
      tbl.appendChild(el('div', { 'class': 'srow' }, cols.map(function (c) { return c(r); }),
        el('button', { 'class': 'x', title: 'Remove', onclick: function () { store.change(function () { arr.splice(i, 1); }); } }, '×')));
    });
    box.appendChild(tbl);
    box.appendChild(el('button', { 'class': 'add', onclick: function () { store.change(function () { arr.push(make()); }); } }, addLabel));
    return box;
  }

  function render() {
    var d = dlg(), p = store.S.project, pr = p.project, T = PHA.ui.text, A = PHA.ui.area, F = PHA.ui.field;
    if (!d || !p) return;
    var top = d.scrollTop;
    d.textContent = '';
    d.appendChild(el('h2', null, 'Study information'));
    d.appendChild(el('p', { 'class': 'muted' }, 'Used on the report\'s cover and introduction. Anything left blank is printed as "Not recorded".'));
    d.appendChild(el('div', { 'class': 'row two' },
      F('Report / study revision', T(pr.revision, function (v) { pr.revision = v; }, { placeholder: 'e.g. Rev A, issued for review' })),
      F('Methodology (from Details)', el('input', { type: 'text', value: pr.method || '', disabled: true }))));
    d.appendChild(F('Purpose', A(pr.purpose, function (v) { pr.purpose = v; }, { placeholder: 'Why the study is being done, e.g. initial PHA required before start-up' })));
    d.appendChild(F('Scope', A(pr.scope, function (v) { pr.scope = v; }, { placeholder: 'Equipment, drawings and operating modes covered' })));
    d.appendChild(F('Objectives', A(pr.objectives, function (v) { pr.objectives = v; }, { placeholder: 'What the team is to identify and evaluate' })));
    d.appendChild(F('Exclusions', A(pr.exclusions, function (v) { pr.exclusions = v; }, { placeholder: 'What is outside the study, and where it is covered' })));
    d.appendChild(rows('Team members', pr.team, [
      function (r) { return T(r.name, function (v) { r.name = v; }, { placeholder: 'Name' }); },
      function (r) { return T(r.role, function (v) { r.role = v; }, { placeholder: 'Study role, e.g. Facilitator, Scribe' }); },
      function (r) { return T(r.discipline, function (v) { r.discipline = v; }, { placeholder: 'Discipline / company' }); }
    ], function () { return { id: U.uid('tm'), name: '', role: '', discipline: '' }; }, '+ Team member'));
    d.appendChild(rows('Study sessions', p.sessions, [
      function (r) { return el('input', { type: 'date', value: r.date || '', oninput: PHA.ui.setField(function (v) { r.date = v; }) }); },
      function (r) { return T(r.note, function (v) { r.note = v; }, { placeholder: 'Nodes covered, location, notes' }); }
    ], function () { return { id: U.uid('ses'), date: '', note: '' }; }, '+ Session date'));
    d.appendChild(rows('Assumptions', pr.assumptions, [
      function (r) { return T(r.text, function (v) { r.text = v; }, { placeholder: 'e.g. Relief valve PSV-101 sized for fire case (to be confirmed)' }); },
      function (r) { return PHA.ui.select(r.status, ASSUMPTION_STATUS, function (e) { var v = e.target.value || 'open'; store.change(function () { r.status = v; }, 'field'); }, 'Status'); }
    ], function () { return { id: U.uid('asm'), text: '', status: 'open' }; }, '+ Assumption'));
    d.appendChild(el('div', { 'class': 'row end' }, el('button', { 'class': 'primary', 'data-act': 'study-done', onclick: function () { d.close(); } }, 'Done')));
    d.scrollTop = top;
  }

  function open() {
    render();
    var d = dlg();
    if (!d.open) { if (d.showModal) d.showModal(); else d.setAttribute('open', ''); }
  }
  store.on('change', function (e) { var d = dlg(); if (d && d.open && e.kind !== 'field') render(); });
  store.on('restore', function () { var d = dlg(); if (d && d.open) render(); });

  PHA.study = { open: open, ASSUMPTION_STATUS: ASSUMPTION_STATUS };
})();
