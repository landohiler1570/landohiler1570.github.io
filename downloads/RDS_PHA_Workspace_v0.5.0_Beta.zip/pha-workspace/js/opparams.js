/* opparams.js: operating parameters and limits for a node, with basic consistency checks and an operating envelope.
   Every limit is typed by the team from an engineering source. Nothing is pre-filled or assumed. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, sv = U.sv, store = PHA.store, C = PHA.calc, M = PHA.modules;
  var KEY = 'operatingParameters';

  var UNIT_HINTS = {
    pressure: ['psig', 'psia', 'barg', 'bara', 'kPa', 'inH2O'],
    temperature: ['°F', '°C', 'K'],
    flow: ['gpm', 'lb/h', 'kg/h', 'm3/h', 'scfm'],
    level: ['%', 'in', 'ft', 'mm', 'm']
  };
  var ROWS = [
    ['Normal range', 'normalMin', 'normalMax'],
    ['Alarm setpoint', 'alarmLow', 'alarmHigh'],
    ['Trip setpoint', 'tripLow', 'tripHigh'],
    ['Safe operating limit', 'safeMin', 'safeMax'],
    ['Design limit', 'designMin', 'designMax']
  ];
  var BAND_COLORS = { normal: '#7fbf7f', margin: '#d5e8d4', alarm: '#ffd966', trip: '#f4a259', beyond: '#e06666' };

  function title(o) {
    var t = [o.measurement, o.name].filter(Boolean).join(': ') || 'New parameter';
    return t + (o.tag ? ' (' + o.tag + ')' : '');
  }

  /* ---- operating envelope ---- */

  function envelopeSvg(o) {
    var env = C.envelope(o);
    if (!env) return el('div', { 'class': 'muted pad' }, 'Enter at least two different values to draw the operating envelope.');
    var Wd = 640, X0 = 24, X1 = 616, BY = 62, BH = 26;
    function x(f) { return X0 + f * (X1 - X0); }
    var svg = sv('svg', { viewBox: '0 0 ' + Wd + ' 148', 'class': 'envelope', role: 'img', 'aria-label': 'Operating envelope for ' + title(o) });
    svg.appendChild(sv('rect', { x: X0, y: BY, width: X1 - X0, height: BH, fill: '#e3e8ee' }));
    env.bands.forEach(function (b) {
      var r = sv('rect', { x: x(b.x0), y: BY, width: Math.max(0.5, x(b.x1) - x(b.x0)), height: BH, fill: BAND_COLORS[b.cls] });
      var t = sv('title'); t.textContent = C.BAND_LABELS[b.cls] + ': ' + C.fmt(b.from) + ' to ' + C.fmt(b.to) + (o.unit ? ' ' + o.unit : '');
      r.appendChild(t); svg.appendChild(r);
    });
    svg.appendChild(sv('rect', { x: X0, y: BY, width: X1 - X0, height: BH, fill: 'none', stroke: '#7b8794', 'stroke-width': 1 }));

    // labels alternate above and below the bar, stepping outward when they would overlap
    var marks = env.marks.slice().sort(function (a, b) { return a.x - b.x; });
    var rowsUsed = { up: [[], [], []], down: [[], [], []] };
    marks.forEach(function (m, i) {
      var text = m.short + ' ' + C.fmt(m.value), w = text.length * 6.3 + 10, cx = U.clamp(x(m.x), X0 + w / 2 - 14, X1 - w / 2 + 14);
      var side = i % 2 === 0 ? 'up' : 'down', rows = rowsUsed[side], row = 0;
      for (row = 0; row < rows.length; row++) {
        if (!rows[row].some(function (r) { return Math.abs(r.cx - cx) < (r.w + w) / 2; })) break;
      }
      if (row === rows.length) row = rows.length - 1;
      rows[row].push({ cx: cx, w: w });
      var ty = side === 'up' ? BY - 12 - row * 15 : BY + BH + 20 + row * 15;
      var limit = /^(safe|design)/.test(m.key);
      svg.appendChild(sv('line', { x1: x(m.x), y1: side === 'up' ? ty + 3 : BY - 4, x2: x(m.x), y2: side === 'up' ? BY + BH + 4 : ty - 11,
        stroke: limit ? '#16202b' : '#44505c', 'stroke-width': limit ? 2 : 1.2, 'stroke-dasharray': /^(alarm)/.test(m.key) ? '3 2' : null }));
      var tx = sv('text', { x: cx, y: ty, 'text-anchor': 'middle', 'font-size': 11.5, 'font-weight': limit ? 700 : 400, fill: '#16202b' });
      tx.textContent = text;
      svg.appendChild(tx);
    });
    var wrap = el('div', { 'class': 'env-wrap' });
    wrap.appendChild(svg);
    var seen = {}, legend = el('div', { 'class': 'env-legend' });
    env.bands.forEach(function (b) {
      if (seen[b.cls]) return;
      seen[b.cls] = true;
      legend.appendChild(el('span', null, el('i', { style: { background: BAND_COLORS[b.cls] } }), C.BAND_LABELS[b.cls]));
    });
    legend.appendChild(el('span', null, el('i', { style: { background: '#e3e8ee' } }), 'No limit entered'));
    wrap.appendChild(legend);
    wrap.appendChild(el('div', { 'class': 'muted small' }, 'Drawn only from the values entered above' + (o.unit ? ', in ' + o.unit : '') + '. Blank limits are left blank, not assumed.'));
    return wrap;
  }

  function checksEl(o) {
    var list = C.checkOpParam(o);
    var box = el('div', { 'class': 'checks-box' });
    if (!list.length) {
      var any = C.opValues(o).some(function (v) { return C.isNum(v.value); });
      box.appendChild(el('div', { 'class': 'muted small' }, any ? 'Consistency checks: no ordering problems found among the entered values.' : 'No values entered yet.'));
    } else {
      list.forEach(function (c) { box.appendChild(el('div', { 'class': 'chk ' + c.level }, el('b', null, c.level === 'info' ? 'Note' : 'Check'), ' ', c.msg)); });
    }
    box.appendChild(el('div', { 'class': 'muted small' }, 'These checks compare the entries with each other. They do not confirm that any limit is correct.'));
    return box;
  }

  function checkBadge(o) {
    var n = C.checkOpParam(o).filter(function (c) { return c.level !== 'info'; }).length;
    return n ? el('span', { 'class': 'tag warn' }, n + (n === 1 ? ' check' : ' checks')) : null;
  }

  /* ---- one parameter ---- */

  function card(p, n, o, open) {
    var ui = PHA.ui, S = store.S;
    var c = el('div', { 'class': 'card' + (open ? ' open' : ''), 'data-opp': o.id });
    var ttl = el('span', { 'class': 'dev' }, title(o));
    var badge = el('span', { 'class': 'badge-slot' }, checkBadge(o));
    c.appendChild(el('button', { 'class': 'card-head', onclick: function () { S.ui.openParam = open ? null : o.id; PHA.panel.render(); } },
      el('span', { 'class': 'chev' }, open ? '▾' : '▸'), ttl, o.unit ? el('span', { 'class': 'tag' }, o.unit) : null, badge));
    if (!open) return c;

    var viz = el('div', { 'class': 'viz' });
    function refresh() {
      ttl.textContent = title(o);
      badge.textContent = ''; var b = checkBadge(o); if (b) badge.appendChild(b);
      viz.textContent = '';
      viz.appendChild(envelopeSvg(o));
      viz.appendChild(checksEl(o));
    }
    function txt(get, set, attrs) { return ui.text(get, function (v, proj) { set(v, proj); refresh(); }, attrs); }

    var typesId = 'mt-' + o.id, unitsId = 'un-' + o.id;
    var hints = UNIT_HINTS[String(o.measurement || '').toLowerCase()] || [];
    var body = el('div', { 'class': 'card-body' });
    body.appendChild(el('datalist', { id: typesId }, p.project.measurementTypes.map(function (t) { return el('option', { value: t }); })));
    body.appendChild(el('datalist', { id: unitsId }, hints.map(function (t) { return el('option', { value: t }); })));
    body.appendChild(el('div', { 'class': 'row' },
      ui.field('Measurement', txt(o.measurement, function (v) { o.measurement = v; }, { list: typesId, placeholder: 'Pressure, Temperature, ...', 'data-focus': 'opp:' + o.id }), 'w-meas'),
      ui.field('Description', txt(o.name, function (v) { o.name = v; }, { placeholder: 'e.g. Reactor R-211 pressure' }), 'grow'),
      ui.field('Unit', txt(o.unit, function (v) { o.unit = v; }, { list: unitsId, placeholder: 'unit' }), 'w-id')));
    var drawings = Object.keys(p.drawings).map(function (k) { return [k, p.drawings[k].number || p.drawings[k].file.name]; });
    body.appendChild(el('div', { 'class': 'row' },
      ui.field('Instrument tag', txt(o.tag, function (v) { o.tag = v; }, { placeholder: 'e.g. PI-212' }), 'w-meas'),
      ui.field('Drawing', ui.select(o.drawingId || '', drawings, function (e) { var v = e.target.value || null; store.change(function () { o.drawingId = v; }, 'field'); }, 'Not linked'), 'w-status'),
      ui.field('Engineering source reference', txt(o.source, function (v) { o.source = v; }, { placeholder: 'Data sheet, relief study, SOL table, revision' }), 'grow')));

    var grid = el('div', { 'class': 'limits' });
    grid.appendChild(el('span')); grid.appendChild(el('span', { 'class': 'flabel' }, 'Low side')); grid.appendChild(el('span', { 'class': 'flabel' }, 'High side'));
    function cell(key, label) {
      var inp = el('input', { type: 'text', inputmode: 'decimal', value: o.values[key] || '', 'aria-label': label, 'data-level': key, placeholder: 'not entered',
        oninput: function (e) {
          var v = e.target.value;
          store.change(function () { o.values[key] = v; }, 'field');
          e.target.classList.toggle('invalid', isNaN(C.num(v)) && C.num(v) !== null);
          refresh();
        } });
      inp.classList.toggle('invalid', C.num(o.values[key]) !== null && isNaN(C.num(o.values[key])));
      return inp;
    }
    ROWS.forEach(function (r) {
      grid.appendChild(el('span', { 'class': 'limit-label' }, r[0]));
      grid.appendChild(cell(r[1], r[0] + ', low side'));
      grid.appendChild(cell(r[2], r[0] + ', high side'));
    });
    body.appendChild(grid);
    body.appendChild(viz);
    body.appendChild(ui.field('Notes', ui.area(o.notes, function (v) { o.notes = v; }, { rows: 1 })));
    body.appendChild(el('div', { 'class': 'row end' }, el('button', { 'class': 'danger', onclick: function () {
      if (!confirm('Delete this operating parameter? You can undo this.')) return;
      store.change(function (proj) { delete proj.opParams[o.id]; });
    } }, 'Delete parameter')));
    refresh();
    c.appendChild(body);
    return c;
  }

  function render(p, n) {
    var S = store.S, list = store.byNode(p.opParams, n.id);
    var sec = el('div');
    sec.appendChild(el('div', { 'class': 'sec-head' },
      el('h3', null, 'Operating parameters', el('span', { 'class': 'count' }, String(list.length))),
      el('button', { 'class': 'primary', onclick: function () {
        var id;
        store.change(function (proj) { id = store.createOpParam(proj, n.id).id; M.markApplicable(proj.nodes[n.id], KEY); });
        S.ui.openParam = id; PHA.panel.render(); PHA.panel.focus('opp:' + id);
      } }, '+ Add parameter')));
    if (!list.length) sec.appendChild(el('div', { 'class': 'muted pad' }, 'No operating parameters recorded for this node.'));
    list.forEach(function (o) { sec.appendChild(card(p, n, o, o.id === S.ui.openParam)); });
    return sec;
  }

  M.register(KEY, { count: function (p, n) { return store.byNode(p.opParams, n.id).length; }, render: render });
  PHA.opparams = { envelopeSvg: envelopeSvg, title: title };
})();
