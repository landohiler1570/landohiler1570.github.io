/* calc.js: pure calculations and checks. No DOM, no storage, so everything here is covered by tests/tests.html.
   Rule for the whole file: a blank entry means "not entered". It is never treated as zero and never filled in. */
(function () {
  'use strict';
  var PHA = window.PHA = window.PHA || {};

  var MODULES = [
    { key: 'operatingParameters', label: 'Operating parameters and limits', tab: 'Operating limits', scope: 'node',
      desc: 'Normal ranges, alarm and trip setpoints, safe operating limits and design limits for each node.' },
    { key: 'processSafetyTime', label: 'Process Safety Time analysis', tab: 'Safety time', scope: 'node',
      desc: 'A timeline comparing the response sequence with the time to a hazardous condition.' },
    { key: 'riskMatrix', label: 'Risk matrix', tab: null, scope: 'scenario',
      desc: 'Severity and likelihood ranking on each scenario.' },
    { key: 'safeguardEvaluation', label: 'Safeguard evaluation', tab: null, scope: 'scenario',
      desc: 'Type, independence and dependability questions for each safeguard.' },
    { key: 'humanFactors', label: 'Human factors', tab: 'Human factors', scope: 'node',
      desc: 'Prompts on operator response, procedures, labeling and workload for each node.' }
  ];
  var STATUSES = [['not-evaluated', 'Not evaluated'], ['applicable', 'Applicable'], ['not-applicable', 'Not applicable']];

  /* '' or null -> null (not entered). Anything that is not a plain number -> NaN. */
  function num(v) {
    if (v == null) return null;
    if (typeof v === 'number') return isFinite(v) ? v : NaN;
    var s = String(v).trim();
    if (s === '') return null;
    if (!/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s)) return NaN;
    return Number(s);
  }
  function isNum(n) { return typeof n === 'number' && !isNaN(n); }
  function fmt(n) {
    if (!isNum(n)) return '';
    var r = Math.round(n * 1000) / 1000;
    return String(r);
  }

  /* ---------- modules ---------- */

  function moduleEnabled(p, node, key) {
    var ov = node && node.modules && node.modules[key];
    if (ov === 'on') return true;
    if (ov === 'off') return false;
    return !!(p.project.modules && p.project.modules[key]);
  }
  function moduleStatus(node, key) {
    var s = node && node.moduleStatus && node.moduleStatus[key];
    return (s && s.status) || 'not-evaluated';
  }

  /* ---------- operating parameters ---------- */

  /* Levels in the order they are normally expected to fall, lowest to highest. */
  var OP_LEVELS = [
    { key: 'designMin', label: 'Design minimum', short: 'Design min' },
    { key: 'safeMin', label: 'Safe lower limit', short: 'Safe low' },
    { key: 'tripLow', label: 'Low trip setpoint', short: 'Trip L' },
    { key: 'alarmLow', label: 'Low alarm setpoint', short: 'Alarm L' },
    { key: 'normalMin', label: 'Normal minimum', short: 'Normal min' },
    { key: 'normalMax', label: 'Normal maximum', short: 'Normal max' },
    { key: 'alarmHigh', label: 'High alarm setpoint', short: 'Alarm H' },
    { key: 'tripHigh', label: 'High trip setpoint', short: 'Trip H' },
    { key: 'safeMax', label: 'Safe upper limit', short: 'Safe high' },
    { key: 'designMax', label: 'Design maximum', short: 'Design max' }
  ];
  var LIMIT_KEYS = ['designMin', 'safeMin', 'tripLow', 'alarmLow', 'alarmHigh', 'tripHigh', 'safeMax', 'designMax'];

  function opValues(prm) {
    var vals = (prm && prm.values) || {};
    return OP_LEVELS.map(function (lv) { return { key: lv.key, label: lv.label, short: lv.short, value: num(vals[lv.key]) }; });
  }

  /* Basic consistency checks. They compare the entries with each other; they do not judge whether a limit is right. */
  function checkOpParam(prm) {
    var out = [], vals = opValues(prm);
    vals.forEach(function (v) {
      if (v.value !== null && isNaN(v.value)) out.push({ level: 'error', code: 'nan', key: v.key, msg: v.label + ' is not a number.' });
    });
    var entered = vals.filter(function (v) { return isNum(v.value); });
    for (var i = 0; i + 1 < entered.length; i++) {
      var a = entered[i], b = entered[i + 1];
      if (a.value > b.value) {
        out.push({ level: 'warn', code: 'order', key: a.key, msg: a.label + ' (' + fmt(a.value) + ') is above ' + b.label + ' (' + fmt(b.value) + ').' });
      } else if (a.value === b.value) {
        out.push({ level: 'info', code: 'equal', key: a.key, msg: a.label + ' equals ' + b.label + ' (' + fmt(a.value) + '); there is no margin between them.' });
      }
    }
    if (entered.length && !String((prm && prm.unit) || '').trim()) out.push({ level: 'warn', code: 'unit', msg: 'No unit entered.' });
    var has = {};
    entered.forEach(function (v) { has[v.key] = true; });
    if (has.normalMin !== has.normalMax) out.push({ level: 'info', code: 'normal-one-end', msg: 'The normal range has only one end entered.' });
    var anyLimit = LIMIT_KEYS.some(function (k) { return has[k]; });
    if (anyLimit && !String((prm && prm.source) || '').trim()) {
      out.push({ level: 'info', code: 'source', msg: 'No engineering source is referenced for these limits.' });
    }
    return out;
  }

  /* Geometry for the operating envelope. Only entered values are placed; nothing is inferred for blanks.
     Returns null when there are fewer than two distinct values to draw between. */
  function envelope(prm) {
    var vals = opValues(prm).filter(function (v) { return isNum(v.value); });
    if (vals.length < 2) return null;
    var min = Math.min.apply(null, vals.map(function (v) { return v.value; }));
    var max = Math.max.apply(null, vals.map(function (v) { return v.value; }));
    if (max === min) return null;
    var pad = (max - min) * 0.06, lo = min - pad, hi = max + pad;
    function pos(v) { return (v - lo) / (hi - lo); }
    var by = {};
    vals.forEach(function (v) { by[v.key] = v.value; });
    var bands = [];
    function band(from, to, cls) { if (to > from) bands.push({ from: from, to: to, cls: cls, x0: pos(from), x1: pos(to) }); }
    if (by.normalMin != null && by.normalMax != null) band(by.normalMin, by.normalMax, 'normal');
    var hiChain = [['normalMax', null], ['alarmHigh', 'margin'], ['tripHigh', 'alarm'], ['safeMax', 'trip'], ['designMax', 'beyond']]
      .filter(function (c) { return by[c[0]] != null; });
    for (var i = 0; i + 1 < hiChain.length; i++) band(by[hiChain[i][0]], by[hiChain[i + 1][0]], hiChain[i + 1][1]);
    var loChain = [['normalMin', null], ['alarmLow', 'margin'], ['tripLow', 'alarm'], ['safeMin', 'trip'], ['designMin', 'beyond']]
      .filter(function (c) { return by[c[0]] != null; });
    for (var j = 0; j + 1 < loChain.length; j++) band(by[loChain[j + 1][0]], by[loChain[j][0]], loChain[j + 1][1]);
    return {
      lo: lo, hi: hi, bands: bands,
      marks: vals.map(function (v) { return { key: v.key, label: v.label, short: v.short, value: v.value, x: pos(v.value) }; })
    };
  }

  /* Named by the outer edge only, so a label stays true when an inner level (for example the alarm) is blank. */
  var BAND_LABELS = {
    normal: 'Normal operating range',
    margin: 'Out to the alarm setpoint',
    alarm: 'Out to the trip setpoint',
    trip: 'Out to the safe operating limit',
    beyond: 'Out to the design limit'
  };

  /* ---------- process safety time ---------- */

  var PST_PARTS = [
    { key: 'detect', label: 'Detection delay' },
    { key: 'activate', label: 'Alarm or trip activation' },
    { key: 'response', label: 'Operator or automated response delay' },
    { key: 'action', label: 'Final protective action completion' }
  ];
  var PST_HAZARD = { key: 'hazard', label: 'Time to hazardous condition' };
  var PST_UNITS = [['s', 'seconds'], ['min', 'minutes'], ['h', 'hours']];

  /* Simplified calculation: the response sequence is the plain sum of the entered delays, and the margin is the
     time to the hazardous condition minus that sum. No margin is reported until every value is entered.
     The result never says whether a safeguard is effective; that is a team and engineering judgment. */
  function pstCalc(rec) {
    var t = (rec && rec.times) || {};
    var errors = [], missing = [], sum = 0;
    var parts = PST_PARTS.map(function (pt) {
      var v = num(t[pt.key]);
      if (v === null) missing.push(pt.key);
      else if (isNaN(v) || v < 0) { errors.push(pt.key); v = NaN; }
      else sum += v;
      return { key: pt.key, label: pt.label, value: v };
    });
    var hazard = num(t.hazard);
    if (hazard === null) missing.push('hazard');
    else if (isNaN(hazard) || hazard < 0) { errors.push('hazard'); hazard = NaN; }
    var res = { parts: parts, hazard: hazard, sum: Math.round(sum * 1e9) / 1e9, missing: missing, errors: errors,
                complete: false, margin: null, ratio: null, state: 'incomplete' };
    if (errors.length) { res.state = 'invalid'; return res; }
    if (missing.length) return res;
    res.complete = true;
    res.margin = Math.round((hazard - res.sum) * 1e9) / 1e9;
    res.ratio = hazard > 0 ? res.sum / hazard : null;
    res.state = res.margin > 0 ? 'positive' : (res.margin === 0 ? 'zero' : 'negative');
    return res;
  }

  /* ---------- safeguard evaluation ---------- */

  var SFG_TYPES = ['BPCS control loop', 'Alarm with operator response', 'Safety instrumented function (SIF)',
                   'Pressure relief device', 'Mechanical or passive protection', 'Procedure or administrative control', 'Other'];
  var SFG_CRITERIA = [
    { key: 'independent', label: 'Independent of the initiating cause and of the other safeguards' },
    { key: 'specific', label: 'Specific to this consequence' },
    { key: 'dependable', label: 'Dependable: maintained and tested' },
    { key: 'auditable', label: 'Auditable: performance can be verified' }
  ];
  /* Counts answers only. It is a tally of what the team recorded, not a verdict. */
  function criteriaTally(ev) {
    var c = (ev && ev.criteria) || {}, yes = 0, no = 0, open = 0;
    SFG_CRITERIA.forEach(function (k) {
      if (c[k.key] === 'yes') yes++; else if (c[k.key] === 'no') no++; else open++;
    });
    return { yes: yes, no: no, open: open, total: SFG_CRITERIA.length };
  }

  PHA.calc = {
    MODULES: MODULES, STATUSES: STATUSES, OP_LEVELS: OP_LEVELS, BAND_LABELS: BAND_LABELS,
    PST_PARTS: PST_PARTS, PST_HAZARD: PST_HAZARD, PST_UNITS: PST_UNITS, SFG_TYPES: SFG_TYPES, SFG_CRITERIA: SFG_CRITERIA,
    num: num, isNum: isNum, fmt: fmt, moduleEnabled: moduleEnabled, moduleStatus: moduleStatus,
    opValues: opValues, checkOpParam: checkOpParam, envelope: envelope, pstCalc: pstCalc, criteriaTally: criteriaTally
  };
})();
