/* annotate.js: the annotation layer. Node regions are SVG shapes drawn over the page.
   Points are stored as fractions of the page (0..1), so they stay aligned at any zoom or window size.
   Nothing here reads the drawing's content: a node is whatever the facilitator outlines. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, sv = U.sv, store = PHA.store, V = PHA.viewer;

  var stage, fills, overlay, hint;
  var mode = 'select';       // select | pan | polygon | rect
  var target = null;         // node id that the next drawn region is added to; null = make a new node
  var draft = null;          // shape being drawn
  var gesture = null;
  var spaceDown = false;
  var modeListeners = [];

  var HINTS = {
    select: 'Click a node to open its analysis. Drag a corner handle to reshape. Drag empty space to pan, scroll to zoom.',
    pan: 'Drag to pan. Scroll to zoom.',
    polygon: 'Click each corner of the node. Double-click or press Enter to finish. Backspace removes the last point, Esc cancels.',
    rect: 'Drag a box around the node. Esc cancels.'
  };

  function setMode(m, targetNodeId) {
    mode = m;
    target = (m === 'polygon' || m === 'rect') ? (targetNodeId || null) : null;
    draft = null;
    stage.dataset.mode = m;
    var t = HINTS[m];
    if (target && store.S.project.nodes[target]) t = 'Adding a region to ' + store.S.project.nodes[target].displayId + '. ' + t;
    hint.textContent = t;
    render();
    modeListeners.forEach(function (f) { f(m); });
  }

  /* Node labels: the ID (and scenario count) by default, so long names do not cover neighbouring equipment.
     'name' mode adds the name, shortened; the full name is always in the tooltip and in the node panel. */
  var labelMode = 'id', labelListeners = [];
  try { if (localStorage.getItem('pha.labelMode') === 'name') labelMode = 'name'; } catch (e) { /* ignore */ }
  function shortName(t, max) { t = String(t || ''); return t.length > max ? t.slice(0, max - 1).replace(/\s+\S*$/, '') + '\u2026' : t; }
  function labelText(n, count, sel) {
    var t = n.displayId;
    if (n.name && (labelMode === 'name' || sel)) t += '  ' + shortName(n.name, labelMode === 'name' ? 28 : 24);
    return t + (count ? '  (' + count + ')' : '');
  }
  function cycleLabels() {
    labelMode = labelMode === 'id' ? 'name' : 'id';
    try { localStorage.setItem('pha.labelMode', labelMode); } catch (e) { /* ignore */ }
    labelListeners.forEach(function (f) { f(labelMode); });
    render();
  }

  function pts(points, W, H) {
    return points.map(function (p) { return (p[0] * W).toFixed(2) + ',' + (p[1] * H).toFixed(2); }).join(' ');
  }

  function render() {
    fills.textContent = ''; overlay.textContent = '';
    var S = store.S, p = S.project, vi = V.info();
    if (!p || !S.drawingId || !vi.W) return;
    var W = vi.W, H = vi.H, inv = 1 / vi.k;

    var nodes = Object.keys(p.nodes).map(function (k) { return p.nodes[k]; });
    nodes.sort(function (a, b) { return (a.id === S.sel.nodeId) - (b.id === S.sel.nodeId); });   // selected node on top

    nodes.forEach(function (n) {
      var sel = n.id === S.sel.nodeId;
      var regs = n.regions.filter(function (r) { return r.drawingId === S.drawingId; });
      var count = store.nodeScenarios(p, n.id).length;
      regs.forEach(function (r, i) {
        var P = pts(r.points, W, H);
        fills.appendChild(sv('polygon', { points: P, fill: n.color, 'fill-opacity': sel ? 0.34 : 0.24 }));

        var g = sv('g', { 'class': 'region' + (sel ? ' sel' : ''), 'data-node': n.id, 'data-region': r.id });
        g.appendChild(sv('polygon', { points: P, stroke: n.color }));
        // Full node name as a tooltip on every region of the node.
        var tip = sv('title'); tip.textContent = n.displayId + (n.name ? ' ' + n.name : '') + (count ? ' (' + count + ' scenario' + (count === 1 ? '' : 's') + ')' : '');
        g.appendChild(tip);
        if (i === 0) {
          var minX = Math.min.apply(null, r.points.map(function (q) { return q[0]; })) * W;
          var minY = Math.min.apply(null, r.points.map(function (q) { return q[1]; })) * H;
          var fs = 15 * inv, label = sv('text', { 'class': 'lbl', 'font-size': fs, 'stroke-width': 4 * inv, fill: n.color });
          label.textContent = labelText(n, count, sel);
          // Keep the label on the sheet: below the top edge, and pulled left if it would run off the right edge.
          var estW = label.textContent.length * fs * 0.56;
          var lx = Math.max(0, Math.min(minX, W - estW)), ly = minY - 7 * inv;
          if (ly - fs < 0) ly = minY + fs + 4 * inv;
          label.setAttribute('x', lx); label.setAttribute('y', ly);
          g.appendChild(label);
        }
        overlay.appendChild(g);

        if (sel && mode === 'select') {
          r.points.forEach(function (q, idx) {
            overlay.appendChild(sv('circle', {
              'class': 'handle', cx: q[0] * W, cy: q[1] * H, r: 6 * inv, 'stroke-width': 2 * inv, stroke: n.color,
              'data-node': n.id, 'data-region': r.id, 'data-idx': idx
            }));
          });
        }
      });
    });

    if (draft) {
      var color = (target && p.nodes[target]) ? p.nodes[target].color : store.PALETTE[(p.counters.node - 1) % store.PALETTE.length];
      if (draft.shape === 'rect') {
        var a = draft.a, b = draft.b;
        overlay.appendChild(sv('rect', {
          'class': 'draft', x: Math.min(a[0], b[0]) * W, y: Math.min(a[1], b[1]) * H,
          width: Math.abs(a[0] - b[0]) * W, height: Math.abs(a[1] - b[1]) * H, stroke: color, fill: color
        }));
      } else {
        var line = draft.pts.concat(draft.cursor ? [draft.cursor] : []);
        overlay.appendChild(sv('polyline', { 'class': 'draft', points: pts(line, W, H), stroke: color, fill: color }));
        draft.pts.forEach(function (q, idx) {
          overlay.appendChild(sv('circle', { 'class': 'draft-pt', cx: q[0] * W, cy: q[1] * H, r: (idx === 0 ? 7 : 4) * inv, fill: color, 'stroke-width': 2 * inv }));
        });
      }
    }
  }

  var renderSoon = (function () {
    var queued = false;
    return function () {
      if (queued) return;
      queued = true;
      requestAnimationFrame(function () { queued = false; render(); });
    };
  })();

  function clampPt(n) { return [U.clamp(n[0], 0, 1), U.clamp(n[1], 0, 1)]; }
  function pxDist(a, b) { var vi = V.info(); return Math.hypot((a[0] - b[0]) * vi.W * vi.k, (a[1] - b[1]) * vi.H * vi.k); }

  function finish(points, shape) {
    var S = store.S, isNew = false, nodeId;
    store.change(function (p) {
      var node = target && p.nodes[target];
      if (!node) { node = store.createNode(p); isNew = true; }
      node.regions.push({ id: U.uid('reg'), drawingId: S.drawingId, shape: shape, points: points, validation: 'current' });
      nodeId = node.id;
    });
    setMode('select');
    store.select(nodeId, isNew ? null : S.sel.scenarioId);
    if (isNew && PHA.panel) PHA.panel.focusName();
  }

  function finishPolygon() {
    if (!draft || draft.shape !== 'polygon') return;
    if (draft.pts.length < 3) { hint.textContent = 'A node needs at least three corners. Keep clicking, or press Esc to cancel.'; return; }
    finish(draft.pts.slice(), 'polygon');
  }

  function addPoint(n) {
    n = clampPt(n);
    if (!draft) { draft = { shape: 'polygon', pts: [n], cursor: n }; render(); return; }
    var last = draft.pts[draft.pts.length - 1];
    if (pxDist(n, last) < 3) return;                                   // second click of a double-click
    if (draft.pts.length >= 3 && pxDist(n, draft.pts[0]) < 10) { finishPolygon(); return; }
    draft.pts.push(n);
    render();
  }

  /* ---- pointer handling: one handler on the stage decides what a press means ---- */

  function onDown(e) {
    if (e.button === 2 || !V.info().W) return;
    if (e.target.closest && e.target.closest('#empty')) return;
    var g = { id: e.pointerId, start: [e.clientX, e.clientY], last: [e.clientX, e.clientY], moved: false, kind: null };
    if (spaceDown || e.button === 1 || mode === 'pan') {
      g.kind = 'pan';
    } else if (mode === 'rect') {
      g.kind = 'rect';
      var n = clampPt(V.toNorm(e.clientX, e.clientY));
      draft = { shape: 'rect', a: n, b: n };
    } else if (mode === 'polygon') {
      g.kind = 'tap';
    } else {
      var h = e.target.closest && e.target.closest('.handle');
      var rg = e.target.closest && e.target.closest('.region');
      if (h) {
        g.kind = 'vertex'; g.nodeId = h.dataset.node; g.regionId = h.dataset.region; g.idx = +h.dataset.idx;
      } else {
        g.kind = 'tap'; g.hitNode = rg ? rg.dataset.node : null;
      }
    }
    gesture = g;
    try { stage.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    if (e.button === 1) e.preventDefault();
  }

  function onMove(e) {
    if (mode === 'polygon' && draft && draft.shape === 'polygon') {
      draft.cursor = clampPt(V.toNorm(e.clientX, e.clientY));
      renderSoon();
    }
    var g = gesture;
    if (!g || g.id !== e.pointerId) return;
    var dx = e.clientX - g.last[0], dy = e.clientY - g.last[1];
    if (!g.moved && Math.hypot(e.clientX - g.start[0], e.clientY - g.start[1]) > 4) {
      g.moved = true;
      if (g.kind === 'pan' || g.kind === 'tap') stage.classList.add('panning');
    }
    g.last = [e.clientX, e.clientY];
    if (g.kind === 'pan' || (g.kind === 'tap' && g.moved)) {
      V.panBy(dx, dy);
    } else if (g.kind === 'rect' && draft) {
      draft.b = clampPt(V.toNorm(e.clientX, e.clientY));
      renderSoon();
    } else if (g.kind === 'vertex' && g.moved) {
      var n = clampPt(V.toNorm(e.clientX, e.clientY));
      store.change(function (p) {
        var node = p.nodes[g.nodeId];
        var r = node && node.regions.filter(function (x) { return x.id === g.regionId; })[0];
        if (r) { r.points[g.idx] = n; r.shape = 'polygon'; }
      }, 'geom');
    }
  }

  function onUp(e) {
    var g = gesture;
    if (!g || g.id !== e.pointerId) return;
    gesture = null;
    stage.classList.remove('panning');
    try { stage.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    if (g.kind === 'rect' && draft) {
      var a = draft.a, b = draft.b;
      draft = null;
      if (pxDist(a, [b[0], a[1]]) > 8 && pxDist(a, [a[0], b[1]]) > 8) {
        var x0 = Math.min(a[0], b[0]), x1 = Math.max(a[0], b[0]), y0 = Math.min(a[1], b[1]), y1 = Math.max(a[1], b[1]);
        finish([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], 'rect');
      } else render();
    } else if (g.kind === 'tap' && !g.moved) {
      if (mode === 'polygon') addPoint(V.toNorm(e.clientX, e.clientY));
      else if (mode === 'select') {
        if (g.hitNode !== store.S.sel.nodeId) store.select(g.hitNode, null);
      }
    }
  }

  function onKey(e) {
    if (e.key === 'Escape') {
      if (draft || mode !== 'select') { setMode('select'); e.preventDefault(); }
      return;
    }
    if (U.isTyping(e)) return;
    if (e.key === ' ') { spaceDown = true; stage.classList.add('space'); e.preventDefault(); return; }
    if (draft && draft.shape === 'polygon') {
      if (e.key === 'Enter') { finishPolygon(); e.preventDefault(); }
      else if (e.key === 'Backspace') {
        draft.pts.pop();
        if (!draft.pts.length) draft = null;
        render(); e.preventDefault();
      }
    }
  }

  function init() {
    stage = document.getElementById('stage');
    fills = document.getElementById('fills');
    overlay = document.getElementById('overlay');
    hint = document.getElementById('hint');
    stage.addEventListener('pointerdown', onDown);
    stage.addEventListener('pointermove', onMove);
    stage.addEventListener('pointerup', onUp);
    stage.addEventListener('pointercancel', onUp);
    stage.addEventListener('dblclick', function () { if (mode === 'polygon') finishPolygon(); });
    stage.addEventListener('auxclick', function (e) { e.preventDefault(); });
    document.addEventListener('keydown', onKey);
    document.addEventListener('keyup', function (e) { if (e.key === ' ') { spaceDown = false; stage.classList.remove('space'); } });
    hint.textContent = HINTS.select;
  }

  PHA.annotate = {
    init: init, render: render, setMode: setMode,
    getMode: function () { return mode; }, cycleLabels: cycleLabels, labelText: labelText,
    onLabels: function (f) { labelListeners.push(f); f(labelMode); },
    onMode: function (f) { modeListeners.push(f); }
  };
})();
