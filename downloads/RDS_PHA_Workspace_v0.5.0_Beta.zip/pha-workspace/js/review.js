/* review.js: deviation review, scenario completeness and study completion. No DOM, no storage.
   Used by the wizard, the Node Board, the report and the repository catalog, so all of them count the same way.
   Rule for the whole file: a statistic is only reported from what has actually been recorded. */
(function () {
  'use strict';
  var PHA = window.PHA, store = PHA.store, C = PHA.calc;

  var DEV_STATUSES = [['yes', 'Yes: applicable'], ['no', 'No: not applicable'], ['not-reviewed', 'Not reviewed']];
  var SC_LABEL = { open: 'Draft', verify: 'Pending verification', reviewed: 'Reviewed' };

  function vals(o) { return Object.keys(o || {}).map(function (k) { return o[k]; }); }
  function txt(v) { return String(v == null ? '' : v).trim(); }
  function filled(list) { return (list || []).filter(function (x) { return txt(x && x.text); }); }
  function riskOn(p, sc) { return C.moduleEnabled(p, p.nodes[sc.nodeId], 'riskMatrix'); }
  function scState(sc) { return sc.status === 'reviewed' ? 'reviewed' : sc.status === 'verify' ? 'verify' : 'open'; }

  /* What still stands between a scenario and "Reviewed". blocking: must be fixed first; warnings: shown, not blocking. */
  function scenarioCheck(p, sc) {
    var blocking = [], warnings = [];
    var d = sc.deviationId && p.deviations[sc.deviationId];
    if (!txt(sc.deviation)) blocking.push('No deviation is stated.');
    if (d && d.status !== 'yes') blocking.push('The deviation is not marked applicable (Yes).');
    if (!filled(sc.causes).length) blocking.push('No initiating cause is recorded.');
    if (!filled(sc.consequences).length) blocking.push('No consequence is recorded.');
    if (riskOn(p, sc)) {
      var rs = sc.riskStatus || {};
      if (rs.status === 'not-applicable') { if (!txt(rs.reason)) blocking.push('Risk ranking is marked not applicable without a reason.'); }
      else {
        var u = store.scenarioRisk(p, sc, 'unmitigated'), m = store.scenarioRisk(p, sc, 'mitigated');
        if (!u && !m) blocking.push('No risk ranking is recorded.');
        else if (!u || !m) warnings.push('Only the ranking ' + (u ? 'without' : 'with') + ' safeguards is recorded.');
        if (p.project.riskMatrix.rankBy === 'consequence') {
          var unr = filled(sc.consequences).filter(function (q) { return !(q.risk && (store.riskOf(p, q.risk.unmitigated) || store.riskOf(p, q.risk.mitigated))); }).length;
          if (unr) warnings.push(unr + ' consequence(s) have no ranking of their own.');
        }
      }
    }
    if (!sc.safeguardIds.filter(function (id) { return p.safeguards[id]; }).length) warnings.push('No existing safeguards are recorded.');
    // 0.5.0: Quick-Add text is a suggestion until the team agrees it, and must not keep unfilled placeholders.
    var items = filled(sc.causes).concat(filled(sc.consequences));
    var pending = items.filter(function (x) { return x.teamStatus === 'pending'; }).length;
    if (pending) blocking.push(pending + ' item(s) inserted from the Quick-Add library are not yet confirmed by the team.');
    var holes = items.filter(function (x) { return PHA.library && PHA.library.unfilled(x).length; }).length;
    if (holes) blocking.push(holes + ' item(s) still contain unfilled placeholders such as [Material].');
    var sq = sc.sequence || {};
    if (!sq.direct && !txt(sq.mechanism) && !txt(sq.event)) warnings.push('No failure sequence is recorded (mechanism or hazardous event), and it is not marked as not needed.');
    var legacy = sc.causes.concat(sc.consequences).filter(function (x) { return x.review; }).length;
    if (legacy) warnings.push(legacy + ' item(s) converted from an earlier version are flagged for checking.');
    var open = sc.recommendationIds.filter(function (id) { return p.recommendations[id] && p.recommendations[id].status !== 'closed'; }).length;
    if (open) warnings.push(open + ' recommendation(s) are open. (Open recommendations do not stop a scenario being reviewed.)');
    return { blocking: blocking, warnings: warnings, canReview: !blocking.length };
  }

  /* Where a deviation review stands. complete means nothing more is needed for it in the study. */
  function devState(p, d) {
    var scs = store.deviationScenarios(p, d.id);
    if (d.status === 'not-reviewed') return { key: 'not-reviewed', complete: false, label: 'Not reviewed', scenarios: scs };
    if (d.status === 'no') {
      return txt(d.reason) ? { key: 'na', complete: true, label: 'Not applicable', scenarios: scs }
                           : { key: 'na-no-reason', complete: false, label: 'Not applicable: reason missing', scenarios: scs };
    }
    if (!scs.length) {
      if (d.dispositionType && txt(d.disposition)) {
        return { key: 'yes-dispositioned', complete: true, scenarios: scs,
                 label: d.dispositionType === 'no-credible-scenario' ? 'Applicable: no credible hazardous scenario identified' : 'Applicable: covered elsewhere' };
      }
      if (d.dispositionType) return { key: 'yes-no-scenario', complete: false, label: 'Applicable: disposition chosen but its finding is not written', scenarios: scs };
      return { key: 'yes-no-scenario', complete: false, label: 'Applicable: no scenario or disposition recorded', scenarios: scs };
    }
    var done = scs.filter(function (s) { return scState(s) === 'reviewed'; }).length;
    if (done === scs.length) return { key: 'yes-complete', complete: true, label: 'Applicable: analysis reviewed', scenarios: scs };
    return { key: 'yes-open', complete: false, label: 'Applicable: ' + done + ' of ' + scs.length + ' scenario(s) reviewed', scenarios: scs };
  }

  /* Counts for one node, or for the whole study when nodeId is null. */
  function summary(p, nodeId) {
    var devs = vals(p.deviations).filter(function (d) { return nodeId == null || d.nodeId === nodeId; });
    var scs = vals(p.scenarios).filter(function (s) { return nodeId == null || s.nodeId === nodeId; });
    var s = { deviations: devs.length, decided: 0, notReviewed: 0, applicable: 0, notApplicable: 0, naNoReason: 0, applicableOpen: 0, devComplete: 0,
              fromUpgrade: 0, scenarios: scs.length, reviewed: 0, verify: 0, draft: 0, unranked: 0, openRecs: 0, recs: 0 };
    devs.forEach(function (d) {
      var st = devState(p, d);
      if (d.status === 'not-reviewed') s.notReviewed++; else s.decided++;
      if (d.status === 'yes') s.applicable++;
      if (d.status === 'no') s.notApplicable++;
      if (st.key === 'na-no-reason') s.naNoReason++;
      if (d.status === 'yes' && !st.complete) s.applicableOpen++;
      if (st.complete) s.devComplete++;
      if (d.origin === 'upgrade') s.fromUpgrade++;
    });
    var recSeen = {};
    scs.forEach(function (sc) {
      var st = scState(sc);
      if (st === 'reviewed') s.reviewed++; else if (st === 'verify') s.verify++; else s.draft++;
      if (riskOn(p, sc) && (sc.riskStatus || {}).status !== 'not-applicable' && !store.scenarioRisk(p, sc, 'mitigated') && !store.scenarioRisk(p, sc, 'unmitigated')) s.unranked++;
      sc.recommendationIds.forEach(function (id) {
        var r = p.recommendations[id];
        if (!r || recSeen[id]) return;
        recSeen[id] = true; s.recs++;
        if (r.status !== 'closed') s.openRecs++;
      });
    });
    s.complete = s.deviations > 0 && s.devComplete === s.deviations && s.reviewed === s.scenarios;
    return s;
  }

  /* Plain-language completion lines. Only numbers that come from recorded data. */
  function summaryLines(s) {
    var out = [];
    out.push(s.decided + ' of ' + s.deviations + ' recorded deviation' + (s.deviations === 1 ? '' : 's') + ' reviewed' + (s.notReviewed ? ' (' + s.notReviewed + ' not reviewed)' : '') + '.');
    if (s.decided) out.push(s.applicable + ' applicable, ' + s.notApplicable + ' not applicable' + (s.naNoReason ? ' (' + s.naNoReason + ' without a recorded reason)' : '') + '.');
    out.push(s.scenarios + ' scenario' + (s.scenarios === 1 ? '' : 's') + ' recorded: ' + s.reviewed + ' reviewed, ' + s.verify + ' pending verification, ' + s.draft + ' draft.');
    if (s.applicableOpen) out.push(s.applicableOpen + ' applicable deviation' + (s.applicableOpen === 1 ? ' still needs' : 's still need') + ' analysis or review.');
    if (s.unranked) out.push(s.unranked + ' scenario' + (s.unranked === 1 ? ' has' : 's have') + ' no risk ranking.');
    if (s.recs) out.push(s.openRecs + ' of ' + s.recs + ' recommendation' + (s.recs === 1 ? '' : 's') + ' open.');
    return out;
  }

  /* Everything a report must call out as incomplete. Each entry: { kind, text, nodeId?, ref? }. */
  function outstanding(p) {
    var out = [], pr = p.project;
    function add(kind, text, extra) { out.push(Object.assign({ kind: kind, text: text }, extra || {})); }
    function nodeName(id) { var n = p.nodes[id]; return n ? n.displayId + (n.name ? ' ' + n.name : '') : 'Unknown node'; }
    vals(p.deviations).forEach(function (d) {
      var st = devState(p, d), label = nodeName(d.nodeId) + ': ' + (d.text || 'unnamed deviation');
      if (st.key === 'not-reviewed') add('deviation', label + ' has not been reviewed.', { nodeId: d.nodeId });
      else if (st.key === 'na-no-reason') add('deviation', label + ' is marked not applicable without a recorded basis.', { nodeId: d.nodeId });
      else if (st.key === 'yes-no-scenario') add('deviation', label + ' is applicable but has no scenario or documented disposition.', { nodeId: d.nodeId });
    });
    vals(p.scenarios).forEach(function (sc) {
      var label = sc.displayId + ' (' + nodeName(sc.nodeId) + ', ' + (sc.deviation || 'no deviation') + ')';
      var st = scState(sc);
      if (st === 'verify') add('verify', label + ' is awaiting verification.', { nodeId: sc.nodeId, ref: sc.id });
      else if (st === 'open') add('draft', label + ' is a draft and has not been reviewed.', { nodeId: sc.nodeId, ref: sc.id });
      if (riskOn(p, sc) && (sc.riskStatus || {}).status !== 'not-applicable' && !store.scenarioRisk(p, sc, 'mitigated') && !store.scenarioRisk(p, sc, 'unmitigated')) {
        add('risk', label + ' has no risk ranking.', { nodeId: sc.nodeId, ref: sc.id });
      }
      var pend = sc.causes.concat(sc.consequences).filter(function (x) { return txt(x.text) && (x.teamStatus === 'pending' || (PHA.library && PHA.library.unfilled(x).length)); }).length;
      if (pend) add('pending', label + ' has ' + pend + ' Quick-Add item(s) not yet confirmed by the team or with unfilled placeholders.', { nodeId: sc.nodeId, ref: sc.id });
      if (sc.causes.concat(sc.consequences).some(function (x) { return x.review; })) add('migration', label + ' has text converted from an earlier version that is flagged for checking.', { nodeId: sc.nodeId, ref: sc.id });
    });
    vals(p.recommendations).forEach(function (r) { if (r.status !== 'closed') add('recommendation', r.displayId + ' is open' + (r.text ? ': ' + r.text : '') + '.', { ref: r.id }); });
    (pr.assumptions || []).forEach(function (a) { if (a.status !== 'confirmed' && a.status !== 'closed' && txt(a.text)) add('assumption', 'Assumption not confirmed: ' + a.text); });
    // missing supporting information
    if (!txt(pr.scope)) add('info', 'The study scope is not recorded.');
    if (!txt(pr.purpose)) add('info', 'The study purpose is not recorded.');
    if (!(pr.team || []).some(function (t) { return txt(t.name); })) add('info', 'No team members are recorded.');
    if (!(p.sessions || []).some(function (s) { return txt(s.date); })) add('info', 'No study session dates are recorded.');
    var rm = pr.riskMatrix || {};
    if (!txt(rm.source)) add('info', 'The risk matrix has no source reference' + (rm.note ? '; it may still be the application\'s placeholder matrix' : '') + '.');
    vals(p.nodes).forEach(function (n) {
      if (!txt(n.designIntent)) add('info', nodeName(n.id) + ' has no design intent recorded.', { nodeId: n.id });
      if (!store.nodeDeviations(p, n.id).length) add('info', nodeName(n.id) + ' has no deviations recorded.', { nodeId: n.id });
    });
    vals(p.drawings).forEach(function (d) { if (!txt(d.revision)) add('info', 'Drawing ' + (d.number || d.file.name) + ' has no revision recorded.'); });
    vals(p.opParams).forEach(function (o) {
      var anyLimit = C.checkOpParam(o).some(function (c) { return c.code === 'source'; });
      if (anyLimit) add('info', 'Operating limits for ' + (o.name || o.measurement || 'a parameter') + ' (' + nodeName(o.nodeId) + ') have no engineering source.', { nodeId: o.nodeId });
    });
    return out;
  }

  /* Node Board filtering. opts: { nodeId, q, risk ('' | band label | 'unranked'), completion ('' | 'complete' | 'incomplete'), openRecs } */
  function filterScenarios(p, opts) {
    opts = opts || {};
    var q = txt(opts.q).toLowerCase();
    return vals(p.scenarios).filter(function (sc) {
      if (opts.nodeId && sc.nodeId !== opts.nodeId) return false;
      if (q && (sc.deviation + ' ' + sc.parameter + ' ' + sc.guideword + ' ' + sc.displayId).toLowerCase().indexOf(q) < 0) return false;
      if (opts.risk) {
        var k = store.scenarioRisk(p, sc, 'mitigated') || store.scenarioRisk(p, sc, 'unmitigated');
        if (opts.risk === 'unranked' ? !!k : (!k || k.label !== opts.risk)) return false;
      }
      if (opts.completion === 'complete' && scState(sc) !== 'reviewed') return false;
      if (opts.completion === 'incomplete' && scState(sc) === 'reviewed') return false;
      if (opts.completion === 'verify' && scState(sc) !== 'verify') return false;
      if (opts.openRecs && !sc.recommendationIds.some(function (id) { return p.recommendations[id] && p.recommendations[id].status !== 'closed'; })) return false;
      return true;
    }).sort(function (a, b) { return (a.displayId || '').localeCompare(b.displayId || '', undefined, { numeric: true }); });
  }

  /* Small completion record for the repository catalog row, so the register never has to open a project to print it. */
  function catalogCompletion(p) {
    var s = summary(p, null);
    return { deviations: s.deviations, notReviewed: s.notReviewed, scenarios: s.scenarios, reviewed: s.reviewed, verify: s.verify,
             draft: s.draft, openRecs: s.openRecs, complete: s.complete, outstanding: outstanding(p).filter(function (o) { return o.kind !== 'info'; }).length };
  }

  PHA.review = {
    DEV_STATUSES: DEV_STATUSES, SC_LABEL: SC_LABEL, scState: scState, scenarioCheck: scenarioCheck, devState: devState,
    summary: summary, summaryLines: summaryLines, outstanding: outstanding, filterScenarios: filterScenarios, catalogCompletion: catalogCompletion
  };
})();
