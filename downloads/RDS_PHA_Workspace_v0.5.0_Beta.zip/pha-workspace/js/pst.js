/* pst.js: Process Safety Time analysis for a node.
   The diagram is drawn from the times the team enters. The arithmetic is a plain sum (see calc.js);
   it is not a validated dynamic model and it never declares a safeguard effective. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, sv = U.sv, store = PHA.store, C = PHA.calc, M = PHA.modules;
  var KEY = 'processSafetyTime';
  var COLORS = { detect: '#4f81d9', activate: '#8a6bd1', response: '#d98a1f', action: '#2f9e94', hazard: '#c9d1da' };
  var CONCLUSIONS = [['adequate', 'Team judged the response time adequate'], ['inadequate', 'Team judged the response time not adequate'], ['study', 'Needs engineering study']];

  function unitWord(rec) { return rec.unit || 's'; }
  function title(rec, p) {
    if (rec.title) return rec.title;
    var sc = rec.scenarioId && p && p.scenarios[rec.scenarioId];
    return sc && sc.deviation ? 'Safety time: ' + sc.deviation : 'New safety time analysis';
  }
  function marginText(rec) {
    var r = C.pstCalc(rec), u = unitWord(rec);
    if (r.state === 'invalid') return 'a time entry is not a valid number';
    if (!r.complete) return 'incomplete, margin not calculated';
    if (r.state === 'negative') return 'shortfall ' + C.fmt(-r.margin) + ' ' + u;
    return 'margin ' + C.fmt(r.margin) + ' ' + u;
  }
  function summary(rec) { return (rec.title || 'Safety time analysis') + ': ' + marginText(rec) + ' (simplified sum)'; }

  function niceStep(max) {
    var raw = max / 5, pow = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / pow;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * pow;
  }

  /* ---- timeline diagram ---- */

  function diagram(rec, onPick) {
    var r = C.pstCalc(rec), u = unitWord(rec);
    var haz = C.isNum(r.hazard) ? r.hazard : null;
    var max = Math.max(haz || 0, r.sum || 0);
    if (!(max > 0)) return el('div', { 'class': 'muted pad' }, 'Enter times to draw the timeline.');
    var X0 = 26, X1 = 610, span = max * 1.1;
    function x(t) { return X0 + (t / span) * (X1 - X0); }
    var svg = sv('svg', { viewBox: '0 0 640 172', 'class': 'pst-svg', role: 'img', 'aria-label': 'Process safety time timeline' });
    function text(s, attrs) { var t = sv('text', attrs); t.textContent = s; svg.appendChild(t); return t; }
    function tip(node, s) { var t = sv('title'); t.textContent = s; node.appendChild(t); }

    // axis
    svg.appendChild(sv('line', { x1: X0, y1: 128, x2: X1, y2: 128, stroke: '#7b8794' }));
    var step = niceStep(span);
    for (var tk = 0; tk <= span + 1e-9; tk += step) {
      svg.appendChild(sv('line', { x1: x(tk), y1: 128, x2: x(tk), y2: 133, stroke: '#7b8794' }));
      text(C.fmt(tk), { x: x(tk), y: 146, 'text-anchor': 'middle', 'font-size': 11, fill: '#44505c' });
    }
    text('Time since the initiating event (' + u + ')', { x: X1, y: 164, 'text-anchor': 'end', 'font-size': 11, fill: '#44505c' });

    // initiating event
    svg.appendChild(sv('line', { x1: X0, y1: 20, x2: X0, y2: 128, stroke: '#16202b', 'stroke-width': 2 }));
    text('Initiating event', { x: X0 + 5, y: 16, 'font-size': 11.5, 'font-weight': 700, fill: '#16202b' });

    // response sequence, drawn in order until the first missing value
    text('Response sequence', { x: X0 + 5, y: 34, 'font-size': 10.5, fill: '#44505c' });
    var t0 = 0, broken = null;
    r.parts.forEach(function (pt, i) {
      if (broken) return;
      if (!C.isNum(pt.value)) { broken = pt; return; }
      var seg = sv('rect', { x: x(t0), y: 40, width: Math.max(1, x(t0 + pt.value) - x(t0)), height: 26, fill: COLORS[pt.key], 'class': 'seg', 'data-key': pt.key, tabindex: 0 });
      tip(seg, pt.label + ': ' + C.fmt(pt.value) + ' ' + u + ' (from ' + C.fmt(t0) + ' to ' + C.fmt(t0 + pt.value) + ')');
      svg.appendChild(seg);
      if (x(t0 + pt.value) - x(t0) > 16) text(String(i + 1), { x: (x(t0) + x(t0 + pt.value)) / 2, y: 58, 'text-anchor': 'middle', 'font-size': 12, 'font-weight': 700, fill: '#fff', 'pointer-events': 'none' });
      t0 += pt.value;
    });
    if (broken) text('not entered: ' + broken.label, { x: x(t0) + 6, y: 58, 'font-size': 11.5, 'font-style': 'italic', fill: '#b00020' });
    else if (r.complete || !r.missing.filter(function (k) { return k !== 'hazard'; }).length) {
      svg.appendChild(sv('line', { x1: x(t0), y1: 36, x2: x(t0), y2: 72, stroke: '#16202b', 'stroke-width': 1.5 }));
    }

    // time to hazardous condition
    if (haz !== null) {
      var hb = sv('rect', { x: X0, y: 88, width: Math.max(1, x(haz) - X0), height: 20, fill: COLORS.hazard, 'class': 'seg', 'data-key': 'hazard', tabindex: 0 });
      tip(hb, C.PST_HAZARD.label + ': ' + C.fmt(haz) + ' ' + u);
      svg.appendChild(hb);
      text('Time to hazardous condition', { x: X0 + 6, y: 102, 'font-size': 11, fill: '#16202b', 'pointer-events': 'none' });
      svg.appendChild(sv('line', { x1: x(haz), y1: 24, x2: x(haz), y2: 128, stroke: '#b00020', 'stroke-width': 2, 'stroke-dasharray': '5 3' }));
      text('Hazardous condition  ' + C.fmt(haz) + ' ' + u, { x: Math.min(x(haz), X1) - 4, y: 20, 'text-anchor': 'end', 'font-size': 11.5, 'font-weight': 700, fill: '#b00020' });
    }

    // margin, only when every value is entered
    if (r.complete) {
      var a = x(Math.min(r.sum, haz)), b = x(Math.max(r.sum, haz)), neg = r.state === 'negative', col = neg ? '#b00020' : '#003366';
      if (b - a > 1) {
        svg.appendChild(sv('line', { x1: a, y1: 78, x2: b, y2: 78, stroke: col, 'stroke-width': 2 }));
        svg.appendChild(sv('line', { x1: a, y1: 73, x2: a, y2: 83, stroke: col, 'stroke-width': 2 }));
        svg.appendChild(sv('line', { x1: b, y1: 73, x2: b, y2: 83, stroke: col, 'stroke-width': 2 }));
      }
      var label = (neg ? 'Shortfall ' + C.fmt(-r.margin) : 'Margin ' + C.fmt(r.margin)) + ' ' + u;
      var wide = b - a > label.length * 6.6 + 12;
      var lx = wide ? (a + b) / 2 : (a > 320 ? a - 6 : b + 6);
      var bg = sv('rect', { x: (wide ? lx - label.length * 3.3 - 4 : (a > 320 ? lx - label.length * 6.6 - 4 : lx - 4)), y: 70, width: label.length * 6.6 + 8, height: 16, fill: '#fff', opacity: 0.9 });
      svg.appendChild(bg);
      text(label, { x: lx, y: 82, 'text-anchor': wide ? 'middle' : (a > 320 ? 'end' : 'start'), 'font-size': 12, 'font-weight': 700, fill: col });
    }

    function pick(e) { var k = e.target.getAttribute && e.target.getAttribute('data-key'); if (k && onPick) onPick(k); }
    svg.addEventListener('click', pick);
    svg.addEventListener('keydown', function (e) { if (e.key === 'Enter') pick(e); });
    return svg;
  }

  function resultEl(rec) {
    var r = C.pstCalc(rec), u = unitWord(rec), box = el('div', { 'class': 'pst-result' });
    function labelOf(k) { return k === 'hazard' ? C.PST_HAZARD.label : C.PST_PARTS.filter(function (pt) { return pt.key === k; })[0].label; }
    if (r.state === 'invalid') {
      box.appendChild(el('div', { 'class': 'chk error' }, el('b', null, 'Check'), ' Not a valid time (must be a number, zero or greater): ' + r.errors.map(labelOf).join(', ') + '.'));
    } else if (!r.complete) {
      box.appendChild(el('div', { 'class': 'chk info' }, el('b', null, 'Incomplete'), ' Margin is not calculated until every time is entered. Not entered: ' + r.missing.map(labelOf).join(', ') + '. Blank is not treated as zero.'));
      if (r.sum > 0) box.appendChild(el('div', { 'class': 'pst-line' }, 'Sum of the delays entered so far: ', el('b', null, C.fmt(r.sum) + ' ' + u)));
    } else {
      box.appendChild(el('div', { 'class': 'pst-line' }, 'Response sequence (sum of the four delays): ', el('b', null, C.fmt(r.sum) + ' ' + u)));
      box.appendChild(el('div', { 'class': 'pst-line' }, 'Time to hazardous condition: ', el('b', null, C.fmt(r.hazard) + ' ' + u)));
      var m = el('div', { 'class': 'pst-line pst-margin ' + r.state },
        r.state === 'negative' ? 'Shortfall: ' : 'Available response margin: ',
        el('b', null, C.fmt(Math.abs(r.margin)) + ' ' + u),
        r.ratio !== null ? ' (the response sequence uses ' + Math.round(r.ratio * 100) + '% of the available time)' : '');
      box.appendChild(m);
      if (r.state === 'negative') box.appendChild(el('div', { 'class': 'chk warn' }, el('b', null, 'Check'), ' By this simplified sum, the protective action completes after the hazardous condition is reached.'));
      if (r.state === 'zero') box.appendChild(el('div', { 'class': 'chk warn' }, el('b', null, 'Check'), ' By this simplified sum there is no margin.'));
    }
    box.appendChild(el('div', { 'class': 'caution' },
      el('b', null, 'Simplified calculation. '),
      'It adds the times entered above and subtracts them from the time to the hazardous condition. It is not a validated engineering model, and a positive margin on its own does not show that the safeguard is effective. Confirm the times with test records, vendor data or process simulation, and record the team\'s judgment below.'));
    return box;
  }

  /* ---- one analysis ---- */

  function card(p, n, rec, open) {
    var ui = PHA.ui, S = store.S;
    var c = el('div', { 'class': 'card' + (open ? ' open' : ''), 'data-pst': rec.id });
    var ttl = el('span', { 'class': 'dev' }, title(rec, p));
    var tag = el('span', { 'class': 'tag' }, marginText(rec));
    c.appendChild(el('button', { 'class': 'card-head', onclick: function () { S.ui.openPst = open ? null : rec.id; PHA.panel.render(); } },
      el('span', { 'class': 'chev' }, open ? '▾' : '▸'), ttl, tag));
    if (!open) return c;

    var body = el('div', { 'class': 'card-body' }), viz = el('div', { 'class': 'viz' }), inputs = {};
    function refresh() {
      ttl.textContent = title(rec, p); tag.textContent = marginText(rec);
      viz.textContent = '';
      viz.appendChild(diagram(rec, function (k) { if (inputs[k]) { inputs[k].focus(); inputs[k].select(); } }));
      viz.appendChild(resultEl(rec));
    }

    var scenarios = store.nodeScenarios(p, n.id).map(function (sc) { return [sc.id, sc.deviation || 'Unnamed deviation']; });
    var sgIds = [];
    (rec.scenarioId && p.scenarios[rec.scenarioId] ? [p.scenarios[rec.scenarioId]] : store.nodeScenarios(p, n.id)).forEach(function (sc) {
      sc.safeguardIds.forEach(function (id) { if (sgIds.indexOf(id) < 0 && p.safeguards[id]) sgIds.push(id); });
    });
    if (rec.safeguardId && sgIds.indexOf(rec.safeguardId) < 0 && p.safeguards[rec.safeguardId]) sgIds.push(rec.safeguardId);
    var safeguards = sgIds.map(function (id) { return [id, p.safeguards[id].description || 'Unnamed safeguard']; });

    body.appendChild(ui.field('Title', ui.text(rec.title, function (v) { rec.title = v; refresh(); }, { placeholder: 'e.g. High level trip closes XV-210', 'data-focus': 'pst:' + rec.id })));
    body.appendChild(el('div', { 'class': 'row two' },
      ui.field('Scenario', ui.select(rec.scenarioId || '', scenarios, function (e) {
        var v = e.target.value || null; store.change(function () { rec.scenarioId = v; });
      }, 'Not linked')),
      ui.field('Safeguard', ui.select(rec.safeguardId || '', safeguards, function (e) {
        var v = e.target.value || null; store.change(function () { rec.safeguardId = v; }, 'field');
      }, 'Not linked'))));
    body.appendChild(el('div', { 'class': 'row' },
      ui.field('Time unit', ui.select(rec.unit, C.PST_UNITS, function (e) {
        var v = e.target.value || 's'; store.change(function () { rec.unit = v; }, 'field'); refresh();
      }, null), 'w-status'),
      ui.field('Response by', ui.select(rec.responseBy, [['operator', 'Operator action'], ['automated', 'Automated action']], function (e) {
        var v = e.target.value; store.change(function () { rec.responseBy = v; }, 'field');
      }, 'Not stated'), 'w-status'),
      el('div', { 'class': 'muted small grow' }, 'Changing the unit relabels the entries. It does not convert them.')));

    var grid = el('div', { 'class': 'times' });
    function timeRow(key, label, n) {
      var inp = el('input', { type: 'text', inputmode: 'decimal', value: rec.times[key] || '', placeholder: 'not entered', 'aria-label': label, 'data-time': key,
        oninput: function (e) {
          var v = e.target.value;
          store.change(function () { rec.times[key] = v; }, 'field');
          var parsed = C.num(v);
          e.target.classList.toggle('invalid', parsed !== null && (isNaN(parsed) || parsed < 0));
          refresh();
        } });
      inputs[key] = inp;
      grid.appendChild(el('span', { 'class': 'tchip', style: { background: COLORS[key] } }, n || ''));
      grid.appendChild(el('span', { 'class': 'limit-label' }, label));
      grid.appendChild(inp);
    }
    timeRow('hazard', C.PST_HAZARD.label + ' (process safety time)', '');
    C.PST_PARTS.forEach(function (pt, i) { timeRow(pt.key, pt.label, String(i + 1)); });
    body.appendChild(grid);
    body.appendChild(viz);
    body.appendChild(ui.field('Basis and sources for the times', ui.area(rec.basis, function (v) { rec.basis = v; },
      { placeholder: 'Where each time comes from: calculation, valve stroke test, alarm rationalization, simulation, vendor data' })));
    body.appendChild(ui.field('Team conclusion (entered by the team, never set by the app)', ui.select(rec.conclusion, CONCLUSIONS, function (e) {
      var v = e.target.value; store.change(function () { rec.conclusion = v; }, 'field');
    }, 'Not evaluated')));
    body.appendChild(ui.field('Notes', ui.area(rec.notes, function (v) { rec.notes = v; }, { rows: 1 })));
    body.appendChild(el('div', { 'class': 'row end' }, el('button', { 'class': 'danger', onclick: function () {
      if (!confirm('Delete this safety time analysis? You can undo this.')) return;
      store.change(function (proj) { delete proj.pst[rec.id]; });
    } }, 'Delete analysis')));
    refresh();
    c.appendChild(body);
    return c;
  }

  function render(p, n) {
    var S = store.S, list = store.byNode(p.pst, n.id);
    var sec = el('div');
    sec.appendChild(el('div', { 'class': 'sec-head' },
      el('h3', null, 'Safety time analyses', el('span', { 'class': 'count' }, String(list.length))),
      el('button', { 'class': 'primary', onclick: function () {
        var id;
        store.change(function (proj) {
          var t = store.createPst(proj, n.id);
          if (S.sel.scenarioId && proj.scenarios[S.sel.scenarioId]) t.scenarioId = S.sel.scenarioId;
          M.markApplicable(proj.nodes[n.id], KEY);
          id = t.id;
        });
        S.ui.openPst = id; PHA.panel.render(); PHA.panel.focus('pst:' + id);
      } }, '+ Add analysis')));
    if (!list.length) sec.appendChild(el('div', { 'class': 'muted pad' }, 'No safety time analysis recorded for this node.'));
    list.forEach(function (rec) { sec.appendChild(card(p, n, rec, rec.id === S.ui.openPst)); });
    return sec;
  }

  M.register(KEY, { count: function (p, n) { return store.byNode(p.pst, n.id).length; }, render: render });
  PHA.pst = { summary: summary, marginText: marginText, diagram: diagram };
})();
