/* persist.js: importing drawings, and reading and writing .phaz project files.
   Since 0.3.0 the working copy lives in the repository (repo.js) and is kept current by autosave.js.
   A .phaz file is the portable, permanent copy: export one to back a project up or move it. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, store = PHA.store;

  var handle = null;                               // file handle for save-in-place (Chromium only)
  var hasFSA = typeof window.showSaveFilePicker === 'function';
  var PICK_TYPES = [{ description: 'PHA Workspace project', accept: { 'application/x-pha-project': ['.phaz'] } }];
  var listeners = [];
  function notify(d) { listeners.forEach(function (f) { f(d || {}); }); }

  /* ---------- import drawings ---------- */

  async function importPdfs(fileList) {
    var files = Array.prototype.slice.call(fileList), firstId = null, problems = [];
    for (var i = 0; i < files.length; i++) {
      var f = files[i];
      try {
        var bytes = new Uint8Array(await f.arrayBuffer());
        var sha = await U.sha256(bytes);
        var p = store.S.project;
        var existing = Object.keys(p.drawings).filter(function (k) { return p.drawings[k].file.sha256 === sha; });
        if (existing.length) {
          if (!store.S.files.has(sha)) {            // re-attach a drawing whose PDF was missing
            store.S.files.set(sha, bytes);
            PHA.viewer.resetDocs();
          }
          firstId = firstId || existing[0];
          continue;
        }
        var doc = await PHA.viewer.openPdf(bytes);
        var pages = [];
        for (var n = 1; n <= doc.numPages; n++) {
          var pg = await doc.getPage(n), vp = pg.getViewport({ scale: 1 });
          pages.push({ w: Math.round(vp.width * 100) / 100, h: Math.round(vp.height * 100) / 100, rotation: pg.rotate || 0 });
        }
        doc.destroy();
        store.S.files.set(sha, bytes);
        var baseName = f.name.replace(/\.pdf$/i, '');
        store.change(function (proj) {
          pages.forEach(function (pg, idx) {
            var id = U.uid('drw');
            proj.drawings[id] = {
              id: id,
              number: baseName + (pages.length > 1 ? ' (p' + (idx + 1) + ')' : ''),
              title: '', revision: '', revisionDate: '',
              file: { name: f.name, sha256: sha, bytes: bytes.length },
              page: idx + 1, pageCount: pages.length,
              pageSize: { w: pg.w, h: pg.h, unit: 'pt' }, rotation: pg.rotation,
              importedAt: new Date().toISOString(), supersedes: null
            };
            firstId = firstId || id;
          });
        });
      } catch (e) {
        problems.push(f.name + ': ' + (e && e.message ? e.message : e));
      }
    }
    if (firstId) {
      if (store.S.drawingId === firstId) PHA.viewer.show(); else store.setDrawing(firstId);
    }
    if (PHA.autosave) PHA.autosave.flush();        // store the new drawing in the repository straight away
    if (problems.length) alert('Could not import:\n\n' + problems.join('\n'));
  }

  /* ---------- project file ---------- */

  /* Build a .phaz (a zip): project.json plus each referenced drawing, byte for byte. */
  function zipOf(project, files) {
    var out = {};
    out['project.json'] = [fflate.strToU8(JSON.stringify(project, null, 1)), { level: 6 }];
    var used = {};
    Object.keys(project.drawings).forEach(function (k) { used[project.drawings[k].file.sha256] = true; });
    Object.keys(used).forEach(function (sha) {
      var b = files && files.get(sha);
      if (b) out['drawings/' + sha + '.pdf'] = [b, { level: 0 }];     // stored uncompressed, unchanged
    });
    return fflate.zipSync(out);
  }
  function buildZip() { return zipOf(store.S.project, store.S.files); }

  function fileNameFor(name) { return U.safeName(name) + '.phaz'; }

  async function writeHandle(h, bytes) {
    var w = await h.createWritable();      // writes to a temporary file, swapped in on close
    await w.write(bytes);
    await w.close();
  }

  /* Write bytes to the user's computer. Returns what is actually known about the result:
       { confirmed: true,  method: 'file',     fileName }  the browser reported the file as written
       { confirmed: false, method: 'download', fileName }  a download was started; browsers do not report whether it finished
       null                                                 the user cancelled
     target: an existing file handle to write to again, or null to ask. */
  async function writeOut(bytes, suggestedName, target) {
    if (hasFSA) {
      try {
        var h = target || await window.showSaveFilePicker({ suggestedName: suggestedName, types: PICK_TYPES });
        await writeHandle(h, bytes);
        return { confirmed: true, method: 'file', fileName: h.name, handle: h };
      } catch (e) {
        if (e && e.name === 'AbortError') return null;
        console.warn('Direct file save failed, falling back to download', e);
      }
    }
    var name = suggestedName.replace(/\.phaz$/i, '') + '-' + U.stamp() + '.phaz';
    U.download(bytes, name, 'application/zip');
    return { confirmed: false, method: 'download', fileName: name };
  }

  /* Export the project open in the editor. The local save is flushed first so the file and the repository match. */
  async function save(forceNew) {
    var A = PHA.autosave, sess = A && A.session();
    if (sess && !sess.volatile) await A.flush();
    var bytes;
    try { bytes = buildZip(); } catch (e) { alert('Could not build the project file: ' + e.message); return false; }
    var res = await writeOut(bytes, fileNameFor(store.S.project.project.name), forceNew ? null : handle);
    if (!res) return false;
    handle = res.handle || null;
    sess = A && A.session();
    if (sess && !sess.volatile && PHA.repo.isOpen()) {
      try {
        var m = await PHA.repo.recordExport(sess.id, { rev: sess.baseRev, confirmed: res.confirmed, method: res.method, fileName: res.fileName });
        if (m) sess.meta = m;
      } catch (e) { /* the file was written; only the note of it failed */ }
    }
    notify({ exported: res });
    return res;
  }
  function resetExportTarget() { handle = null; }

  async function parseProject(bytes) {
    var project, files = new Map(), warnings = [];
    if (bytes[0] === 0x50 && bytes[1] === 0x4B) {                  // "PK": a zip bundle
      var z;
      try { z = fflate.unzipSync(bytes); } catch (e) { throw new Error('This file is damaged or is not a .phaz project file.'); }
      if (!z['project.json']) throw new Error('This file does not contain a PHA project.');
      try { project = JSON.parse(fflate.strFromU8(z['project.json'])); } catch (e) { throw new Error('The project record inside this file is damaged and cannot be read.'); }
      var names = Object.keys(z);
      for (var i = 0; i < names.length; i++) {
        var m = /^drawings\/([0-9a-z]+)\.pdf$/i.exec(names[i]);
        if (!m) continue;
        var actual = await U.sha256(z[names[i]]);
        if (m[1].indexOf('nohash') !== 0 && actual.indexOf('nohash') !== 0 && actual !== m[1]) {
          warnings.push('A drawing file inside the project does not match its recorded fingerprint (' + m[1].slice(0, 10) + '). It may have been altered.');
        }
        files.set(m[1], z[names[i]]);
      }
    } else {                                                        // plain JSON export, no drawings
      try { project = JSON.parse(new TextDecoder().decode(bytes)); } catch (e) { throw new Error('This is not a PHA Workspace project file.'); }
    }
    var fromVersion = project && project.schemaVersion;
    store.migrate(project);
    Object.keys(project.drawings).forEach(function (k) {
      var d = project.drawings[k];
      if (!files.has(d.file.sha256)) warnings.push('Drawing "' + d.number + '" has no PDF in this file. Import ' + d.file.name + ' again to re-attach it.');
    });
    return { project: project, files: files, warnings: warnings, fromVersion: fromVersion, migrated: fromVersion !== project.schemaVersion };
  }


  function exportJson() {
    var p = store.S.project;
    U.download(JSON.stringify(p, null, 2), U.safeName(p.project.name) + '-' + U.stamp() + '.json', 'application/json');
  }

  PHA.persist = {
    importPdfs: importPdfs, save: save, exportJson: exportJson, resetExportTarget: resetExportTarget,
    buildZip: buildZip, zipOf: zipOf, parseProject: parseProject, writeOut: writeOut, writeHandle: writeHandle, fileNameFor: fileNameFor,
    hasFSA: hasFSA, onEvent: function (f) { listeners.push(f); }
  };
})();
