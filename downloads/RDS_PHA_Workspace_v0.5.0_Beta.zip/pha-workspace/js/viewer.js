/* viewer.js: renders the current drawing page and owns zoom and pan.
   Two canvases: a whole-page "base" image that makes panning instant, and a "detail" image of just the
   visible area, re-rendered at screen resolution whenever the view settles. The PDF itself is read-only. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, store = PHA.store;

  var stage, base, detail, layers, emptyBox, busyBox, statBox;
  var view = { k: 1, tx: 0, ty: 0 };     // k = screen pixels per PDF point; tx, ty = page origin within the stage
  var W = 0, H = 0;                       // page size in PDF points, after page rotation
  var page = null, baseScale = 1, fitK = 1;
  var docs = new Map();                   // sha256 -> Promise<PDFDocumentProxy>
  var showToken = 0, detailToken = 0, detailTask = null, settleTimer = null, dv = null;
  var viewListeners = [];
  var stats = { worker: 'not started', baseMs: null, detailMs: null };
  var MAX_K = 16;

  /* Start the PDF engine on a background thread when the browser allows it. A page opened from disk cannot
     start a worker from a .js file path, so the worker source ships as a string and is started from a Blob URL.
     If workers are blocked entirely, PDF.js runs the same code on the main thread instead. */
  var workerReady = null, pdfWorker = null;
  function setupWorker() {
    workerReady = new Promise(function (resolve) {
      var url;
      try {
        url = URL.createObjectURL(new Blob([window.PHA_PDF_WORKER_SRC], { type: 'text/javascript' }));
        pdfjsLib.GlobalWorkerOptions.workerSrc = url;            // used by the main-thread fallback
      } catch (e) { stats.worker = 'main thread'; resolve(); return; }
      var done = false;
      function finish(ok) {
        if (done) return;
        done = true;
        if (ok) {
          // One shared engine for every drawing. Passed explicitly so closing a document never shuts it down.
          try { pdfWorker = new pdfjsLib.PDFWorker({ port: new Worker(url) }); stats.worker = 'background thread'; }
          catch (e) { pdfWorker = null; stats.worker = 'main thread'; }
        } else stats.worker = 'main thread';
        resolve();
      }
      try {                                                      // probe: can this page start any Blob worker?
        var probe = new Worker(URL.createObjectURL(new Blob(['postMessage(1)'], { type: 'text/javascript' })));
        probe.onmessage = function () { probe.terminate(); finish(true); };
        probe.onerror = function () { finish(false); };
        setTimeout(function () { finish(false); }, 2500);
      } catch (e) { finish(false); }
    });
  }

  function openPdf(bytes) {
    return workerReady.then(function () {
      // PDF.js takes ownership of the buffer it is given, so always hand it a copy.
      var opts = {
        data: new Uint8Array(bytes),
        isEvalSupported: false,      // closes CVE-2024-4367 in PDF.js 3.x
        enableXfa: false,
        useSystemFonts: true
      };
      if (pdfWorker) opts.worker = pdfWorker;
      return pdfjsLib.getDocument(opts).promise;
    });
  }

  function getDoc(sha) {
    if (!docs.has(sha)) {
      var bytes = store.S.files.get(sha);
      if (!bytes) return Promise.reject(new Error('MISSING_FILE'));
      docs.set(sha, openPdf(bytes));
    }
    return docs.get(sha);
  }

  function resetDocs() {
    docs.forEach(function (p) { p.then(function (d) { d.destroy(); }).catch(function () {}); });
    docs.clear();
  }

  function setEmpty(html) {
    if (html) { emptyBox.hidden = false; if (typeof html === 'string') emptyBox.querySelector('p').textContent = html; }
    else emptyBox.hidden = true;
  }
  function setBusy(msg) { busyBox.hidden = !msg; busyBox.textContent = msg || ''; }
  function showStat() {
    var parts = [];
    if (stats.baseMs != null) parts.push('page ' + Math.round(stats.baseMs) + ' ms');
    if (stats.detailMs != null) parts.push('detail ' + Math.round(stats.detailMs) + ' ms');
    parts.push('PDF engine: ' + stats.worker);
    statBox.textContent = parts.join('  |  ');
  }

  async function show() {
    var my = ++showToken;
    var p = store.S.project, d = p && p.drawings[store.S.drawingId];
    cancelDetail(); dv = null; detail.style.display = 'none';
    if (!d) {
      page = null; W = H = 0;
      layers.forEach(function (e) { e.style.display = 'none'; });
      emptyBox.querySelector('h2').textContent = 'No drawing loaded';
      setEmpty('Import a P&ID PDF to begin. The file is read from your computer and never leaves it.');
      setBusy(''); notify();
      return;
    }
    setEmpty(false);
    setBusy('Rendering ' + (d.number || 'drawing') + ' ...');
    try {
      var doc = await getDoc(d.file.sha256);
      var pg = await doc.getPage(d.page);
      if (my !== showToken) return;
      var vp1 = pg.getViewport({ scale: 1 });
      var bs = Math.min(3, 2800 / Math.max(vp1.width, vp1.height));
      var vp = pg.getViewport({ scale: bs });
      var c = document.createElement('canvas');
      c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
      var t0 = performance.now();
      await pg.render({ canvasContext: c.getContext('2d', { alpha: false }), viewport: vp }).promise;
      if (my !== showToken) return;
      stats.baseMs = performance.now() - t0; stats.detailMs = null;
      page = pg; W = vp1.width; H = vp1.height; baseScale = bs;
      base.width = c.width; base.height = c.height;
      base.getContext('2d').drawImage(c, 0, 0);
      layers.forEach(function (e) {
        e.style.display = 'block';
        if (e.tagName.toLowerCase() === 'svg') e.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
      });
      setBusy('');
      fit();
      showStat();
    } catch (e) {
      if (my !== showToken) return;
      page = null; W = H = 0;
      layers.forEach(function (el) { el.style.display = 'none'; });
      setBusy('');
      emptyBox.querySelector('h2').textContent = 'Drawing file not available';
      setEmpty(e && e.message === 'MISSING_FILE'
        ? 'The PDF for "' + (d.file.name || d.number) + '" is not stored in this project. Import the same file again to re-attach it.'
        : 'This PDF could not be displayed: ' + (e && e.message ? e.message : e));
      notify();
    }
  }

  function cancelDetail() {
    detailToken++;
    if (detailTask) { try { detailTask.cancel(); } catch (e) { /* ignore */ } detailTask = null; }
  }

  /* Keep the last detail image glued to the page while the user pans or zooms. */
  function placeDetail() {
    if (!dv) { detail.style.display = 'none'; return; }
    var s = view.k / dv.k;
    detail.style.left = (view.tx + (dv.left - dv.tx) * s) + 'px';
    detail.style.top = (view.ty + (dv.top - dv.ty) * s) + 'px';
    detail.style.width = (dv.w * s) + 'px';
    detail.style.height = (dv.h * s) + 'px';
    detail.style.display = 'block';
  }

  function apply() {
    var w = W * view.k, h = H * view.k;
    layers.forEach(function (e) {
      e.style.left = view.tx + 'px'; e.style.top = view.ty + 'px';
      e.style.width = w + 'px'; e.style.height = h + 'px';
    });
    placeDetail();
    cancelDetail();
    clearTimeout(settleTimer);
    settleTimer = setTimeout(renderDetail, 170);
    notify();
  }

  function notify() { viewListeners.forEach(function (f) { f(view); }); }

  async function renderDetail() {
    if (!page) return;
    var dpr = window.devicePixelRatio || 1, k = view.k;
    if (k * dpr <= baseScale * 1.02) { dv = null; detail.style.display = 'none'; return; }   // base image is sharp enough
    var sw = stage.clientWidth, sh = stage.clientHeight;
    var x0 = Math.max(0, view.tx), y0 = Math.max(0, view.ty);
    var x1 = Math.min(sw, view.tx + W * k), y1 = Math.min(sh, view.ty + H * k);
    if (x1 - x0 < 2 || y1 - y0 < 2) return;
    var c = document.createElement('canvas');
    c.width = Math.round((x1 - x0) * dpr); c.height = Math.round((y1 - y0) * dpr);
    var snap = { k: k, tx: view.tx, ty: view.ty, left: x0, top: y0, w: x1 - x0, h: y1 - y0 };
    cancelDetail();
    var my = detailToken, t0 = performance.now();
    detailTask = page.render({
      canvasContext: c.getContext('2d', { alpha: false }),
      viewport: page.getViewport({ scale: k * dpr }),
      transform: [1, 0, 0, 1, (view.tx - x0) * dpr, (view.ty - y0) * dpr]
    });
    try { await detailTask.promise; } catch (e) { return; }
    if (my !== detailToken) return;
    detailTask = null;
    detail.width = c.width; detail.height = c.height;
    detail.getContext('2d').drawImage(c, 0, 0);
    dv = snap;
    placeDetail();
    stats.detailMs = performance.now() - t0;
    showStat();
  }

  function fit() {
    if (!W) return;
    var sw = stage.clientWidth, sh = stage.clientHeight;
    fitK = Math.max(0.01, Math.min((sw - 40) / W, (sh - 40) / H));
    view.k = fitK;
    view.tx = (sw - W * fitK) / 2;
    view.ty = (sh - H * fitK) / 2;
    apply();
  }

  function zoomAt(factor, cx, cy) {
    if (!W) return;
    if (cx == null) { cx = stage.clientWidth / 2; cy = stage.clientHeight / 2; }
    var nk = U.clamp(view.k * factor, fitK * 0.25, MAX_K);
    var r = nk / view.k;
    view.tx = cx - (cx - view.tx) * r;
    view.ty = cy - (cy - view.ty) * r;
    view.k = nk;
    apply();
  }

  function panBy(dx, dy) {
    if (!W) return;
    view.tx += dx; view.ty += dy;
    apply();
  }

  /* Screen position -> fraction of the page (0..1 from the top-left corner). */
  function toNorm(clientX, clientY) {
    var r = stage.getBoundingClientRect();
    return [(clientX - r.left - view.tx) / (W * view.k), (clientY - r.top - view.ty) / (H * view.k)];
  }

  function info() { return { W: W, H: H, k: view.k, tx: view.tx, ty: view.ty, fitK: fitK }; }

  function init() {
    stage = document.getElementById('stage');
    base = document.getElementById('base');
    detail = document.getElementById('detail');
    layers = [base, document.getElementById('fills'), document.getElementById('overlay')];
    emptyBox = document.getElementById('empty');
    busyBox = document.getElementById('busy');
    statBox = document.getElementById('stat');
    setupWorker();

    stage.addEventListener('wheel', function (e) {
      e.preventDefault();
      var r = stage.getBoundingClientRect();
      var unit = e.deltaMode === 1 ? 0.05 : (e.ctrlKey ? 0.01 : 0.0015);
      zoomAt(Math.exp(-e.deltaY * unit), e.clientX - r.left, e.clientY - r.top);
    }, { passive: false });

    if (window.ResizeObserver) {
      new ResizeObserver(function () { if (W) apply(); }).observe(stage);
    }
  }

  PHA.viewer = {
    init: init, show: show, resetDocs: resetDocs, openPdf: openPdf, docFor: getDoc,
    fit: fit, zoomAt: zoomAt, panBy: panBy, toNorm: toNorm, info: info, stats: stats,
    onView: function (f) { viewListeners.push(f); }
  };
})();
