/* store.js: the single in-memory project and every rule for changing it.
   Records live in flat collections keyed by a stable id and point at each other by id. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util;

  var SCHEMA_VERSION = 3;
  var APP_VERSION = '0.5.0';
  var PALETTE = ['#1f77b4', '#e6550d', '#2ca02c', '#9467bd', '#d6278f', '#0e8f9c', '#b8860b', '#7f4f24'];

  var S = {
    project: null,
    files: new Map(),          // sha256 -> Uint8Array of the original PDF (never modified)
    sel: { nodeId: null, scenarioId: null },
    drawingId: null,
    dirty: false,
    fileName: null,
    savedAt: null,
    ui: { tab: 'scenarios', openParam: null, openPst: null },  // view state only, never saved
    seq: 0                     // bumps on every change, so autosave can tell whether it saved the latest state
  };

  var listeners = {};
  function on(evt, cb) { (listeners[evt] = listeners[evt] || []).push(cb); }
  function emit(evt, d) { (listeners[evt] || []).forEach(function (cb) { cb(d); }); }

  function blank() {
    var now = new Date().toISOString();
    var base = {
      schemaVersion: SCHEMA_VERSION,
      app: 'PHA Workspace',
      project: {
        id: U.uid('prj'),
        name: '',
        method: 'HAZOP',
        createdAt: now,
        modifiedAt: now,
        guidewords: ['No', 'More', 'Less', 'Reverse', 'As well as', 'Part of', 'Other than'],
        parameters: ['Flow', 'Pressure', 'Temperature', 'Level', 'Composition', 'Other'],
        riskMatrix: {
          note: 'Placeholder 5x5 matrix. Replace with the site risk matrix before a real study.',
          severity: [
            { v: '1', label: '1 - Minor' }, { v: '2', label: '2 - Moderate' }, { v: '3', label: '3 - Serious' },
            { v: '4', label: '4 - Major' }, { v: '5', label: '5 - Catastrophic' }],
          likelihood: [
            { v: '1', label: '1 - Remote' }, { v: '2', label: '2 - Unlikely' }, { v: '3', label: '3 - Possible' },
            { v: '4', label: '4 - Likely' }, { v: '5', label: '5 - Frequent' }],
          bands: [
            { min: 15, label: 'High', color: '#CC0000' },
            { min: 8, label: 'Medium', color: '#C97700' },
            { min: 1, label: 'Low', color: '#2E7D32' }]
        }
      },
      counters: { node: 1, recommendation: 1, scenario: 1 },
      deviations: {},
      drawings: {},
      nodes: {},
      equipment: {},
      scenarios: {},
      safeguards: {},
      recommendations: {},
      sessions: []
    };
    return base;
  }

  var PROJECT_STATUSES = [['draft', 'Draft'], ['in-progress', 'In progress'], ['completed', 'Completed'], ['archived', 'Archived']];
  var STATUS_KEYS = PROJECT_STATUSES.map(function (s) { return s[0]; });
  var DEFAULT_MODULES = { operatingParameters: false, processSafetyTime: false, riskMatrix: true, safeguardEvaluation: false, humanFactors: false };
  var DEFAULT_HF_PROMPTS = [
    { id: 'hf_response', text: 'Operator response to an alarm or abnormal condition is required' },
    { id: 'hf_time', text: 'Time available for the operator to diagnose and act' },
    { id: 'hf_procedure', text: 'Procedures: available, current and clear for this task' },
    { id: 'hf_labeling', text: 'Equipment, valve and instrument labeling' },
    { id: 'hf_access', text: 'Access to valves, controls and instruments' },
    { id: 'hf_alarms', text: 'Alarm load and alarm priority during an upset' },
    { id: 'hf_training', text: 'Training and competency for this operation' },
    { id: 'hf_workload', text: 'Workload, staffing and fatigue' },
    { id: 'hf_handover', text: 'Communication and shift handover' },
    { id: 'hf_error', text: 'Manual steps where a slip or wrong sequence is credible' }
  ];
  function copy(o) { return JSON.parse(JSON.stringify(o)); }
  /* Failure sequence (0.5.0), between the initiating causes and the consequences:
       mechanism  how the deviation could escalate (intermediate failures; none is assumed to occur)
       event      the loss-of-containment or other hazardous event, kept apart from the ultimate consequences
       eventType  'loc' | 'other' | ''        direct  true when the team records that no intermediate mechanism applies */
  function blankSequence() { return { mechanism: '', event: '', eventType: '', direct: false }; }
  var DISPOSITION_TYPES = ['', 'no-credible-scenario', 'covered-elsewhere'];
  function blankRisk() { return { unmitigated: { s: '', l: '' }, mitigated: { s: '', l: '' } }; }
  function hasRisk(sc) {
    var r = sc.risk || {};
    return !!((r.unmitigated && (r.unmitigated.s || r.unmitigated.l)) || (r.mitigated && (r.mitigated.s || r.mitigated.l)));
  }

  /* ---- format 3: individual cause and consequence records ----
     Format 2 kept causes and consequences as arrays of strings, one per line typed in the old text box.
     Each existing array entry becomes one record with its text exactly as stored. Nothing is split on hyphens,
     punctuation or line breaks. The original arrays are kept on the scenario (sc.migration) so nothing is lost,
     and an entry that itself contains a line break is flagged for the team to check rather than being split. */
  function listItem(prefix, text, extra) {
    return Object.assign({ id: U.uid(prefix), text: text == null ? '' : String(text) }, extra || {});
  }
  function convertList(arr, prefix, flags) {
    var out = [];
    (arr || []).forEach(function (v) {
      if (v && typeof v === 'object') { if (!v.id) v.id = U.uid(prefix); if (v.text == null) v.text = ''; out.push(v); return; }
      var t = v == null ? '' : String(v);
      if (!t.trim()) { flags.blanks++; return; }                       // empty lines from the old text box carry no content
      var item = listItem(prefix, t, { legacy: true });
      if (/[\r\n]/.test(t)) { item.review = 'Converted from an earlier version as one item. It contains a line break: check whether it should be split.'; flags.ambiguous = true; }
      out.push(item);
    });
    return out;
  }
  function needsConversion(arr) { return Array.isArray(arr) && arr.some(function (v) { return !v || typeof v !== 'object'; }); }
  function convertScenarioLists(sc) {
    var c = needsConversion(sc.causes), q = needsConversion(sc.consequences);
    if (!c && !q) return false;
    var flags = { blanks: 0, ambiguous: false };
    var orig = { causes: copy(sc.causes || []), consequences: copy(sc.consequences || []) };
    if (c) sc.causes = convertList(sc.causes, 'cau', flags);
    if (q) sc.consequences = convertList(sc.consequences, 'csq', flags);
    if (!sc.migration) sc.migration = { from: 'text lines (format 1 or 2)', at: new Date().toISOString(), original: orig, blankLinesDropped: flags.blanks, ambiguous: flags.ambiguous };
    return true;
  }

  /* Scenarios made before format 3 have no deviation review record. One record per node and deviation is created and
     marked as coming from the upgrade: the scenario's existence shows the team analysed it, but no explicit decision
     was recorded, so the record says so. */
  function linkLegacyDeviations(p) {
    var byKey = {};
    Object.keys(p.deviations).forEach(function (k) { var d = p.deviations[k]; byKey[devKey(d.nodeId, d.parameter, d.guideword, d.text)] = d; });
    Object.keys(p.scenarios).forEach(function (k) {
      var sc = p.scenarios[k];
      if (sc.deviationId && p.deviations[sc.deviationId]) return;
      var key = devKey(sc.nodeId, sc.parameter, sc.guideword, sc.deviation);
      var d = byKey[key];
      if (!d) {
        d = { id: U.uid('dev'), nodeId: sc.nodeId, parameter: sc.parameter || '', guideword: sc.guideword || '', text: sc.deviation || '',
              status: 'yes', reason: '', disposition: '', dispositionType: '', origin: 'upgrade', reviewedAt: null };
        p.deviations[d.id] = d; byKey[key] = d;
      }
      sc.deviationId = d.id;
    });
  }
  function devKey(nodeId, parameter, guideword, text) {
    return [nodeId || '', (parameter || '').toLowerCase(), (guideword || '').toLowerCase(), (text || '').trim().toLowerCase()].join('|');
  }

  /* Fill in anything a record is missing. Only ever adds; never removes or overwrites what is there. */
  function normalize(p) {
    ['drawings', 'nodes', 'equipment', 'scenarios', 'safeguards', 'recommendations', 'opParams', 'pst', 'deviations'].forEach(function (k) { p[k] = p[k] || {}; });
    // Project Quick-Add library (0.5.0): templates and the placeholder values the team has used.
    if (!p.library || typeof p.library !== 'object') p.library = { templates: [], values: {} };
    if (!Array.isArray(p.library.templates)) p.library.templates = [];
    if (!p.library.values || typeof p.library.values !== 'object') p.library.values = {};
    p.counters = p.counters || { node: 1, recommendation: 1 };
    p.sessions = p.sessions || [];
    var pr = p.project = p.project || {};
    // Repository fields (0.3.0). Optional additions: the file format number stays 2 and older files simply gain them.
    if (!pr.id) pr.id = U.uid('prj');
    if (pr.facility == null) pr.facility = '';
    if (pr.studyType == null) pr.studyType = '';
    if (!pr.method) pr.method = 'HAZOP';
    if (STATUS_KEYS.indexOf(pr.status) < 0) pr.status = 'draft';
    if (!pr.createdAt) pr.createdAt = new Date().toISOString();
    if (!pr.modifiedAt) pr.modifiedAt = pr.createdAt;
    pr.modules = pr.modules || {};
    Object.keys(DEFAULT_MODULES).forEach(function (k) { if (typeof pr.modules[k] !== 'boolean') pr.modules[k] = DEFAULT_MODULES[k]; });
    if (!Array.isArray(pr.measurementTypes)) pr.measurementTypes = ['Pressure', 'Temperature', 'Flow', 'Level'];
    if (!Array.isArray(pr.humanFactorPrompts)) pr.humanFactorPrompts = copy(DEFAULT_HF_PROMPTS);
    // Study information for the report (0.4.0). Blank means "not recorded" and the report says so.
    ['purpose', 'scope', 'objectives', 'exclusions', 'revision'].forEach(function (k) { if (pr[k] == null) pr[k] = ''; });
    if (!Array.isArray(pr.team)) pr.team = [];
    if (!Array.isArray(pr.assumptions)) pr.assumptions = [];
    var rm = pr.riskMatrix;
    if (rm) {
      // Existing projects ranked by severity x likelihood against score bands. That stays their rule unless the team changes it.
      if (rm.rule !== 'table' && rm.rule !== 'product') rm.rule = 'product';
      if (rm.rankBy !== 'consequence' && rm.rankBy !== 'scenario') rm.rankBy = 'scenario';
      if (!Array.isArray(rm.categories)) rm.categories = [];
      (rm.bands || []).forEach(function (b) { if (b.action == null) b.action = ''; });
    }
    Object.keys(p.deviations).forEach(function (k) {
      var d = p.deviations[k];
      if (['yes', 'no', 'not-reviewed'].indexOf(d.status) < 0) d.status = 'not-reviewed';
      ['parameter', 'guideword', 'text', 'reason', 'disposition'].forEach(function (f) { if (d[f] == null) d[f] = ''; });
      // 0.5.0: what kind of disposition an applicable deviation without a scenario has. 0.4.0's only disposition
      // field asked for "analysis recorded elsewhere", so existing disposition text is read as that.
      if (DISPOSITION_TYPES.indexOf(d.dispositionType) < 0) d.dispositionType = String(d.disposition || '').trim() ? 'covered-elsewhere' : '';
    });
    Object.keys(p.nodes).forEach(function (k) {
      var n = p.nodes[k];
      n.modules = n.modules || {};
      n.moduleStatus = n.moduleStatus || {};
      n.humanFactors = n.humanFactors || {};
      n.humanFactors.items = n.humanFactors.items || {};
      n.humanFactors.custom = n.humanFactors.custom || [];
      n.regions = n.regions || []; n.equipmentIds = n.equipmentIds || [];
    });
    Object.keys(p.scenarios).forEach(function (k) {
      var sc = p.scenarios[k];
      sc.risk = sc.risk || {};
      sc.risk.unmitigated = sc.risk.unmitigated || { s: '', l: '' };
      sc.risk.mitigated = sc.risk.mitigated || { s: '', l: '' };
      if (!sc.riskStatus) sc.riskStatus = { status: hasRisk(sc) ? 'applicable' : 'not-evaluated', reason: '' };
      sc.safeguardIds = sc.safeguardIds || []; sc.recommendationIds = sc.recommendationIds || [];
      sc.causes = sc.causes || []; sc.consequences = sc.consequences || [];
      convertScenarioLists(sc);
      sc.consequences.forEach(function (q) {
        if (!Array.isArray(q.causeIds)) q.causeIds = [];
        if (q.category == null) q.category = '';
        if (q.escalation == null) q.escalation = '';
        if (!q.risk) q.risk = blankRisk();
      });
      if (!sc.status) sc.status = 'open';
      sc.sequence = Object.assign(blankSequence(), sc.sequence || {});
    });
    // Scenario IDs for cards and reports. Assigned once, in the order the scenarios were recorded, and never renumbered.
    if (!p.counters.scenario) {
      var nextNo = 1;
      Object.keys(p.scenarios).forEach(function (k) { var m = /^S-(\d+)$/.exec(p.scenarios[k].displayId || ''); if (m) nextNo = Math.max(nextNo, +m[1] + 1); });
      p.counters.scenario = nextNo;
    }
    Object.keys(p.scenarios).forEach(function (k) {
      var sc = p.scenarios[k];
      if (!sc.displayId) sc.displayId = 'S-' + String(p.counters.scenario++).padStart(3, '0');
    });
    linkLegacyDeviations(p);
    Object.keys(p.safeguards).forEach(function (k) {
      var g = p.safeguards[k];
      g.evaluation = g.evaluation || {};
      var ev = g.evaluation;
      if (!ev.status) ev.status = 'not-evaluated';
      ev.criteria = ev.criteria || {};
      if (ev.credited == null) ev.credited = '';
      if (ev.notes == null) ev.notes = '';
      if (ev.reason == null) ev.reason = '';
      if (g.role == null) g.role = '';            // '' not stated | 'preventive' | 'mitigative'
    });
    return p;
  }

  /* Bring an older file up to the current schema, one small step per version.
     Migrations only add. Every record and every field from the older file is kept as it was. */
  function migrate(p) {
    if (!p || typeof p !== 'object' || !p.schemaVersion) throw new Error('This is not a PHA Workspace project file.');
    if (p.schemaVersion > SCHEMA_VERSION) {
      throw new Error('This project was saved by a newer version of the app (format ' + p.schemaVersion + '). Open it with that version.');
    }
    if (p.schemaVersion === 1) {
      // Format 2 adds configurable modules. A Phase 1 project opens looking the same: risk ranking on, new modules off.
      p.project = p.project || {};
      p.project.modules = copy(DEFAULT_MODULES);
      p.project.formatHistory = (p.project.formatHistory || []).concat([{ from: 1, to: 2, at: new Date().toISOString() }]);
      p.schemaVersion = 2;
    }
    if (p.schemaVersion === 2) {
      // Format 3 turns cause and consequence text lines into individual records and adds deviation review records.
      // The conversion itself is done by normalize(), which keeps the original text on each converted scenario.
      p.project = p.project || {};
      p.project.formatHistory = (p.project.formatHistory || []).concat([{ from: 2, to: 3, at: new Date().toISOString() }]);
      p.schemaVersion = 3;
    }
    return normalize(p);
  }

  /* A new, empty study with its own permanent id. */
  function makeProject(fields) {
    var p = normalize(blank());
    Object.keys(fields || {}).forEach(function (k) { if (fields[k] != null) p.project[k] = fields[k]; });
    return p;
  }

  function firstDrawingId(p) { var k = Object.keys(p.drawings); return k.length ? k[0] : null; }

  function newProject() {
    S.project = normalize(blank());
    S.files = new Map();
    resetHistory(); S.ui = { tab: 'scenarios', openParam: null, openPst: null };
    S.sel = { nodeId: null, scenarioId: null };
    S.drawingId = null;
    S.dirty = false; S.fileName = null; S.savedAt = null;
    emit('project');
  }

  function load(project, files, meta) {
    S.project = migrate(project);
    S.files = files || new Map();
    resetHistory(); S.ui = { tab: 'scenarios', openParam: null, openPst: null };
    S.sel = { nodeId: null, scenarioId: null };
    S.drawingId = firstDrawingId(S.project);
    S.dirty = !!(meta && meta.dirty);
    S.fileName = (meta && meta.fileName) || null;
    S.savedAt = (meta && meta.savedAt) || null;
    emit('project');
  }

  /* ---- undo / redo: whole-project snapshots. Projects are a few kilobytes of JSON, so this is cheap and exact. ---- */
  var undoStack = [], redoStack = [], lastSnap = { kind: null, t: 0 }, HISTORY_MAX = 100;
  function resetHistory() { undoStack = []; redoStack = []; lastSnap = { kind: null, t: 0 }; emit('history'); }
  function canUndo() { return undoStack.length > 0; }
  function canRedo() { return redoStack.length > 0; }

  function fixView() {
    var p = S.project;
    if (S.sel.nodeId && !p.nodes[S.sel.nodeId]) S.sel = { nodeId: null, scenarioId: null };
    if (S.sel.scenarioId && !p.scenarios[S.sel.scenarioId]) S.sel.scenarioId = null;
    if (S.drawingId && !p.drawings[S.drawingId]) S.drawingId = firstDrawingId(p);
    if (!S.drawingId) S.drawingId = firstDrawingId(p);
  }
  function step(from, to) {
    if (!from.length) return false;
    to.push(JSON.stringify(S.project));
    S.project = JSON.parse(from.pop());
    lastSnap = { kind: null, t: 0 };
    S.dirty = true; S.seq++;
    var before = S.drawingId;
    fixView();
    emit('restore', { drawingChanged: before !== S.drawingId });
    emit('history');
    return true;
  }
  function undo() { return step(undoStack, redoStack); }
  function redo() { return step(redoStack, undoStack); }

  /* Every edit goes through here. kind: 'struct' (records added/removed), 'field' (typing), 'geom' (dragging).
     A burst of typing or one drag is a single undo step. */
  function change(fn, kind) {
    kind = kind || 'struct';
    var now = Date.now();
    var sameBurst = kind !== 'struct' && lastSnap.kind === kind && now - lastSnap.t < 1200;
    if (!sameBurst) {
      undoStack.push(JSON.stringify(S.project));
      if (undoStack.length > HISTORY_MAX) undoStack.shift();
    }
    redoStack = [];
    lastSnap = { kind: kind, t: now };
    fn(S.project);
    S.project.project.modifiedAt = new Date().toISOString();
    S.dirty = true; S.seq++;
    emit('change', { kind: kind });
    emit('history');
  }

  function select(nodeId, scenarioId) {
    S.sel = { nodeId: nodeId || null, scenarioId: scenarioId || null };
    emit('select');
  }

  function setDrawing(id) {
    if (S.drawingId === id) return;
    S.drawingId = id;
    emit('drawing');
  }

  function markSaved(name) {
    S.dirty = false;
    if (name) S.fileName = name;
    S.savedAt = new Date();
    emit('saved');
  }

  /* ---- record helpers (call inside change()) ---- */

  function createNode(p) {
    var num = p.counters.node++;
    var n = {
      id: U.uid('nod'),
      displayId: 'N-' + String(num).padStart(2, '0'),
      name: '', designIntent: '',
      color: PALETTE[(num - 1) % PALETTE.length],
      status: 'not-started',
      regions: [], equipmentIds: [],
      modules: {}, moduleStatus: {}, humanFactors: { items: {}, custom: [] }
    };
    p.nodes[n.id] = n;
    return n;
  }

  /* A deviation review record: one per node and deviation, kept whether or not a scenario is ever made from it.
     status: 'not-reviewed' | 'yes' (applicable: analyse it) | 'no' (not applicable: reason required). */
  function createDeviation(p, nodeId, fields) {
    var d = { id: U.uid('dev'), nodeId: nodeId, parameter: '', guideword: '', text: '', status: 'not-reviewed',
              reason: '', disposition: '', dispositionType: '', origin: 'study', reviewedAt: null };
    Object.assign(d, fields || {});
    p.deviations[d.id] = d;
    return d;
  }
  function findDeviation(p, nodeId, parameter, guideword) {
    if (!parameter || !guideword) return null;
    return Object.keys(p.deviations).map(function (k) { return p.deviations[k]; }).filter(function (d) {
      return d.nodeId === nodeId && d.parameter === parameter && d.guideword === guideword;
    })[0] || null;
  }
  function deviationText(parameter, guideword) {
    if (!guideword && !parameter) return '';
    return ((guideword || '') + ' ' + (parameter || '').toLowerCase()).trim();
  }
  function deviationScenarios(p, devId) {
    return Object.keys(p.scenarios).map(function (k) { return p.scenarios[k]; }).filter(function (s) { return s.deviationId === devId; });
  }
  /* Change a deviation's parameter, guideword or wording. Every scenario made from it follows, so the two never disagree. */
  function setDeviationFields(p, d, patch) {
    Object.keys(patch).forEach(function (k) { d[k] = patch[k]; });
    deviationScenarios(p, d.id).forEach(function (s) {
      s.parameter = d.parameter; s.guideword = d.guideword; s.deviation = d.text;
      s.deviationAuto = d.text === deviationText(d.parameter, d.guideword);
    });
  }
  function nodeDeviations(p, nodeId) {
    return Object.keys(p.deviations).map(function (k) { return p.deviations[k]; }).filter(function (d) { return d.nodeId === nodeId; });
  }
  function removeDeviation(p, id) {
    if (deviationScenarios(p, id).length) return false;      // never orphan or delete scenarios through a deviation
    delete p.deviations[id];
    return true;
  }

  function createScenario(p, nodeId, deviationId) {
    var d = deviationId && p.deviations[deviationId];
    if (!d) d = createDeviation(p, nodeId, { status: 'yes' });     // a scenario added directly is an applicable deviation
    p.counters.scenario = p.counters.scenario || 1;
    var s = {
      id: U.uid('scn'), nodeId: nodeId, displayId: 'S-' + String(p.counters.scenario++).padStart(3, '0'),
      deviationId: d.id,
      parameter: d.parameter, guideword: d.guideword, deviation: d.text, deviationAuto: true,
      causes: [], consequences: [],
      safeguardIds: [], recommendationIds: [],
      risk: { unmitigated: { s: '', l: '' }, mitigated: { s: '', l: '' } },
      riskStatus: { status: 'not-evaluated', reason: '' },
      sequence: blankSequence(),
      notes: '', status: 'open'
    };
    p.scenarios[s.id] = s;
    return s;
  }

  /* Individual initiating causes and consequences. Each has a permanent id. */
  /* extra (optional): { teamStatus: 'pending', source: { kind: 'library', templateId, template, scope, at } } for Quick Add. */
  function addCause(sc, text, extra) { var c = listItem('cau', text, extra); sc.causes.push(c); return c; }
  function addConsequence(sc, text, extra) { var q = listItem('csq', text, Object.assign({ causeIds: [], category: '', escalation: '', risk: blankRisk() }, extra || {})); sc.consequences.push(q); return q; }
  function removeCause(sc, id) {
    sc.causes = sc.causes.filter(function (c) { return c.id !== id; });
    sc.consequences.forEach(function (q) { q.causeIds = (q.causeIds || []).filter(function (x) { return x !== id; }); });
  }
  function removeConsequence(sc, id) { sc.consequences = sc.consequences.filter(function (q) { return q.id !== id; }); }
  function moveItem(list, id, dir) {
    var i = list.map(function (x) { return x.id; }).indexOf(id), j = i + dir;
    if (i < 0 || j < 0 || j >= list.length) return;
    var t = list[i]; list[i] = list[j]; list[j] = t;
  }
  /* When one cause leads to materially different consequences or safeguards, it gets its own scenario under the same
     deviation. Consequences linked only to that cause go with it; everything else stays. */
  function splitCause(p, sc, causeId) {
    var cause = sc.causes.filter(function (c) { return c.id === causeId; })[0];
    if (!cause) return null;
    var ns = createScenario(p, sc.nodeId, sc.deviationId);
    ns.causes.push(cause);
    sc.causes = sc.causes.filter(function (c) { return c.id !== causeId; });
    var keep = [];
    sc.consequences.forEach(function (q) {
      var ids = q.causeIds || [];
      if (ids.length && ids.every(function (x) { return x === causeId; })) ns.consequences.push(q);
      else { q.causeIds = ids.filter(function (x) { return x !== causeId; }); keep.push(q); }
    });
    sc.consequences = keep;
    return ns;
  }
  /* Associate an existing safeguard record with another scenario (it stays one record). */
  function attachSafeguard(sc, id) { if (sc.safeguardIds.indexOf(id) < 0) sc.safeguardIds.push(id); }
  function safeguardUse(p, id) {
    return Object.keys(p.scenarios).filter(function (k) { return p.scenarios[k].safeguardIds.indexOf(id) >= 0; }).length;
  }

  function createSafeguard(p, sc) {
    var g = { id: U.uid('sfg'), description: '', type: '', role: '', equipmentId: null,
              evaluation: { status: 'not-evaluated', reason: '', criteria: {}, credited: '', notes: '' } };
    p.safeguards[g.id] = g;
    sc.safeguardIds.push(g.id);
    return g;
  }

  function createRecommendation(p, sc) {
    var num = p.counters.recommendation++;
    var r = { id: U.uid('rec'), displayId: 'R-' + String(num).padStart(3, '0'), text: '', assignee: '', due: '', status: 'open' };
    p.recommendations[r.id] = r;
    sc.recommendationIds.push(r.id);
    return r;
  }

  /* An operating parameter starts with every value blank. The app never supplies an engineering value. */
  function createOpParam(p, nodeId) {
    var o = {
      id: U.uid('opp'), nodeId: nodeId, measurement: '', name: '', unit: '', tag: '', drawingId: null,
      values: { designMin: '', safeMin: '', tripLow: '', alarmLow: '', normalMin: '', normalMax: '', alarmHigh: '', tripHigh: '', safeMax: '', designMax: '' },
      source: '', notes: ''
    };
    p.opParams[o.id] = o;
    return o;
  }

  function createPst(p, nodeId) {
    var t = {
      id: U.uid('pst'), nodeId: nodeId, scenarioId: null, safeguardId: null, title: '', unit: 's', responseBy: '',
      times: { hazard: '', detect: '', activate: '', response: '', action: '' },
      basis: '', conclusion: '', notes: ''
    };
    p.pst[t.id] = t;
    return t;
  }

  function byNode(coll, nodeId) {
    return Object.keys(coll).map(function (k) { return coll[k]; }).filter(function (r) { return r.nodeId === nodeId; });
  }
  function unlinkSafeguard(p, id) {
    Object.keys(p.pst).forEach(function (k) { if (p.pst[k].safeguardId === id) p.pst[k].safeguardId = null; });
  }
  function removeSafeguard(p, sc, id) {
    sc.safeguardIds = sc.safeguardIds.filter(function (x) { return x !== id; });
    if (!isReferenced(p, 'safeguardIds', id)) { delete p.safeguards[id]; unlinkSafeguard(p, id); }
  }

  function isReferenced(p, key, id) {
    return Object.keys(p.scenarios).some(function (k) { return p.scenarios[k][key].indexOf(id) >= 0; });
  }

  function removeScenario(p, id) {
    var sc = p.scenarios[id];
    if (!sc) return;
    delete p.scenarios[id];
    // Safety time analyses and human factor notes that pointed at this scenario are kept, just unlinked.
    Object.keys(p.pst).forEach(function (k) { if (p.pst[k].scenarioId === id) p.pst[k].scenarioId = null; });
    Object.keys(p.nodes).forEach(function (k) {
      var items = (p.nodes[k].humanFactors && p.nodes[k].humanFactors.items) || {};
      Object.keys(items).forEach(function (i) { if (items[i].scenarioId === id) items[i].scenarioId = null; });
    });
    sc.safeguardIds.forEach(function (g) { if (!isReferenced(p, 'safeguardIds', g)) { delete p.safeguards[g]; unlinkSafeguard(p, g); } });
    sc.recommendationIds.forEach(function (r) { if (!isReferenced(p, 'recommendationIds', r)) delete p.recommendations[r]; });
  }

  function removeNode(p, id) {
    var n = p.nodes[id];
    if (!n) return;
    nodeScenarios(p, id).forEach(function (sc) { removeScenario(p, sc.id); });
    n.equipmentIds.forEach(function (e) { delete p.equipment[e]; });
    byNode(p.opParams, id).forEach(function (o) { delete p.opParams[o.id]; });
    byNode(p.pst, id).forEach(function (t) { delete p.pst[t.id]; });
    nodeDeviations(p, id).forEach(function (d) { delete p.deviations[d.id]; });
    delete p.nodes[id];
  }

  function removeDrawing(p, id) {
    var d = p.drawings[id];
    if (!d) return;
    delete p.drawings[id];
    Object.keys(p.nodes).forEach(function (k) {
      p.nodes[k].regions = p.nodes[k].regions.filter(function (r) { return r.drawingId !== id; });
    });
    Object.keys(p.opParams).forEach(function (k) { if (p.opParams[k].drawingId === id) p.opParams[k].drawingId = null; });
    // The PDF bytes stay in memory for this session so Undo can bring the drawing back. Unused files are not saved.
  }

  function nodeScenarios(p, nodeId) {
    return Object.keys(p.scenarios).map(function (k) { return p.scenarios[k]; })
      .filter(function (s) { return s.nodeId === nodeId; });
  }

  /* Risk ranking from the project's configured matrix.
       rule 'product' (the rule every project before 0.4.0 used): score = severity value x likelihood value,
                      ranked against the bands' lowest scores. Only valid when the matrix values are numbers.
       rule 'table':  each severity / likelihood cell is assigned a band directly; no arithmetic is done.
     Returns { score (null for a table), label, color, action, rank (0 = the highest band) } or null if not ranked. */
  function riskOf(p, r) {
    if (!r || !r.s || !r.l) return null;
    var m = p.project.riskMatrix, bands = m.bands || [];
    if (m.rule === 'table') {
      var si = m.severity.map(function (o) { return o.v; }).indexOf(r.s), li = m.likelihood.map(function (o) { return o.v; }).indexOf(r.l);
      var bi = (m.cells && m.cells[li] && si >= 0) ? m.cells[li][si] : null;
      if (si < 0 || li < 0 || bi == null || !bands[bi]) return { score: null, label: 'Unassigned', color: '#666', action: '', rank: bands.length };
      return { score: null, label: bands[bi].label, color: bands[bi].color, action: bands[bi].action || '', rank: bi };
    }
    var score = Number(r.s) * Number(r.l);
    var sorted = bands.slice().sort(function (a, b) { return b.min - a.min; });
    for (var i = 0; i < sorted.length; i++) if (score >= sorted[i].min) return { score: score, label: sorted[i].label, color: sorted[i].color, action: sorted[i].action || '', rank: i };
    return { score: score, label: '', color: '#666', action: '', rank: sorted.length };
  }
  /* Build a cell table that gives exactly the rankings the score rule gives now, so switching rule changes nothing until edited. */
  function tableFromProduct(p) {
    var m = p.project.riskMatrix, sorted = m.bands.slice().sort(function (a, b) { return b.min - a.min; });
    return m.likelihood.map(function (l) {
      return m.severity.map(function (s) {
        var k = riskOf({ project: { riskMatrix: Object.assign({}, m, { rule: 'product' }) } }, { s: s.v, l: l.v });
        return k && sorted[k.rank] ? m.bands.indexOf(sorted[k.rank]) : null;
      });
    });
  }
  /* The ranking shown for a scenario. With per-consequence ranking the worst ranked consequence is shown; the
     individual rankings stay on each consequence and are never overwritten. which: 'unmitigated' | 'mitigated'. */
  function scenarioRisk(p, sc, which) {
    var m = p.project.riskMatrix;
    if (m.rankBy !== 'consequence') return riskOf(p, sc.risk[which]);
    var worst = null;
    sc.consequences.forEach(function (q) {
      var k = q.risk && riskOf(p, q.risk[which]);
      if (k && (!worst || k.rank < worst.rank || (k.rank === worst.rank && (k.score || 0) > (worst.score || 0)))) worst = k;
    });
    return worst;
  }

  PHA.store = {
    S: S, on: on, PALETTE: PALETTE, SCHEMA_VERSION: SCHEMA_VERSION, APP_VERSION: APP_VERSION,
    undo: undo, redo: redo, canUndo: canUndo, canRedo: canRedo, normalize: normalize, makeProject: makeProject, PROJECT_STATUSES: PROJECT_STATUSES,
    createOpParam: createOpParam, createPst: createPst, removeSafeguard: removeSafeguard, byNode: byNode,
    newProject: newProject, load: load, migrate: migrate, change: change, select: select,
    setDrawing: setDrawing, markSaved: markSaved,
    createNode: createNode, createScenario: createScenario, createSafeguard: createSafeguard,
    createRecommendation: createRecommendation, removeScenario: removeScenario, removeNode: removeNode,
    removeDrawing: removeDrawing, nodeScenarios: nodeScenarios, riskOf: riskOf,
    // 0.4.0
    createDeviation: createDeviation, findDeviation: findDeviation, deviationText: deviationText, deviationScenarios: deviationScenarios,
    setDeviationFields: setDeviationFields, nodeDeviations: nodeDeviations, removeDeviation: removeDeviation,
    addCause: addCause, addConsequence: addConsequence, removeCause: removeCause, removeConsequence: removeConsequence,
    moveItem: moveItem, splitCause: splitCause, attachSafeguard: attachSafeguard, safeguardUse: safeguardUse,
    tableFromProduct: tableFromProduct, scenarioRisk: scenarioRisk, blankRisk: blankRisk, blankSequence: blankSequence, DISPOSITION_TYPES: DISPOSITION_TYPES,
    SCENARIO_STATUSES: [['open', 'Draft'], ['verify', 'Pending verification'], ['reviewed', 'Reviewed']]
  };
})();
