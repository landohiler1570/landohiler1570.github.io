/* modules.js: configurable analysis modules.
   - Project defaults and per-node overrides decide what is SHOWN. Turning a module off never deletes data.
   - Each node records, per module, whether it is Not evaluated, Applicable or Not applicable.
   - Also holds the scenario-level pieces: risk ranking block and safeguard evaluation. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, C = PHA.calc;
  var tabs = {};      // module key -> { count(p, n), render(p, n) }, registered by opparams.js, pst.js, humanfactors.js

  function register(key, impl) { tabs[key] = impl; }
  function def(key) { return C.MODULES.filter(function (m) { return m.key === key; })[0]; }
  function enabled(p, n, key) { return C.moduleEnabled(p, n, key); }

  /* Three-way choice used everywhere a status is recorded. */
  function triState(value, onChange) {
    var wrap = el('div', { 'class': 'tri', role: 'group' });
    function paint(v) {
      wrap.dataset.v = v;
      Array.prototype.forEach.call(wrap.children, function (b) {
        b.classList.toggle('on', b.dataset.v === v);
        b.setAttribute('aria-pressed', b.dataset.v === v ? 'true' : 'false');
      });
    }
    C.STATUSES.forEach(function (s) {
      wrap.appendChild(el('button', { type: 'button', 'data-v': s[0], onclick: function () {
        if (wrap.dataset.v === s[0]) return;
        paint(s[0]); onChange(s[0]);
      } }, s[1]));
    });
    paint(value || 'not-evaluated');
    wrap.setValue = paint;
    return wrap;
  }

  function nodeStatus(n, key) {
    n.moduleStatus[key] = n.moduleStatus[key] || { status: 'not-evaluated', reason: '' };
    return n.moduleStatus[key];
  }
  /* Recording data means the module has been looked at. Call inside store.change(). */
  function markApplicable(n, key) {
    var st = nodeStatus(n, key);
    if (st.status === 'not-evaluated') st.status = 'applicable';
  }

  /* How much data a node holds for a module, whether or not the module is switched on. */
  function dataCount(p, n, key) {
    if (key === 'operatingParameters') return store.byNode(p.opParams, n.id).length;
    if (key === 'processSafetyTime') return store.byNode(p.pst, n.id).length;
    if (key === 'humanFactors') {
      var items = n.humanFactors.items;
      return Object.keys(items).filter(function (k) { return items[k].status && items[k].status !== 'not-evaluated' || items[k].notes; }).length;
    }
    var scs = store.nodeScenarios(p, n.id);
    if (key === 'riskMatrix') {
      return scs.filter(function (sc) {
        var r = sc.risk;
        return r.unmitigated.s || r.unmitigated.l || r.mitigated.s || r.mitigated.l || sc.riskStatus.status !== 'not-evaluated';
      }).length;
    }
    if (key === 'safeguardEvaluation') {
      var c = 0;
      scs.forEach(function (sc) {
        sc.safeguardIds.forEach(function (id) {
          var g = p.safeguards[id];
          if (g && (g.type || g.evaluation.status !== 'not-evaluated' || g.evaluation.notes || Object.keys(g.evaluation.criteria).length)) c++;
        });
      });
      return c;
    }
    return 0;
  }

  /* ---------- node tabs ---------- */

  function tabList(p, n) {
    var list = [{ key: 'scenarios', label: 'Scenarios', count: store.nodeScenarios(p, n.id).length }];
    C.MODULES.forEach(function (m) {
      if (m.tab && tabs[m.key] && enabled(p, n, m.key)) list.push({ key: m.key, label: m.tab, count: tabs[m.key].count(p, n), status: C.moduleStatus(n, m.key) });
    });
    return list;
  }

  function tabBar(p, n) {
    var list = tabList(p, n), ui = store.S.ui;
    if (!list.some(function (t) { return t.key === ui.tab; })) ui.tab = 'scenarios';
    if (list.length === 1) return { el: null, active: 'scenarios' };
    var bar = el('div', { 'class': 'tabs', role: 'tablist' });
    list.forEach(function (t) {
      bar.appendChild(el('button', {
        'class': 'tab' + (t.key === ui.tab ? ' on' : '') + (t.status === 'not-applicable' ? ' na' : ''), role: 'tab', 'data-tab': t.key,
        onclick: function () { ui.tab = t.key; PHA.panel.render(); }
      }, t.label, t.status === 'not-applicable' ? el('span', { 'class': 'tab-count' }, 'N/A') : el('span', { 'class': 'tab-count' }, String(t.count))));
    });
    return { el: bar, active: ui.tab };
  }

  function renderTab(key, p, n) {
    var m = def(key), impl = tabs[key], st = nodeStatus(n, key);
    var sec = el('div', { 'class': 'module' });
    sec.appendChild(el('div', { 'class': 'status-bar' },
      el('span', { 'class': 'flabel' }, m.label + ' for this node'),
      triState(st.status, function (v) { store.change(function () { nodeStatus(n, key).status = v; }); })));
    if (st.status === 'not-applicable') {
      var kept = dataCount(p, n, key);
      sec.appendChild(PHA.ui.field('Why this does not apply to the node', PHA.ui.text(st.reason, function (v) { nodeStatus(n, key).reason = v; },
        { placeholder: 'Reason recorded with the study' })));
      if (kept) sec.appendChild(el('div', { 'class': 'muted pad' }, kept + ' record(s) entered earlier are kept and will show again if this is set back to Applicable.'));
      return sec;
    }
    if (st.status === 'not-evaluated') {
      sec.appendChild(el('div', { 'class': 'muted pad' }, 'Not evaluated yet. Adding a record marks it Applicable; choose Not applicable if the team decides it does not apply.'));
    }
    sec.appendChild(impl.render(p, n));
    return sec;
  }

  /* Tells the facilitator when a node holds data in a module that is currently switched off. */
  function hiddenNote(p, n) {
    var lines = [];
    C.MODULES.forEach(function (m) {
      if (enabled(p, n, m.key)) return;
      var c = dataCount(p, n, m.key);
      if (c) lines.push(m.label + ': ' + c + ' record(s)');
    });
    if (!lines.length) return null;
    return el('div', { 'class': 'hidden-note' },
      el('b', null, 'Kept but hidden (module off): '), lines.join('; ') + '. ',
      el('button', { onclick: function () { openConfig(); } }, 'Modules'));
  }

  /* ---------- risk ranking (scenario level) ---------- */

  /* marks: { u: {s,l}, m: {s,l} } to show where a scenario sits. onCell(si, li): makes cells clickable (table editing). */
  function matrixGrid(p, marks, onCell) {
    var m = p.project.riskMatrix, sev = m.severity, lik = m.likelihood;
    var g = el('div', { 'class': 'mgrid' + (onCell ? ' editable' : ''), style: { gridTemplateColumns: 'auto repeat(' + sev.length + ', 1fr)' } });
    for (var li = lik.length - 1; li >= 0; li--) {
      g.appendChild(el('div', { 'class': 'mhead', title: 'Likelihood: ' + lik[li].label }, lik[li].v));
      for (var si = 0; si < sev.length; si++) {
        var k = store.riskOf(p, { s: sev[si].v, l: lik[li].v });
        var shown = k.score != null ? String(k.score) : (k.label || '?').slice(0, 1);
        var cell = el(onCell ? 'button' : 'div', { 'class': 'mcell', style: { background: k.color }, title: sev[si].label + ' x ' + lik[li].label + ' = ' + k.label + (k.score != null ? ' ' + k.score : '') }, shown);
        if (onCell) (function (a, b) { cell.addEventListener('click', function () { onCell(a, b); }); })(si, li);
        if (marks) {
          var tags = '';
          if (marks.u && marks.u.s === sev[si].v && marks.u.l === lik[li].v) tags += '○';
          if (marks.m && marks.m.s === sev[si].v && marks.m.l === lik[li].v) tags += '●';
          if (tags) { cell.textContent = tags; cell.classList.add('marked'); }
        }
        g.appendChild(cell);
      }
    }
    g.appendChild(el('div', { 'class': 'mhead' }, ''));
    sev.forEach(function (s) { g.appendChild(el('div', { 'class': 'mhead', title: 'Severity: ' + s.label }, s.v)); });
    return g;
  }

  /* The risk-reduction requirement the matrix attaches to a band, if the team has entered one. */
  function actionLine(p, k) {
    if (!k || !String(k.action || '').trim()) return null;
    return el('div', { 'class': 'band-action', style: { borderLeftColor: k.color } }, el('b', null, k.label + ': '), k.action);
  }

  function riskBlock(p, n, sc, onChange) {
    if (!enabled(p, n, 'riskMatrix')) return null;
    var st = sc.riskStatus, rm = p.project.riskMatrix;
    var tri = triState(st.status, function (v) { store.change(function () { sc.riskStatus.status = v; }); });
    var box = el('div', { 'class': 'list riskblock' }, el('div', { 'class': 'list-head' }, el('span', { 'class': 'flabel' }, 'Risk ranking'), tri));
    if (st.status === 'not-applicable') {
      box.appendChild(PHA.ui.text(st.reason, function (v) { sc.riskStatus.reason = v; }, { placeholder: 'Why a risk ranking does not apply to this scenario' }));
      return box;
    }
    var holder = el('div', { 'class': 'mholder' }), actions = el('div', { 'class': 'band-actions' }), overall = el('div', { 'class': 'risk-overall' });
    function paint() {
      holder.textContent = '';
      var u = store.scenarioRisk(p, sc, 'unmitigated'), m = store.scenarioRisk(p, sc, 'mitigated');
      if (rm.rankBy !== 'consequence') holder.appendChild(matrixGrid(p, { u: sc.risk.unmitigated, m: sc.risk.mitigated }));
      else holder.appendChild(matrixGrid(p));
      holder.appendChild(el('div', { 'class': 'muted mlegend' }, rm.rankBy !== 'consequence' ? '○ without safeguards   ● with safeguards' : 'Matrix for reference'));
      overall.textContent = '';
      if (rm.rankBy === 'consequence') {
        overall.appendChild(el('span', { 'class': 'muted' }, 'Highest ranked consequence: '));
        overall.appendChild(PHA.ui.riskBadge(p, null, true, u)); overall.appendChild(document.createTextNode(' → '));
        overall.appendChild(PHA.ui.riskBadge(p, null, true, m));
      }
      actions.textContent = '';
      var seen = {};
      [u, m].forEach(function (k) { if (k && !seen[k.label]) { seen[k.label] = 1; var a = actionLine(p, k); if (a) actions.appendChild(a); } });
    }
    function touched() {
      if (sc.riskStatus.status === 'not-evaluated') {
        store.change(function () { sc.riskStatus.status = 'applicable'; }, 'field');
        tri.setValue('applicable');
      }
      paint();
      if (onChange) onChange();
    }
    var rows = el('div', { 'class': 'risk-rows' });
    if (rm.rankBy === 'consequence') {
      var list = sc.consequences.filter(function (q) { return String(q.text || '').trim(); });
      if (!list.length) rows.appendChild(el('div', { 'class': 'muted' }, 'This study ranks each consequence separately. Record a consequence first.'));
      list.forEach(function (q, i) {
        var cat = rm.categories.length ? PHA.ui.select(q.category, rm.categories, function (e) { var v = e.target.value; store.change(function () { q.category = v; }, 'field'); }, 'Category') : null;
        rows.appendChild(el('div', { 'class': 'csq-risk' },
          el('div', { 'class': 'csq-risk-head' }, el('b', null, 'Consequence ' + (i + 1) + ': '), el('span', null, q.text), cat),
          PHA.ui.riskRow(p, 'Without safeguards', q.risk.unmitigated, touched),
          PHA.ui.riskRow(p, 'With safeguards', q.risk.mitigated, touched)));
      });
    } else {
      rows.appendChild(PHA.ui.riskRow(p, 'Without safeguards', sc.risk.unmitigated, touched));
      rows.appendChild(PHA.ui.riskRow(p, 'With safeguards', sc.risk.mitigated, touched));
    }
    rows.appendChild(overall);
    rows.appendChild(actions);
    paint();
    box.appendChild(el('div', { 'class': 'risk-wrap' }, rows, holder));
    return box;
  }

  /* ---------- safeguard evaluation (per safeguard, inside a scenario) ---------- */

  function sfgEval(p, n, sc, g) {
    if (!enabled(p, n, 'safeguardEvaluation')) return null;
    var ev = g.evaluation;
    var box = el('div', { 'class': 'sfg-eval' });
    box.appendChild(el('div', { 'class': 'list-row' },
      PHA.ui.select(g.type, C.SFG_TYPES, function (e) { var v = e.target.value; store.change(function () { g.type = v; }, 'field'); }, 'Safeguard type'),
      triState(ev.status, function (v) { store.change(function () { ev.status = v; }); })));
    if (ev.status === 'not-applicable') {
      box.appendChild(PHA.ui.text(ev.reason, function (v) { ev.reason = v; }, { placeholder: 'Why an evaluation does not apply to this safeguard' }));
      return box;
    }
    if (ev.status !== 'applicable') return box;

    var tally = el('div', { 'class': 'muted' });
    function paintTally() {
      var t = C.criteriaTally(ev);
      tally.textContent = 'Answers recorded: ' + t.yes + ' yes, ' + t.no + ' no, ' + t.open + ' not answered. This is a record of the team\'s answers, not a calculated result.';
    }
    C.SFG_CRITERIA.forEach(function (c) {
      box.appendChild(el('div', { 'class': 'crit' }, el('span', null, c.label),
        PHA.ui.select(ev.criteria[c.key], [['yes', 'Yes'], ['no', 'No']], function (e) {
          var v = e.target.value;
          store.change(function () { if (v) ev.criteria[c.key] = v; else delete ev.criteria[c.key]; }, 'field');
          paintTally();
        }, 'Not answered')));
    });
    if (enabled(p, n, 'processSafetyTime')) {
      var linked = Object.keys(p.pst).map(function (k) { return p.pst[k]; }).filter(function (t) { return t.safeguardId === g.id; });
      box.appendChild(el('div', { 'class': 'crit' }, el('span', null, 'Response time'),
        el('span', { 'class': 'muted' }, linked.length
          ? linked.map(function (t) { return PHA.pst.summary(t); }).join(' | ')
          : 'No safety time analysis is linked to this safeguard.')));
    }
    box.appendChild(el('div', { 'class': 'crit' }, el('span', null, 'Team decision on taking credit'),
      PHA.ui.select(ev.credited, [['yes', 'Credited'], ['no', 'Not credited']], function (e) {
        var v = e.target.value; store.change(function () { ev.credited = v; }, 'field');
      }, 'Not decided')));
    box.appendChild(PHA.ui.area(ev.notes, function (v) { ev.notes = v; }, { placeholder: 'Evaluation notes, test intervals, references', rows: 1 }));
    paintTally();
    box.appendChild(tally);
    return box;
  }

  /* ---------- configuration dialog ---------- */

  function effective(p, key) { return p.project.modules[key] ? 'On' : 'Off'; }

  function renderConfig() {
    var dlg = document.getElementById('config'), S = store.S, p = S.project;
    if (!dlg || !p) return;
    var top = dlg.scrollTop, openDetails = {};
    Array.prototype.forEach.call(dlg.querySelectorAll('details'), function (d) { openDetails[d.dataset.k] = d.open; });
    dlg.textContent = '';
    dlg.appendChild(el('h2', null, 'Modules'));
    dlg.appendChild(el('p', { 'class': 'muted' }, 'Choose which analysis tools are shown. Turning a module off only hides it: everything already recorded is kept in the project and returns when the module is turned back on.'));

    dlg.appendChild(el('h3', null, 'Project defaults'));
    var list = el('div', { 'class': 'modlist' });
    C.MODULES.forEach(function (m) {
      list.appendChild(el('label', { 'class': 'modrow' },
        el('input', { type: 'checkbox', checked: p.project.modules[m.key] ? true : null, 'data-mod': m.key, onchange: function (e) {
          var v = e.target.checked; store.change(function (proj) { proj.project.modules[m.key] = v; });
        } }),
        el('div', null, el('b', null, m.label), el('div', { 'class': 'muted' }, m.desc))));
    });
    dlg.appendChild(list);

    var n = p.nodes[S.sel.nodeId];
    dlg.appendChild(el('h3', null, n ? 'Override for node ' + n.displayId + (n.name ? ' - ' + n.name : '') : 'Node override'));
    if (!n) dlg.appendChild(el('p', { 'class': 'muted' }, 'Select a node first to give it its own settings.'));
    else {
      var ov = el('div', { 'class': 'modlist' });
      C.MODULES.forEach(function (m) {
        var c = dataCount(p, n, m.key);
        ov.appendChild(el('div', { 'class': 'modrow ov' },
          el('div', null, el('b', null, m.label), c ? el('span', { 'class': 'muted' }, '  ' + c + ' record(s) on this node') : null),
          PHA.ui.select(n.modules[m.key] || '', [['on', 'On for this node'], ['off', 'Off for this node']], function (e) {
            var v = e.target.value;
            store.change(function () { if (v) n.modules[m.key] = v; else delete n.modules[m.key]; });
          }, 'Use project default (' + effective(p, m.key) + ')')));
      });
      dlg.appendChild(ov);
    }

    /* risk matrix settings */
    var rm = p.project.riskMatrix;
    var det = el('details', { 'data-k': 'rm' }, el('summary', null, 'Risk matrix settings'));
    if (openDetails.rm) det.open = true;
    var prev = el('div', { 'class': 'mholder wide' });
    function paintPrev() {
      prev.textContent = '';
      prev.appendChild(matrixGrid(p, null, rm.rule === 'table' ? function (si, li) {
        store.change(function (proj) {
          var m2 = proj.project.riskMatrix, cur = m2.cells[li][si];
          m2.cells[li][si] = cur == null ? 0 : (cur + 1 < m2.bands.length ? cur + 1 : null);
        });
        paintPrev();
      } : null));
    }
    paintPrev();
    det.appendChild(PHA.ui.field('Matrix source or reference', PHA.ui.text(rm.source || '', function (v) { rm.source = v; }, { placeholder: 'e.g. corporate risk standard and revision' })));
    det.appendChild(el('div', { 'class': 'row two' },
      PHA.ui.field('How a ranking is found', PHA.ui.select(rm.rule, [['product', 'Score = severity value x likelihood value, against band thresholds'], ['table', 'Cell table: each cell is assigned a band']], function (e) {
        var v = e.target.value || 'product';
        store.change(function (proj) {
          var m2 = proj.project.riskMatrix;
          if (v === 'table' && !m2.cells) m2.cells = store.tableFromProduct(proj);     // same rankings as before until cells are edited
          m2.rule = v;
        });
      }, 'Rule')),
      PHA.ui.field('What is ranked', PHA.ui.select(rm.rankBy, [['scenario', 'One ranking per scenario'], ['consequence', 'Each consequence ranked separately']], function (e) {
        var v = e.target.value || 'scenario';
        store.change(function (proj) { proj.project.riskMatrix.rankBy = v; });
      }, 'Ranking'))));
    det.appendChild(el('p', { 'class': 'muted' }, rm.rule === 'table'
      ? 'Cell table: click a cell in the preview to change its band. No arithmetic is done.'
      : 'Score rule: the severity and likelihood values are multiplied and compared with each band\'s lowest score. Use the cell table if the site matrix is not a simple product.'));
    det.appendChild(PHA.ui.field('Consequence categories (comma separated, optional, e.g. Safety, Environment, Asset)', PHA.ui.text(rm.categories.join(', '), function (v) {
      rm.categories = v.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
    })));
    var cols = el('div', { 'class': 'row two' });
    function labelList(title, arr) {
      var box = el('div', { 'class': 'field' }, el('span', { 'class': 'flabel' }, title));
      arr.forEach(function (o) { box.appendChild(PHA.ui.text(o.label, function (v) { o.label = v; })); });
      return box;
    }
    cols.appendChild(labelList('Severity labels (low to high)', rm.severity));
    cols.appendChild(labelList('Likelihood labels (low to high)', rm.likelihood));
    det.appendChild(cols);
    var bands = el('div', { 'class': 'field' }, el('span', { 'class': 'flabel' }, rm.rule === 'table' ? 'Risk bands: name and risk-reduction requirement' : 'Risk bands: name, lowest score and risk-reduction requirement'));
    rm.bands.forEach(function (b) {
      bands.appendChild(el('div', { 'class': 'list-row' },
        el('span', { 'class': 'dot', style: { background: b.color, width: '16px', height: '16px', borderRadius: '4px', flex: '0 0 auto' } }),
        PHA.ui.text(b.label, function (v) { b.label = v; }, { 'class': 'w-band' }),
        rm.rule === 'table' ? null : el('input', { type: 'text', inputmode: 'numeric', 'class': 'short', value: String(b.min), oninput: function (e) {
          var v = C.num(e.target.value);
          e.target.classList.toggle('invalid', !C.isNum(v) || v < 1);
          if (C.isNum(v) && v >= 1) { store.change(function () { b.min = v; }, 'field'); paintPrev(); }
        } }),
        PHA.ui.text(b.action || '', function (v) { b.action = v; }, { placeholder: 'Required action, e.g. further risk reduction required' })));
    });
    det.appendChild(bands);
    det.appendChild(prev);
    dlg.appendChild(det);

    var det2 = el('details', { 'data-k': 'mt' }, el('summary', null, 'Measurement types for operating parameters'));
    if (openDetails.mt) det2.open = true;
    det2.appendChild(PHA.ui.field('Comma separated. Any other measurement can still be typed on a parameter.',
      PHA.ui.text(p.project.measurementTypes.join(', '), function (v, proj) {
        proj.project.measurementTypes = v.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
      })));
    dlg.appendChild(det2);

    dlg.appendChild(el('div', { 'class': 'row end' }, el('button', { 'class': 'primary', id: 'btnConfigClose', onclick: function () { dlg.close ? dlg.close() : dlg.removeAttribute('open'); } }, 'Done')));
    dlg.scrollTop = top;
  }

  function openConfig() {
    var dlg = document.getElementById('config');
    renderConfig();
    if (!dlg.open) { if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', ''); }
  }
  function refreshConfig(kind) {
    var dlg = document.getElementById('config');
    if (dlg && dlg.open && kind !== 'field') renderConfig();
  }

  PHA.modules = {
    register: register, enabled: enabled, triState: triState, markApplicable: markApplicable, dataCount: dataCount,
    tabBar: tabBar, renderTab: renderTab, hiddenNote: hiddenNote, riskBlock: riskBlock, sfgEval: sfgEval, actionLine: actionLine,
    matrixGrid: matrixGrid, openConfig: openConfig, refreshConfig: refreshConfig
  };
})();
