/* panel.js: the left-hand analysis panel. Node list, node details and HAZOP scenarios as cards
   instead of spreadsheet columns. Typing writes straight to the store without redrawing the panel. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store;

  var root, focusKey = null;
  var STATUS = [['not-started', 'Not started'], ['in-progress', 'In progress'], ['complete', 'Complete']];

  function field(label, control, cls) {
    return el('label', { 'class': 'field' + (cls ? ' ' + cls : '') }, el('span', { 'class': 'flabel' }, label), control);
  }
  function setField(fn) { return function (e) { var v = e.target.value; store.change(function (p) { fn(v, p); }, 'field'); }; }
  function text(value, fn, attrs) {
    return el('input', Object.assign({ type: 'text', value: value || '', oninput: setField(fn) }, attrs || {}));
  }
  function area(value, fn, attrs) {
    var t = el('textarea', Object.assign({ rows: 2, oninput: function (e) { grow(e.target); setField(fn)(e); } }, attrs || {}));
    t.value = value || '';
    setTimeout(function () { grow(t); }, 0);
    return t;
  }
  function grow(t) { t.style.height = 'auto'; t.style.height = Math.min(400, t.scrollHeight + 2) + 'px'; }
  function select(value, options, fn, placeholder) {
    var opts = [el('option', { value: '' }, placeholder || '-')].concat(options.map(function (o) {
      return Array.isArray(o) ? el('option', { value: o[0] }, o[1]) : el('option', { value: o }, o);
    }));
    return el('select', { value: value || '', onchange: fn }, opts);
  }

  /* k: an already-computed ranking (optional). Table matrices have no score, so only the band is shown. */
  function riskBadge(p, r, small, k) {
    if (k === undefined) k = store.riskOf(p, r);
    if (!k) return el('span', { 'class': 'risk none' + (small ? ' small' : '') }, 'Not ranked');
    return el('span', { 'class': 'risk' + (small ? ' small' : ''), style: { background: k.color } }, k.label + (k.score != null ? ' ' + k.score : ''));
  }

  /* ---- node chips ---- */

  function chips(p, S) {
    var wrap = el('div', { 'class': 'chips', id: 'chips' });
    var nodes = Object.keys(p.nodes).map(function (k) { return p.nodes[k]; });
    if (!nodes.length) {
      wrap.appendChild(el('div', { 'class': 'muted' }, 'No nodes yet.'));
      return wrap;
    }
    nodes.forEach(function (n) {
      var count = store.nodeScenarios(p, n.id).length;
      wrap.appendChild(el('button', {
        'class': 'chip' + (n.id === S.sel.nodeId ? ' on' : ''), title: n.name || n.displayId,
        style: { borderColor: n.color },
        onclick: function () { goNode(n); }
      }, el('span', { 'class': 'dot', style: { background: n.color } }), el('b', null, n.displayId),
         n.name ? el('span', { 'class': 'chip-name' }, n.name) : null,
         el('span', { 'class': 'chip-count' }, String(count))));
    });
    return wrap;
  }

  function goNode(n) {
    var S = store.S;
    var here = n.regions.some(function (r) { return r.drawingId === S.drawingId; });
    if (!here && n.regions.length) store.setDrawing(n.regions[0].drawingId);
    store.select(n.id === S.sel.nodeId ? null : n.id, null);
  }

  function refreshChips() {
    var old = document.getElementById('chips');
    if (old && store.S.project) old.replaceWith(chips(store.S.project, store.S));
  }

  /* ---- node editor ---- */

  function nodeEditor(p, n) {
    var S = store.S;
    var box = el('div', { 'class': 'node-box', style: { borderTopColor: n.color } });
    var here = n.regions.filter(function (r) { return r.drawingId === S.drawingId; }).length;
    var tags = n.equipmentIds.map(function (id) { return p.equipment[id] ? p.equipment[id].tag : ''; }).filter(Boolean).join(', ');

    box.appendChild(el('div', { 'class': 'row' },
      field('Node ID', text(n.displayId, function (v) { n.displayId = v; }, { 'class': 'short' }), 'w-id'),
      field('Node name', text(n.name, function (v) { n.name = v; }, { id: 'nodeName', placeholder: 'e.g. Feed pump P-201 to reactor R-210' }), 'grow'),
      field('Status', select(n.status, STATUS, function (e) {
        var v = e.target.value || 'not-started';
        store.change(function () { n.status = v; }, 'field');
      }, 'Status'), 'w-status')));

    box.appendChild(field('Design intent', area(n.designIntent, function (v) { n.designIntent = v; },
      { placeholder: 'What this part of the process is meant to do, and its normal operating conditions' })));

    box.appendChild(field('Equipment tags', text(tags, function (v, proj) {
      var want = v.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
      var have = {};
      n.equipmentIds.forEach(function (id) { if (proj.equipment[id]) have[proj.equipment[id].tag] = id; });
      var next = want.map(function (tag) {
        if (have[tag]) { var id = have[tag]; delete have[tag]; return id; }
        var eq = { id: U.uid('eq'), tag: tag, type: '', drawingId: null, pin: null };
        proj.equipment[eq.id] = eq;
        return eq.id;
      });
      Object.keys(have).forEach(function (t) { delete proj.equipment[have[t]]; });
      n.equipmentIds = next;
    }, { placeholder: 'Comma separated, e.g. P-201, FV-203, R-210' })));

    var sw = el('div', { 'class': 'swatches' });
    store.PALETTE.forEach(function (c) {
      sw.appendChild(el('button', {
        'class': 'swatch' + (c === n.color ? ' on' : ''), style: { background: c }, title: 'Use this color',
        onclick: function () { store.change(function () { n.color = c; }); }
      }));
    });

    box.appendChild(el('div', { 'class': 'row tools-row' },
      el('div', { 'class': 'field' }, el('span', { 'class': 'flabel' }, 'Color'), sw),
      el('div', { 'class': 'grow' }),
      el('span', { 'class': 'muted' }, n.regions.length + (n.regions.length === 1 ? ' region' : ' regions') +
        (n.regions.length !== here ? ' (' + here + ' on this drawing)' : '')),
      el('button', { title: 'Outline another area that belongs to this node', onclick: function () { PHA.annotate.setMode('polygon', n.id); } }, '+ Region'),
      el('button', { title: 'Choose which analysis modules this node uses', onclick: function () { PHA.modules.openConfig(); } }, 'Modules'),
      here ? el('button', {
        title: 'Remove this node\'s regions from the current drawing',
        onclick: function () {
          if (!confirm('Remove the ' + here + ' region(s) of ' + n.displayId + ' on this drawing? The analysis is kept.')) return;
          store.change(function () { n.regions = n.regions.filter(function (r) { return r.drawingId !== S.drawingId; }); });
        }
      }, 'Clear regions') : null,
      el('button', {
        'class': 'danger', onclick: function () {
          var c = store.nodeScenarios(p, n.id).length;
          if (!confirm('Delete node ' + n.displayId + (c ? ' and its ' + c + ' scenario(s)' : '') + '? You can undo this.')) return;
          store.change(function (proj) { store.removeNode(proj, n.id); });
          store.select(null);
        }
      }, 'Delete node')));
    return box;
  }

  /* ---- scenarios ---- */

  function deviationOf(sc) { return store.deviationText(sc.parameter, sc.guideword); }

  function listEditor(title, items, addLabel, onAdd, rowFn) {
    var box = el('div', { 'class': 'list' }, el('span', { 'class': 'flabel' }, title));
    items.forEach(function (it, i) { box.appendChild(rowFn(it, i)); });
    box.appendChild(el('button', { 'class': 'add', onclick: onAdd }, addLabel));
    return box;
  }

  function riskRow(p, label, r, onChange) {
    var badge = el('span', { 'class': 'badge-slot' }, riskBadge(p, r));
    function upd(key) {
      return function (e) {
        var v = e.target.value;
        store.change(function () { r[key] = v; }, 'field');
        badge.textContent = ''; badge.appendChild(riskBadge(p, r));
        if (onChange) onChange();
      };
    }
    var m = p.project.riskMatrix;
    return el('div', { 'class': 'risk-row' },
      el('span', { 'class': 'risk-label' }, label),
      select(r.s, m.severity.map(function (o) { return [o.v, o.label]; }), upd('s'), 'Severity'),
      select(r.l, m.likelihood.map(function (o) { return [o.v, o.label]; }), upd('l'), 'Likelihood'),
      badge);
  }

  function statusBadge(sc) {
    var st = PHA.review.scState(sc);
    return el('span', { 'class': 'stbadge st-' + st }, PHA.review.SC_LABEL[st]);
  }

  /* Changing a scenario's parameter or guideword changes its deviation record, and every scenario made from it. */
  function devPicker(p, n, sc, key) {
    return function (e) {
      var v = e.target.value, d = p.deviations[sc.deviationId];
      if (!d) return;
      var nextP = key === 'parameter' ? v : d.parameter, nextG = key === 'guideword' ? v : d.guideword;
      var other = store.findDeviation(p, n.id, nextP, nextG);
      if (other && other.id !== d.id) {
        alert('This node already has a review record for "' + other.text + '". Open that deviation instead, or choose a different combination.');
        e.target.value = d[key];
        return;
      }
      store.change(function (proj) {
        var patch = {}; patch[key] = v;
        if (sc.deviationAuto || !d.text) patch.text = store.deviationText(nextP, nextG);
        store.setDeviationFields(proj, d, patch);
      });
    };
  }

  function scenarioCard(p, n, sc, open) {
    var card = el('div', { 'class': 'card' + (open ? ' open' : ''), 'data-scenario': sc.id });
    var title = el('span', { 'class': 'dev' }, sc.deviation || 'New deviation');
    var riskOn = PHA.modules.enabled(p, n, 'riskMatrix');
    var headBadge = el('span', { 'class': 'badge-slot' }, !riskOn ? null
      : sc.riskStatus.status === 'not-applicable' ? el('span', { 'class': 'risk none small' }, 'Risk N/A') : riskBadge(p, null, true, store.scenarioRisk(p, sc, 'mitigated')));
    var nRec = sc.recommendationIds.length;
    card.appendChild(el('button', {
      'class': 'card-head', onclick: function () { store.select(n.id, open ? null : sc.id); }
    }, el('span', { 'class': 'chev' }, open ? '▾' : '▸'), el('span', { 'class': 'scid' }, sc.displayId), title,
       nRec ? el('span', { 'class': 'tag' }, nRec + (nRec === 1 ? ' rec' : ' recs')) : null, statusBadge(sc), headBadge));
    if (!open) return card;

    var d = p.deviations[sc.deviationId];
    var body = el('div', { 'class': 'card-body' });
    body.appendChild(el('div', { 'class': 'row end top-actions' },
      el('span', { 'class': 'muted grow' }, d ? 'Deviation review: ' + PHA.review.devState(p, d).label : ''),
      el('button', { 'data-act': 'open-wizard', title: 'Work through this scenario one question at a time', onclick: function () { PHA.wizard.start(n.id, { scenarioId: sc.id, step: PHA.wizard.CAUSES }); } }, 'Open in wizard')));
    body.appendChild(el('div', { 'class': 'row' },
      field('Parameter', select(sc.parameter, p.project.parameters, devPicker(p, n, sc, 'parameter'), 'Choose')),
      field('Guideword', select(sc.guideword, p.project.guidewords, devPicker(p, n, sc, 'guideword'), 'Choose')),
      field('Deviation', text(sc.deviation, function (v, proj) {
        var dd = proj.deviations[sc.deviationId];
        if (dd) store.setDeviationFields(proj, dd, { text: v }); else { sc.deviation = v; sc.deviationAuto = false; }
        title.textContent = v || 'New deviation';
      }, { placeholder: 'e.g. No flow' }), 'grow')));

    body.appendChild(el('div', { 'class': 'list' }, el('span', { 'class': 'flabel' }, 'Initiating causes'), PHA.items.causeList(p, sc)));
    var sq = sc.sequence;
    body.appendChild(el('div', { 'class': 'list seq-block' }, el('span', { 'class': 'flabel' }, 'Failure sequence'),
      area(sq.mechanism, function (v) { sq.mechanism = v; }, { placeholder: 'How the deviation could escalate, e.g. pump deadheads; prolonged operation may damage the seal' }),
      el('div', { 'class': 'row' },
        select(sq.eventType, [['loc', 'Loss of containment'], ['other', 'Other hazardous event']], function (e) { var v = e.target.value; store.change(function () { sq.eventType = v; }, 'field'); }, 'Type of hazardous event'),
        text(sq.event, function (v) { sq.event = v; }, { placeholder: 'Hazardous event, e.g. seal loses integrity and releases toluene', 'class': 'grow' })),
      el('label', { 'class': 'chk-inline' }, el('input', { type: 'checkbox', checked: sq.direct ? true : null, onchange: function (e) { var v = e.target.checked; store.change(function () { sq.direct = v; }); } }),
        'No intermediate mechanism: the consequences follow directly from the deviation')));
    body.appendChild(el('div', { 'class': 'list' }, el('span', { 'class': 'flabel' }, 'Consequences'), PHA.items.consequenceList(p, sc)));
    body.appendChild(el('div', { 'class': 'list' }, el('span', { 'class': 'flabel' }, 'Existing safeguards'), PHA.items.safeguardList(p, n, sc)));

    var riskEl = PHA.modules.riskBlock(p, n, sc, function () {
      headBadge.textContent = ''; headBadge.appendChild(riskBadge(p, null, true, store.scenarioRisk(p, sc, 'mitigated')));
    });
    if (riskEl) body.appendChild(riskEl);

    body.appendChild(el('div', { 'class': 'list' }, el('span', { 'class': 'flabel' }, 'Recommendations and actions'), PHA.items.recommendationList(p, sc)));
    body.appendChild(field('Discussion notes', area(sc.notes, function (v) { sc.notes = v; })));
    body.appendChild(PHA.items.statusControl(p, sc));

    body.appendChild(el('div', { 'class': 'row end' }, el('button', {
      'class': 'danger', onclick: function () {
        if (!confirm('Delete scenario ' + sc.displayId + '? Its deviation review record is kept. You can undo this.')) return;
        store.change(function (proj) { store.removeScenario(proj, sc.id); });
        store.select(n.id, null);
      }
    }, 'Delete scenario')));

    card.appendChild(body);
    return card;
  }

  /* ---- deviation review list for a node ---- */

  function deviationSection(p, n) {
    var devs = store.nodeDeviations(p, n.id);
    var sec = el('div', { 'class': 'devs' });
    var s = PHA.review.summary(p, n.id);
    sec.appendChild(el('div', { 'class': 'sec-head' },
      el('h3', null, 'Deviation review', el('span', { 'class': 'count' }, s.decided + '/' + s.deviations)),
      el('div', { 'class': 'row' },
        el('button', { title: 'Add parameter and guideword combinations to review as outstanding items', onclick: function () { checklist(p, n); } }, 'Checklist...'),
        el('button', { 'class': 'primary', 'data-act': 'review-deviation', onclick: function () { PHA.wizard.start(n.id); } }, '+ Review a deviation'))));
    if (!devs.length) {
      sec.appendChild(el('div', { 'class': 'muted pad' }, 'No deviations recorded for this node. Use "Review a deviation" to start the guided wizard.'));
      return sec;
    }
    sec.appendChild(el('div', { 'class': 'muted dev-sum' }, PHA.review.summaryLines(s).slice(0, 3).join(' ')));
    var list = el('div', { 'class': 'devlist' });
    devs.sort(function (a, b) { return (a.parameter + a.guideword).localeCompare(b.parameter + b.guideword); });
    devs.forEach(function (d) {
      var st = PHA.review.devState(p, d);
      list.appendChild(el('button', { 'class': 'devrow ds-' + st.key, 'data-dev': d.id, title: d.status === 'no' ? (d.reason || 'No reason recorded') : st.label,
        onclick: function () { PHA.wizard.start(n.id, { devId: d.id, step: 2, scenarioId: st.scenarios.length === 1 ? st.scenarios[0].id : null }); } },
        el('span', { 'class': 'devtxt' }, d.text || '(no wording)'),
        el('span', { 'class': 'devst' }, st.label),
        st.scenarios.length ? el('span', { 'class': 'tag' }, st.scenarios.map(function (x) { return x.displayId; }).join(', ')) : null));
    });
    sec.appendChild(list);
    return sec;
  }

  /* Add parameter x guideword combinations as Not reviewed records, so nothing is forgotten. Existing ones are left alone. */
  function checklist(p, n) {
    var boxes = [];
    var grid = el('table', { 'class': 'cl-grid' });
    grid.appendChild(el('tr', null, el('th'), p.project.guidewords.map(function (g) { return el('th', null, g); })));
    p.project.parameters.forEach(function (pa) {
      grid.appendChild(el('tr', null, el('th', null, pa), p.project.guidewords.map(function (g) {
        var have = store.findDeviation(p, n.id, pa, g);
        var cb = el('input', { type: 'checkbox', checked: have ? true : null, disabled: have ? true : null, title: store.deviationText(pa, g) });
        if (!have) boxes.push({ cb: cb, pa: pa, g: g });
        return el('td', null, cb);
      })));
    });
    var body = el('div', null, el('p', null, 'Tick the deviations to add to ' + n.displayId + ' as outstanding (Not reviewed). Combinations already recorded are ticked and greyed out.'), grid);
    PHA.dashboard.ask('Deviation checklist', body, [{ key: null, label: 'Cancel' }, { key: 'ok', label: 'Add selected', cls: 'primary' }]).then(function (k) {
      if (k !== 'ok') return;
      var picked = boxes.filter(function (b) { return b.cb.checked; });
      if (!picked.length) return;
      store.change(function (proj) {
        picked.forEach(function (b) { store.createDeviation(proj, n.id, { parameter: b.pa, guideword: b.g, text: store.deviationText(b.pa, b.g) }); });
      });
    });
  }

  function scenarioSection(p, n) {
    var S = store.S, list = store.nodeScenarios(p, n.id);
    list.sort(function (a, b) { return (a.displayId || '').localeCompare(b.displayId || '', undefined, { numeric: true }); });
    var wrap = el('div');
    wrap.appendChild(deviationSection(p, n));
    var sec = el('div', { 'class': 'scenarios' });
    sec.appendChild(el('div', { 'class': 'sec-head' },
      el('h3', null, 'Scenarios', el('span', { 'class': 'count' }, String(list.length))),
      el('button', { title: 'Add a scenario and edit every field at once', 'data-act': 'add-scenario', onclick: function () {
        var id;
        store.change(function (proj) { id = store.createScenario(proj, n.id).id; });
        store.select(n.id, id);
      } }, '+ Add scenario (full editor)')));
    if (!list.length) sec.appendChild(el('div', { 'class': 'muted pad' }, 'No scenarios recorded for this node yet.'));
    list.forEach(function (sc) { sec.appendChild(scenarioCard(p, n, sc, sc.id === S.sel.scenarioId)); });
    wrap.appendChild(sec);
    return wrap;
  }

  /* ---- drawing details (shown when no node is selected) ---- */

  function drawingBox(p, d) {
    var box = el('div', { 'class': 'node-box drawing-box' });
    box.appendChild(el('h3', null, 'Drawing details'));
    box.appendChild(el('div', { 'class': 'row' },
      field('Drawing number', text(d.number, function (v) { d.number = v; PHA.main && PHA.main.fillDrawings(); }), 'grow'),
      field('Revision', text(d.revision, function (v) { d.revision = v; PHA.main && PHA.main.fillDrawings(); }, { 'class': 'short' }), 'w-id'),
      field('Revision date', el('input', { type: 'date', value: d.revisionDate || '', oninput: setField(function (v) { d.revisionDate = v; }) }))));
    box.appendChild(field('Title', text(d.title, function (v) { d.title = v; })));
    var used = Object.keys(p.nodes).filter(function (k) { return p.nodes[k].regions.some(function (r) { return r.drawingId === d.id; }); }).length;
    box.appendChild(el('div', { 'class': 'row tools-row' },
      el('span', { 'class': 'muted file-info' }, d.file.name + (d.pageCount > 1 ? ', page ' + d.page + ' of ' + d.pageCount : '') +
        '  |  fingerprint ' + d.file.sha256.slice(0, 10)),
      el('div', { 'class': 'grow' }),
      el('button', { 'class': 'danger', onclick: function () {
        if (!confirm('Remove this drawing from the project?' + (used ? ' Regions of ' + used + ' node(s) on it will be removed. Their analysis is kept.' : ''))) return;
        var ids = Object.keys(p.drawings), i = ids.indexOf(d.id);
        var next = ids[i + 1] || ids[i - 1] || null;
        store.change(function (proj) { store.removeDrawing(proj, d.id); });
        store.S.drawingId = null; store.setDrawing(next);
        if (!next) PHA.viewer.show();
      } }, 'Remove drawing')));
    return box;
  }

  /* ---- render ---- */

  function render() {
    var S = store.S, p = S.project;
    if (!root || !p) return;
    var top = root.scrollTop;
    root.textContent = '';
    root.appendChild(el('div', { 'class': 'sec-head' }, el('h3', null, 'Nodes'),
      el('span', { 'class': 'muted' }, 'Draw on the P&ID to add a node')));
    root.appendChild(chips(p, S));

    if (S.ui.wizard && PHA.wizard.render(root)) { finishRender(top); return; }
    var n = p.nodes[S.sel.nodeId];
    if (n) {
      root.appendChild(nodeEditor(p, n));
      var tb = PHA.modules.tabBar(p, n);
      if (tb.el) root.appendChild(tb.el);
      root.appendChild(tb.active === 'scenarios' ? scenarioSection(p, n) : PHA.modules.renderTab(tb.active, p, n));
      var hidden = PHA.modules.hiddenNote(p, n);
      if (hidden) root.appendChild(hidden);
    } else {
      var d = p.drawings[S.drawingId];
      if (d) {
        root.appendChild(el('div', { 'class': 'help' },
          el('p', null, el('b', null, 'To start: '), 'choose ', el('b', null, 'Polygon node'), ' or ', el('b', null, 'Box node'),
            ' above the drawing and outline part of the process. Then name the node and add its scenarios here.'),
          el('p', null, 'Click any colored node on the drawing to bring its analysis back.')));
        root.appendChild(drawingBox(p, d));
      } else {
        root.appendChild(el('div', { 'class': 'help' },
          el('p', null, 'Import a P&ID to begin, or open an existing project file.')));
      }
    }
    finishRender(top);
  }
  function finishRender(top) {
    root.scrollTop = top;
    if (flashMsg) { root.insertBefore(el('div', { 'class': 'flash', role: 'status' }, flashMsg), root.firstChild); flashMsg = null; }
    if (focusKey) {
      var t = root.querySelector('[data-focus="' + focusKey + '"]');
      focusKey = null;
      if (t) { t.focus(); if (t.scrollIntoView) t.scrollIntoView({ block: 'nearest' }); }
    }
  }
  var flashMsg = null;
  /* A short confirmation shown at the top of the panel on its next redraw. */
  function flash(msg) { flashMsg = msg; render(); }

  function focus(key) {
    focusKey = key;
    var t = root.querySelector('[data-focus="' + key + '"]');
    if (t) { t.focus(); focusKey = null; }
  }

  function focusName() {
    var t = document.getElementById('nodeName');
    if (t) t.focus();
  }

  function init() { root = document.getElementById('panel'); }

  PHA.ui = { field: field, text: text, area: area, select: select, setField: setField, riskBadge: riskBadge, riskRow: riskRow };
  PHA.panel = { init: init, render: render, refreshChips: refreshChips, focusName: focusName, focus: focus, flash: flash, statusBadge: statusBadge };
})();
