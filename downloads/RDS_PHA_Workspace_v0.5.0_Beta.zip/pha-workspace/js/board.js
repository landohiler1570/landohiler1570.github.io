/* board.js: the Node Board. Scenario cards drawn straight from the scenario records, in the area the P&ID uses.
   It holds no data of its own: every card is rebuilt from store.S.project each time it is drawn. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, R = PHA.review;

  var root, viewer, visible = false, timer = null;
  var view = { mode: 'node', nodeId: '', q: '', risk: '', completion: '', openRecs: false };
  var expanded = {};                         // scenario id -> true when the card shows every item (view state only)
  var SHOW = 3;                              // items shown per list before "show all"

  function txt(v) { return String(v == null ? '' : v).trim(); }
  function nodesSorted(p) {
    return Object.keys(p.nodes).map(function (k) { return p.nodes[k]; })
      .sort(function (a, b) { return (a.displayId || '').localeCompare(b.displayId || '', undefined, { numeric: true }); });
  }

  /* ---------- one scenario card ---------- */

  function list(title, items, fmt, cls, all) {
    var real = items.filter(function (x) { return x; });
    var box = el('div', { 'class': 'sc-sec ' + (cls || '') }, el('div', { 'class': 'sc-sec-h' }, title, el('span', { 'class': 'sc-n' }, String(real.length))));
    if (!real.length) { box.appendChild(el('div', { 'class': 'sc-none' }, 'None recorded')); return box; }
    var ol = el('ol', { 'class': 'sc-list' });
    real.forEach(function (it, i) { if (all || i < SHOW) ol.appendChild(el('li', null, fmt(it, i))); });
    box.appendChild(ol);
    return { box: box, hidden: all ? 0 : Math.max(0, real.length - SHOW) };
  }

  /* opts: { static: no click handlers (wizard summary), expanded: show everything } */
  function card(p, sc, opts) {
    opts = opts || {};
    var n = p.nodes[sc.nodeId] || {}, st = R.scState(sc), all = opts.expanded || !!expanded[sc.id];
    var u = store.scenarioRisk(p, sc, 'unmitigated'), m = store.scenarioRisk(p, sc, 'mitigated');
    var riskNA = (sc.riskStatus || {}).status === 'not-applicable';
    var openRecs = sc.recommendationIds.filter(function (id) { return p.recommendations[id] && p.recommendations[id].status !== 'closed'; }).length;
    var nRecs = sc.recommendationIds.filter(function (id) { return p.recommendations[id]; }).length;
    var sel = store.S.sel.scenarioId === sc.id;

    var c = el('article', { 'class': 'scard st-' + st + (sel ? ' sel' : '') + (opts.static ? ' static' : ''), 'data-scenario': sc.id, style: { borderTopColor: n.color || '#888' },
      tabindex: opts.static ? null : '0', role: opts.static ? null : 'button', 'aria-label': opts.static ? null : 'Open scenario ' + sc.displayId });
    c.appendChild(el('header', { 'class': 'sc-head' },
      el('span', { 'class': 'sc-id' }, sc.displayId || ''),
      el('span', { 'class': 'sc-pg' }, [sc.parameter, sc.guideword].filter(Boolean).join(' / ') || 'Parameter and guideword not set'),
      el('span', { 'class': 'grow' }),
      PHA.panel.statusBadge(sc)));
    c.appendChild(el('div', { 'class': 'sc-dev' }, sc.deviation || 'No deviation stated'));

    var causes = sc.causes.filter(function (x) { return txt(x.text); });
    var csqs = sc.consequences.filter(function (x) { return txt(x.text); });
    var cIndex = {};
    sc.causes.forEach(function (x, i) { cIndex[x.id] = 'C' + (i + 1); });
    var sfgs = sc.safeguardIds.map(function (id) { return p.safeguards[id]; }).filter(function (g) { return g && txt(g.description); });
    var hidden = 0;
    var a = list('Initiating causes', causes, function (x) { return x.text; }, 'causes', all);
    var b = list('Consequences', csqs, function (q) {
      var tags = [];
      if (q.causeIds && q.causeIds.length && causes.length > 1) tags.push(q.causeIds.map(function (id) { return cIndex[id]; }).filter(Boolean).join(', '));
      if (q.category) tags.push(q.category);
      var k = p.project.riskMatrix.rankBy === 'consequence' && q.risk ? (store.riskOf(p, q.risk.mitigated) || store.riskOf(p, q.risk.unmitigated)) : null;
      if (txt(q.escalation)) tags.push(q.escalation);
      return [q.text, tags.length ? el('span', { 'class': 'sc-tag' }, tags.join(' · ')) : null, k ? el('span', { 'class': 'risk small', style: { background: k.color } }, k.label) : null];
    }, 'csq', all);
    var g = list('Existing safeguards', sfgs, function (s) {
      return [s.role ? el('span', { 'class': 'role role-' + s.role, title: s.role === 'preventive' ? 'Preventive' : 'Mitigative' }, s.role === 'preventive' ? 'P' : 'M') : null, s.description];
    }, 'sgs', all);
    // 0.5.0: failure sequence between causes and consequences, so the escalation is visible in team review.
    var sq = sc.sequence || {}, seqBox = el('div', { 'class': 'sc-sec seq' }, el('div', { 'class': 'sc-sec-h' }, 'Failure sequence'));
    if (sq.direct) seqBox.appendChild(el('div', { 'class': 'sc-none' }, 'No intermediate mechanism recorded as needed'));
    else if (!txt(sq.mechanism) && !txt(sq.event)) seqBox.appendChild(el('div', { 'class': 'sc-none' }, 'Not recorded'));
    if (txt(sq.mechanism) && !sq.direct) seqBox.appendChild(el('div', { 'class': 'sc-seq' }, sq.mechanism));
    if (txt(sq.event)) seqBox.appendChild(el('div', { 'class': 'sc-seq' }, el('b', null, (sq.eventType === 'loc' ? 'Loss of containment' : 'Hazardous event') + ': '), sq.event));
    var pend = causes.concat(csqs).filter(function (x) { return x.teamStatus === 'pending' || PHA.library.unfilled(x).length; }).length;
    [a, seqBox, b, g].forEach(function (x) { if (x.box) { c.appendChild(x.box); hidden += x.hidden; } else c.appendChild(x); });
    if (pend) c.appendChild(el('div', { 'class': 'sc-pend' }, pend + ' Quick-Add item' + (pend === 1 ? '' : 's') + ' awaiting team confirmation'));

    var riskRow = el('div', { 'class': 'sc-risk' }, el('span', { 'class': 'sc-sec-h' }, 'Risk'));
    if (!PHA.modules.enabled(p, n, 'riskMatrix')) riskRow.appendChild(el('span', { 'class': 'sc-none' }, 'Risk matrix off for this node'));
    else if (riskNA) riskRow.appendChild(el('span', { 'class': 'sc-none' }, 'Not applicable' + (sc.riskStatus.reason ? ': ' + sc.riskStatus.reason : '')));
    else {
      riskRow.appendChild(PHA.ui.riskBadge(p, null, true, u));
      riskRow.appendChild(el('span', { 'class': 'arrow', title: 'without safeguards → with safeguards' }, '→'));
      riskRow.appendChild(PHA.ui.riskBadge(p, null, true, m));
      if (p.project.riskMatrix.rankBy === 'consequence') riskRow.appendChild(el('span', { 'class': 'muted small' }, 'highest consequence'));
    }
    c.appendChild(riskRow);
    c.appendChild(el('footer', { 'class': 'sc-foot' },
      el('span', { 'class': nRecs ? (openRecs ? 'recs open' : 'recs') : 'recs none' }, nRecs ? nRecs + ' recommendation' + (nRecs === 1 ? '' : 's') + (openRecs ? ' (' + openRecs + ' open)' : ', all closed') : 'No recommendations'),
      el('span', { 'class': 'grow' }),
      !opts.static && hidden ? el('button', { 'class': 'link', 'data-act': 'expand', onclick: function (e) { e.stopPropagation(); expanded[sc.id] = true; render(); } }, 'Show all (' + hidden + ' more)') : null,
      !opts.static && expanded[sc.id] && !opts.expanded ? el('button', { 'class': 'link', 'data-act': 'collapse', onclick: function (e) { e.stopPropagation(); delete expanded[sc.id]; render(); } }, 'Show less') : null,
      !opts.static ? el('button', { 'class': 'mini-btn', 'data-act': 'wizard', title: 'Open this scenario in the guided wizard', onclick: function (e) { e.stopPropagation(); openScenario(sc, 'wizard'); } }, 'Wizard') : null));
    if (!opts.static) {
      c.addEventListener('click', function () { openScenario(sc, 'editor'); });
      c.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target === c) openScenario(sc, 'editor'); });
    }
    return c;
  }

  function openScenario(sc, how) {
    if (how === 'wizard') PHA.wizard.start(sc.nodeId, { scenarioId: sc.id, step: PHA.wizard.CAUSES });
    else {
      store.S.ui.wizard = null;
      store.S.ui.tab = 'scenarios';
      store.select(sc.nodeId, sc.id);
      setTimeout(function () {
        var t = document.querySelector('#panel .card.open');
        if (t && t.scrollIntoView) t.scrollIntoView({ block: 'start' });
      }, 0);
    }
  }

  /* ---------- node group: summary, outstanding deviations, cards ---------- */

  function devStrip(p, n) {
    var devs = store.nodeDeviations(p, n.id), groups = { 'not-reviewed': [], na: [], open: [] };
    devs.forEach(function (d) {
      var st = R.devState(p, d);
      if (st.key === 'not-reviewed') groups['not-reviewed'].push(d);
      else if (d.status === 'no') groups.na.push(d);
      else if (st.key === 'yes-no-scenario') groups.open.push(d);
    });
    var box = el('div', { 'class': 'dstrip' });
    function row(label, cls, arr, tip) {
      if (!arr.length) return;
      box.appendChild(el('div', { 'class': 'drow ' + cls }, el('span', { 'class': 'dlab' }, label),
        arr.map(function (d) {
          return el('button', { 'class': 'dchip', title: tip(d), onclick: function () { PHA.wizard.start(n.id, { devId: d.id, step: 2 }); } }, d.text || '(no wording)');
        })));
    }
    row('Not reviewed', 'nr', groups['not-reviewed'], function () { return 'Outstanding: open it in the wizard to decide'; });
    row('Applicable, no analysis', 'ya', groups.open, function () { return 'Marked applicable but no scenario or disposition is recorded'; });
    row('Not applicable', 'na', groups.na, function (d) { return d.reason ? 'Basis: ' + d.reason : 'No basis recorded'; });
    return box.children.length ? box : null;
  }

  function group(p, n, scs, showStrip) {
    var s = R.summary(p, n.id);
    var g = el('section', { 'class': 'bgroup', 'data-node': n.id });
    g.appendChild(el('div', { 'class': 'bg-head', style: { borderLeftColor: n.color } },
      el('div', { 'class': 'bg-title' }, el('b', null, n.displayId), ' ', n.name ? '— ' + n.name : el('span', { 'class': 'muted' }, '(unnamed node)')),
      el('ul', { 'class': 'bg-sum' }, R.summaryLines(s).map(function (l) { return el('li', null, l); })),
      el('div', { 'class': 'bg-acts' }, el('button', { onclick: function () { PHA.wizard.start(n.id); } }, '+ Review a deviation'))));
    if (showStrip) { var strip = devStrip(p, n); if (strip) g.appendChild(strip); }
    var grid = el('div', { 'class': 'bgrid' });
    if (!scs.length) grid.appendChild(el('div', { 'class': 'muted pad' }, filtered() ? 'No scenarios match the filters.' : 'No scenarios recorded for this node.'));
    scs.forEach(function (sc) { grid.appendChild(card(p, sc)); });
    g.appendChild(grid);
    return g;
  }

  function filtered() { return !!(view.q || view.risk || view.completion || view.openRecs || (view.mode === 'all' && view.nodeId)); }

  function toolbar(p) {
    var bar = el('div', { 'class': 'btool' });
    var seg = el('div', { 'class': 'seg' });
    [['node', 'Selected node'], ['all', 'All nodes']].forEach(function (m) {
      seg.appendChild(el('button', { 'class': view.mode === m[0] ? 'on' : '', 'data-mode': m[0], onclick: function () { view.mode = m[0]; render(); } }, m[1]));
    });
    bar.appendChild(seg);
    if (view.mode === 'all') {
      bar.appendChild(el('select', { 'aria-label': 'Node filter', 'data-filter': 'node', value: view.nodeId, onchange: function (e) { view.nodeId = e.target.value; render(); } },
        [el('option', { value: '' }, 'All nodes')].concat(nodesSorted(p).map(function (n) { return el('option', { value: n.id }, n.displayId + (n.name ? ' ' + n.name : '')); }))));
    }
    var q = el('input', { type: 'text', placeholder: 'Find deviation', 'data-filter': 'q', value: view.q, 'aria-label': 'Deviation filter' });
    q.addEventListener('input', U.debounce(function () { view.q = q.value; render(); var x = root.querySelector('[data-filter=q]'); if (x) { x.focus(); x.setSelectionRange(x.value.length, x.value.length); } }, 250));
    bar.appendChild(q);
    var bands = (p.project.riskMatrix.bands || []).map(function (b) { return [b.label, b.label]; });
    bar.appendChild(el('select', { 'aria-label': 'Risk filter', 'data-filter': 'risk', value: view.risk, onchange: function (e) { view.risk = e.target.value; render(); } },
      [el('option', { value: '' }, 'Any risk ranking')].concat(bands.map(function (b) { return el('option', { value: b[0] }, 'Ranked ' + b[1]); }), [el('option', { value: 'unranked' }, 'Not ranked')])));
    bar.appendChild(el('select', { 'aria-label': 'Completion filter', 'data-filter': 'completion', value: view.completion, onchange: function (e) { view.completion = e.target.value; render(); } },
      [['', 'Any status'], ['complete', 'Reviewed'], ['incomplete', 'Not yet reviewed'], ['verify', 'Pending verification']].map(function (o) { return el('option', { value: o[0] }, o[1]); })));
    bar.appendChild(el('label', { 'class': 'chk-inline' }, el('input', { type: 'checkbox', 'data-filter': 'recs', checked: view.openRecs ? true : null, onchange: function (e) { view.openRecs = e.target.checked; render(); } }), 'Open recommendations'));
    if (filtered()) bar.appendChild(el('button', { 'class': 'link', onclick: function () { view.q = ''; view.risk = ''; view.completion = ''; view.openRecs = false; view.nodeId = ''; render(); } }, 'Clear filters'));
    return bar;
  }

  function render() {
    if (!root || !visible) return;
    var S = store.S, p = S.project;
    var top = root.scrollTop;
    root.textContent = '';
    if (!p) return;
    root.appendChild(toolbar(p));
    var body = el('div', { 'class': 'bbody' });
    var opts = { q: view.q, risk: view.risk, completion: view.completion, openRecs: view.openRecs };
    if (view.mode === 'node') {
      var n = p.nodes[S.sel.nodeId];
      if (!n) body.appendChild(el('div', { 'class': 'help' }, el('p', null, 'Select a node on the P&ID or in the node list to see its scenario cards, or choose ', el('b', null, 'All nodes'), '.')));
      else body.appendChild(group(p, n, R.filterScenarios(p, Object.assign({ nodeId: n.id }, opts)), true));
    } else {
      var all = R.summary(p, null);
      body.appendChild(el('div', { 'class': 'bstudy' }, el('b', null, 'Study: '), R.summaryLines(all).join(' ')));
      var shown = 0;
      nodesSorted(p).forEach(function (nd) {
        if (view.nodeId && nd.id !== view.nodeId) return;
        var scs = R.filterScenarios(p, Object.assign({ nodeId: nd.id }, opts));
        if (filtered() && !scs.length) return;
        shown++;
        body.appendChild(group(p, nd, scs, !filtered()));
      });
      if (!shown) body.appendChild(el('div', { 'class': 'muted pad' }, Object.keys(p.nodes).length ? 'No scenarios match the filters.' : 'No nodes yet. Draw a node on the P&ID first.'));
    }
    root.appendChild(body);
    root.scrollTop = top;
  }

  function refresh() { clearTimeout(timer); timer = null; render(); }
  function refreshSoon() { if (!visible) return; clearTimeout(timer); timer = setTimeout(render, 300); }

  /* P&ID View | Node Board. Switching only changes what is shown; no record is touched. */
  function setMain(which) {
    visible = which === 'board';
    viewer.dataset.main = which;
    Array.prototype.forEach.call(document.querySelectorAll('#mainView button'), function (b) { b.classList.toggle('on', b.dataset.main === which); });
    root.hidden = !visible;
    try { localStorage.setItem('pha.mainView', which); } catch (e) { /* ignore */ }
    if (visible) render();
    else if (PHA.viewer.info().W && PHA.viewer.info().fitK <= 0.011) { PHA.viewer.fit(); }   // laid out while hidden
  }

  function init() {
    root = document.getElementById('board');
    viewer = document.getElementById('viewer');
    document.getElementById('mainView').addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (b) setMain(b.dataset.main);
    });
  }

  PHA.board = { init: init, render: render, refresh: refresh, refreshSoon: refreshSoon, card: card, setMain: setMain,
                isVisible: function () { return visible; }, view: view };
})();
