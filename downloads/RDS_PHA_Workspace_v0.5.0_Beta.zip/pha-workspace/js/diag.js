/* diag.js: "System check". Shows which browser features this machine allows when the app is opened from disk.
   Run this first on a locked-down computer. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el;

  function testWorker() {
    return new Promise(function (res) {
      try {
        var url = URL.createObjectURL(new Blob(['postMessage("ok")'], { type: 'text/javascript' }));
        var w = new Worker(url), done = false;
        var t = setTimeout(function () { if (!done) { done = true; w.terminate(); res(false); } }, 3000);
        w.onmessage = function () { if (!done) { done = true; clearTimeout(t); w.terminate(); res(true); } };
        w.onerror = function () { if (!done) { done = true; clearTimeout(t); res(false); } };
      } catch (e) { res(false); }
    });
  }

  async function testIdb() {
    try {
      var v = 'check-' + Date.now();
      await PHA.repo.kvSet('diag', v);
      return (await PHA.repo.kvGet('diag')) === v;
    } catch (e) { return false; }
  }

  function testZip() {
    try {
      var z = fflate.zipSync({ 'a.txt': fflate.strToU8('hello') });
      return fflate.strFromU8(fflate.unzipSync(z)['a.txt']) === 'hello';
    } catch (e) { return false; }
  }

  async function testHash() {
    try {
      var d = await crypto.subtle.digest('SHA-256', new Uint8Array([1, 2, 3]));
      return d.byteLength === 32;
    } catch (e) { return false; }
  }

  async function run() {
    var worker = await testWorker(), idb = await testIdb(), hash = await testHash(), si = await PHA.repo.storageInfo();
    var fsa = typeof window.showSaveFilePicker === 'function';
    var st = PHA.viewer.stats;
    return [
      { name: 'Opened from', ok: true, note: location.protocol === 'file:' ? 'Local disk (file://), no server' : location.protocol + '//' + location.host },
      { name: 'App scripts', ok: true, note: 'All local JavaScript files loaded. App version ' + PHA.store.APP_VERSION + ', project format ' + PHA.store.SCHEMA_VERSION },
      { name: 'PDF engine', ok: !!window.pdfjsLib, note: window.pdfjsLib ? 'PDF.js ' + pdfjsLib.version : 'PDF.js did not load' },
      { name: 'Background PDF rendering', ok: worker, warn: !worker,
        note: worker ? 'Available. Drawings render without freezing the screen.' : 'Blocked. Drawings still render, but the screen may pause on dense sheets.' },
      { name: 'Confirmed file export', ok: fsa, warn: !fsa,
        note: fsa ? 'Available. Export writes to the file you chose and is confirmed.' : 'Not available in this browser. Each export is a download, which the browser does not confirm.' },
      { name: 'Project repository (browser storage)', ok: idb, warn: false,
        note: idb ? 'Working now. Schema version ' + PHA.repo.DB_VERSION + '. Close the browser completely, reopen, and confirm your projects are still listed.'
                  : 'Blocked. Projects cannot be kept in this browser; export a .phaz file before closing.' },
      { name: 'Storage protection', ok: si.persisted === true, warn: si.persisted !== true,
        note: (si.persisted === true ? 'The browser marks this storage as persistent.' : 'Best-effort: the browser, IT policy or "clear browsing data" can remove it. Export .phaz files regularly.') +
              (si.quota ? ' Using ' + Math.round((si.usage || 0) / 1048576) + ' MB of about ' + Math.round(si.quota / 1048576) + ' MB.' : ' The browser did not report a storage limit.') },
      { name: 'Repository location', ok: true,
        note: 'Storage key "' + location.origin + '". ' + (location.protocol === 'file:' ? 'Opened from disk: Edge and Chrome keep one repository per browser profile for all local files; Firefox ties it to the folder path.' : '') },
      { name: 'Backup folder', ok: typeof window.showDirectoryPicker === 'function', warn: typeof window.showDirectoryPicker !== 'function',
        note: typeof window.showDirectoryPicker === 'function' ? 'Available (optional). One-click backups to a folder you choose.' : 'Not available. Use Export on each project.' },
      { name: 'Drawing fingerprints', ok: hash, warn: !hash,
        note: hash ? 'SHA-256 available' : 'Not available. Drawings get a random ID instead, so duplicates and changes are not detected.' },
      { name: 'Project bundles (zip)', ok: testZip(), note: 'Read and write' },
      { name: 'Last drawing render', ok: true,
        note: st.baseMs == null ? 'No drawing rendered yet. Import a dense P&ID and run this check again.'
          : 'Whole page ' + Math.round(st.baseMs) + ' ms' + (st.detailMs != null ? ', zoomed detail ' + Math.round(st.detailMs) + ' ms' : '') + ' (' + st.worker + ')' }
    ];
  }

  async function open() {
    var dlg = document.getElementById('diag');
    dlg.textContent = '';
    dlg.appendChild(el('h2', null, 'System check'));
    dlg.appendChild(el('p', { 'class': 'muted' }, 'Running checks ...'));
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
    var rows = await run();
    dlg.textContent = '';
    dlg.appendChild(el('h2', null, 'System check'));
    dlg.appendChild(el('p', { 'class': 'muted' }, 'What this browser allows when the app runs from disk. Yellow items reduce convenience; red items stop the app.'));
    var list = el('div', { 'class': 'checks' });
    rows.forEach(function (r) {
      var cls = r.ok ? 'ok' : (r.warn ? 'warn' : 'bad');
      list.appendChild(el('div', { 'class': 'check ' + cls },
        el('span', { 'class': 'mark' }, r.ok ? 'OK' : (r.warn ? 'LIMITED' : 'FAIL')),
        el('div', null, el('b', null, r.name), el('div', { 'class': 'muted' }, r.note))));
    });
    dlg.appendChild(list);
    dlg.appendChild(el('div', { 'class': 'row end' },
      el('span', { 'class': 'muted' }, navigator.userAgent.replace(/^Mozilla\/5\.0 /, '')),
      el('div', { 'class': 'grow' }),
      el('button', { 'class': 'primary', onclick: function () { dlg.close ? dlg.close() : dlg.removeAttribute('open'); } }, 'Close')));
    return rows;
  }

  PHA.diag = { open: open, run: run };
})();
