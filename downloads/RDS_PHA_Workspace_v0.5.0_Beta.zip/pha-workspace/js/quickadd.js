/* quickadd.js: the Quick-Add dialog for causes and consequences, and the template editor (0.5.0).
   A template is wording only. Inserting it adds an editable item marked "pending team confirmation";
   placeholders are filled only with what the user types or picks. */
(function () {
  'use strict';
  var PHA = window.PHA, U = PHA.util, el = U.el, store = PHA.store, L = PHA.library;
  function $(id) { return document.getElementById(id); }

  var state = { kind: 'cause', scId: null, q: '', scope: 'all', pickId: null, values: {} };
  var SCOPES = [['all', 'All'], ['fav', '★ Favorites'], ['project', 'This project'], ['personal', 'My templates'], ['builtin', 'Built-in']];
  var SCOPE_LABEL = { project: 'Project', personal: 'Mine', builtin: 'Built-in' };

  function dlg() { return $('qaDlg'); }
  function show(d) { if (!d.open) { if (d.showModal) d.showModal(); else d.setAttribute('open', ''); } }

  /* Text with its placeholders marked, for the list. */
  function marked(text) {
    var span = el('span', { 'class': 'qa-text' }), last = 0, re = /\[([A-Za-z][A-Za-z ]{0,30}[A-Za-z]|[A-Za-z])\]/g, m;
    text = String(text || '');
    while ((m = re.exec(text))) {
      if (m.index > last) span.appendChild(document.createTextNode(text.slice(last, m.index)));
      span.appendChild(el('b', { 'class': 'ph' }, m[0]));
      last = m.index + m[0].length;
    }
    if (last < text.length) span.appendChild(document.createTextNode(text.slice(last)));
    return span;
  }

  async function toggleFav(t) {
    var p = store.S.project;
    if (t.scope === 'project') {
      store.change(function (proj) { var x = proj.library.templates.filter(function (y) { return y.id === t.id; })[0]; if (x) x.favorite = !x.favorite; });
      render(); return;
    }
    var next = L.copyPersonal(), i = next.favorites.indexOf(t.id);
    if (i >= 0) next.favorites.splice(i, 1); else next.favorites.push(t.id);
    try { await L.savePersonal(next); } catch (e) { alert('The favorite could not be saved in this browser: ' + (e.message || e)); }
    render();
    void p;
  }

  function render() {
    var d = dlg(), p = store.S.project, sc = state.scId && p.scenarios[state.scId];
    if (!d || !p) return;
    var top = (d.querySelector('.qa-list') || {}).scrollTop || 0;
    d.textContent = '';
    var noun = state.kind === 'cause' ? 'initiating cause' : 'consequence';
    d.appendChild(el('div', { 'class': 'qa-head' }, el('h2', null, 'Quick Add: ' + noun),
      el('div', { 'class': 'grow' }),
      el('button', { 'data-act': 'qa-new', onclick: function () { editTemplate(null, state.kind, ''); } }, '+ New template'),
      el('button', { 'data-act': 'qa-close', onclick: function () { d.close(); } }, 'Close')));
    d.appendChild(el('p', { 'class': 'muted' }, 'Inserting a template adds editable wording. It does not establish that the ' + noun + ' is credible: the item is marked for team confirmation.' +
      (L.personalState() === 'unavailable' ? ' My templates are not available because browser storage could not be opened.' : '')));
    var q = el('input', { type: 'text', 'data-qa': 'search', placeholder: 'Search wording or category', value: state.q });
    q.addEventListener('input', U.debounce(function () { state.q = q.value; render(); var x = dlg().querySelector('[data-qa=search]'); if (x) { x.focus(); x.setSelectionRange(x.value.length, x.value.length); } }, 200));
    var seg = el('div', { 'class': 'seg' });
    SCOPES.forEach(function (s) { seg.appendChild(el('button', { 'class': state.scope === s[0] ? 'on' : '', 'data-scope': s[0], onclick: function () { state.scope = s[0]; render(); } }, s[1])); });
    d.appendChild(el('div', { 'class': 'row qa-filters' }, q, seg));

    var list = el('div', { 'class': 'qa-list' }), needle = state.q.trim().toLowerCase();
    var tpls = L.all(p, state.kind).filter(function (t) {
      if (state.scope === 'fav' && !t.fav) return false;
      if (state.scope !== 'all' && state.scope !== 'fav' && t.scope !== state.scope) return false;
      return !needle || (t.text + ' ' + t.category).toLowerCase().indexOf(needle) >= 0;
    }).sort(function (a, b) { return (b.fav ? 1 : 0) - (a.fav ? 1 : 0); });
    if (!tpls.length) list.appendChild(el('div', { 'class': 'muted pad' }, 'No templates match.'));
    tpls.forEach(function (t) {
      list.appendChild(el('div', { 'class': 'qa-row' + (state.pickId === t.id ? ' on' : ''), 'data-tpl': t.id },
        el('button', { 'class': 'qa-star' + (t.fav ? ' on' : ''), title: t.fav ? 'Remove from favorites' : 'Add to favorites', 'data-fav': t.id, onclick: function () { toggleFav(t); } }, t.fav ? '★' : '☆'),
        el('button', { 'class': 'qa-pick', 'data-pick': t.id, onclick: function () { state.pickId = t.id; state.values = {}; render(); } },
          t.category ? el('span', { 'class': 'qa-cat' }, t.category) : null, marked(t.text)),
        el('span', { 'class': 'qa-scope s-' + t.scope }, SCOPE_LABEL[t.scope]),
        t.scope === 'builtin' ? el('button', { 'class': 'mini-btn', title: 'Copy into this project\'s library so it can be changed', onclick: function () { editTemplate(null, t.kind, t.text, t.category); } }, 'Copy')
          : el('button', { 'class': 'mini-btn', 'data-edit': t.id, onclick: function () { editTemplate(t, t.kind, t.text, t.category); } }, 'Edit')));
    });
    d.appendChild(list);
    list.scrollTop = top;

    var pick = state.pickId && L.all(p, state.kind).filter(function (t) { return t.id === state.pickId; })[0];
    var pane = el('div', { 'class': 'qa-fill' });
    if (!pick) pane.appendChild(el('div', { 'class': 'muted' }, 'Choose a template above.'));
    else {
      var names = L.placeholders(pick.text), prev = el('div', { 'class': 'qa-preview', 'data-qa': 'preview' });
      function paint() { prev.textContent = L.fill(pick.text, state.values); }
      if (names.length) pane.appendChild(el('div', { 'class': 'flabel' }, 'Fill in the placeholders. Anything left blank stays in brackets and must be completed before the scenario can be reviewed.'));
      names.forEach(function (nm) {
        var inp = el('input', { type: 'text', 'data-ph': nm, value: state.values[nm] || '', placeholder: nm });
        inp.addEventListener('input', function () { state.values[nm] = inp.value; paint(); });
        var sug = L.suggestions(p, sc, nm);
        pane.appendChild(el('div', { 'class': 'qa-ph' }, el('label', null, '[' + nm + ']'), inp,
          sug.length ? el('div', { 'class': 'qa-sug' }, sug.map(function (s) {
            return el('button', { 'class': 'cchip', title: 'From ' + s.from, 'data-sug': s.value, onclick: function () { inp.value = s.value; state.values[nm] = s.value; paint(); } }, s.value);
          })) : el('div', { 'class': 'muted small' }, 'No value in the project records. Type it, or leave it blank.')));
      });
      paint();
      pane.appendChild(el('div', { 'class': 'flabel' }, 'Will insert'));
      pane.appendChild(prev);
      pane.appendChild(el('div', { 'class': 'row end' }, el('button', { 'class': 'primary', 'data-act': 'qa-insert', onclick: function () { insert(pick); } }, 'Insert ' + noun)));
    }
    d.appendChild(pane);
  }

  function insert(t) {
    var p = store.S.project, sc = p.scenarios[state.scId];
    if (!sc) { dlg().close(); return; }
    var text = L.fill(t.text, state.values);
    var list = state.kind === 'cause' ? sc.causes : sc.consequences;
    var dup = list.filter(function (x) { return L.sameText(x.text, text); })[0];
    if (dup) { alert('This scenario already has that ' + (state.kind === 'cause' ? 'cause' : 'consequence') + '. Edit the existing item instead.'); return; }
    var extra = { teamStatus: 'pending', source: { kind: 'library', templateId: t.id, scope: t.scope, template: t.text, at: new Date().toISOString() } };
    store.change(function (proj) {
      var s2 = proj.scenarios[sc.id];
      if (state.kind === 'cause') store.addCause(s2, text, extra);
      else { var q = store.addConsequence(s2, text, extra); if (t.category && (proj.project.riskMatrix.categories || []).indexOf(t.category) >= 0) q.category = t.category; }
      L.remember(proj, state.values);
    });
    dlg().close();
    PHA.panel.flash('Inserted from Quick Add. Edit it if needed, then press Confirm when the team agrees it applies.');
  }

  /* Template editor. t null = new. Project templates are part of the project (undoable, exported in .phaz);
     personal templates are saved in this browser. */
  function editTemplate(t, kind, text, category) {
    var body = el('div', { 'class': 'qa-edit' });
    var ta = el('textarea', { rows: 3, 'data-te': 'text' }); ta.value = text || '';
    var cat = el('input', { type: 'text', 'data-te': 'category', value: category || '', placeholder: 'e.g. Fire, Valve position' });
    var kindSel = el('select', { 'data-te': 'kind' }, [el('option', { value: 'cause' }, 'Initiating cause'), el('option', { value: 'consequence' }, 'Consequence')]);
    kindSel.value = kind;
    var where = el('select', { 'data-te': 'scope', disabled: t ? true : null },
      [el('option', { value: 'project' }, 'This project (travels in the .phaz file)'), el('option', { value: 'personal', disabled: L.personalState() === 'unavailable' ? true : null }, 'My templates (this browser, all projects)')]);
    where.value = t ? t.scope : 'project';
    body.appendChild(el('p', { 'class': 'muted' }, 'Use placeholders in square brackets for values filled in at insertion: ' + L.STANDARD.map(function (s) { return '[' + s + ']'; }).join(' ') + '.'));
    body.appendChild(PHA.ui.field('Wording', ta));
    body.appendChild(el('div', { 'class': 'row two' }, PHA.ui.field('Kind', kindSel), PHA.ui.field('Category (optional)', cat)));
    body.appendChild(PHA.ui.field('Save in', where));
    var buttons = [{ key: null, label: 'Cancel' }];
    if (t) buttons.push({ key: 'delete', label: 'Delete template', cls: 'danger' });
    buttons.push({ key: 'ok', label: 'Save template', cls: 'primary' });
    return PHA.dashboard.ask(t ? 'Edit template' : 'New template', body, buttons).then(async function (k) {
      if (!k) { if (dlg().open) render(); return; }
      var scope = where.value, rec = { kind: kindSel.value, category: cat.value.trim(), text: ta.value.trim() };
      if (k === 'ok' && !rec.text) { alert('A template needs wording.'); return editTemplate(t, rec.kind, '', rec.category); }
      try {
        if (scope === 'project') {
          store.change(function (proj) {
            var arr = proj.library.templates;
            if (k === 'delete') { proj.library.templates = arr.filter(function (x) { return x.id !== t.id; }); return; }
            var x = t ? arr.filter(function (y) { return y.id === t.id; })[0] : null;
            if (x) Object.assign(x, rec); else arr.push(Object.assign(L.newTemplate(rec.kind, rec.text, rec.category), {}));
          });
        } else {
          var next = L.copyPersonal();
          if (k === 'delete') { next.templates = next.templates.filter(function (x) { return x.id !== t.id; }); next.favorites = next.favorites.filter(function (x) { return x !== t.id; }); }
          else {
            var y = t ? next.templates.filter(function (z) { return z.id === t.id; })[0] : null;
            if (y) Object.assign(y, rec); else next.templates.push(L.newTemplate(rec.kind, rec.text, rec.category));
          }
          await L.savePersonal(next);
        }
        PHA.panel.flash(k === 'delete' ? 'Template deleted.' : 'Template saved.');
      } catch (e) {
        alert('The template was not saved: ' + (e.message || e) + '\n\nNothing was changed.');
      }
      if (dlg().open) render();
    });
  }

  function open(kind, sc) {
    state.kind = kind; state.scId = sc.id; state.pickId = null; state.values = {}; state.q = ''; state.scope = 'all';   // each opening starts unfiltered
    render(); show(dlg());
    var s = dlg().querySelector('[data-qa=search]'); if (s) s.focus();
  }
  function saveAsTemplate(kind, text, category) { return editTemplate(null, kind, text, category); }

  store.on('change', function (e) { if (dlg() && dlg().open && e.kind !== 'field') render(); });
  L.onChange(function () { if (dlg() && dlg().open) render(); });

  PHA.quickadd = { open: open, saveAsTemplate: saveAsTemplate, editTemplate: editTemplate };
})();
