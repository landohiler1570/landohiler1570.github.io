/* util.js: small helpers shared by every module. Everything hangs off one global, window.PHA. */
(function () {
  'use strict';
  var PHA = window.PHA = window.PHA || {};

  function uid(prefix) {
    var hex;
    if (window.crypto && crypto.randomUUID) {
      hex = crypto.randomUUID().replace(/-/g, '');
    } else {
      var b = new Uint8Array(16);
      crypto.getRandomValues(b);
      hex = Array.prototype.map.call(b, function (x) { return x.toString(16).padStart(2, '0'); }).join('');
    }
    return prefix + '_' + hex.slice(0, 16);
  }

  /* SHA-256 of a Uint8Array as hex. Needs a secure context; falls back to a random token. */
  async function sha256(bytes) {
    if (window.crypto && crypto.subtle) {
      try {
        var d = await crypto.subtle.digest('SHA-256', bytes);
        return Array.prototype.map.call(new Uint8Array(d), function (x) { return x.toString(16).padStart(2, '0'); }).join('');
      } catch (e) { /* fall through */ }
    }
    return 'nohash' + uid('').slice(1) + uid('').slice(1);
  }

  /* el('div', {class:'x', onclick:fn}, child, 'text', [more]) */
  function el(tag, attrs) {
    var e = document.createElement(tag);
    var kids = Array.prototype.slice.call(arguments, 2);
    var flat = [];
    (function push(a) { a.forEach(function (c) { Array.isArray(c) ? push(c) : flat.push(c); }); })(kids);
    flat.forEach(function (c) {
      if (c == null || c === false) return;
      e.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    });
    var value;
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v == null || v === false) return;
        if (k === 'class') e.className = v;
        else if (k === 'value') value = v;
        else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
        else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
        else if (v === true) e.setAttribute(k, '');
        else e.setAttribute(k, v);
      });
    }
    if (value !== undefined) e.value = value;   // after children, so <select> picks the right option
    return e;
  }

  function sv(tag, attrs) {
    var e = document.createElementNS('http://www.w3.org/2000/svg', tag);
    if (attrs) Object.keys(attrs).forEach(function (k) { if (attrs[k] != null) e.setAttribute(k, attrs[k]); });
    return e;
  }

  function debounce(fn, ms) {
    var t;
    return function () {
      var a = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, a); }, ms);
    };
  }

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function download(bytesOrBlob, name, type) {
    var blob = bytesOrBlob instanceof Blob ? bytesOrBlob : new Blob([bytesOrBlob], { type: type || 'application/octet-stream' });
    var url = URL.createObjectURL(blob);
    var a = el('a', { href: url, download: name });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
  }

  function stamp() {
    var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes());
  }

  function clock(d) {
    d = d || new Date();
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }

  function safeName(s) {
    return (s || 'pha-project').replace(/[^\w\-. ]+/g, '').trim().replace(/\s+/g, '-') || 'pha-project';
  }

  function isTyping(e) {
    var t = e.target;
    return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
  }

  PHA.util = { uid: uid, sha256: sha256, el: el, sv: sv, debounce: debounce, clamp: clamp,
               download: download, stamp: stamp, clock: clock, safeName: safeName, isTyping: isTyping };
})();
