PHA WORKSPACE - version 0.5.0 (Milestone A: scenario workflow and Quick-Add libraries)
=====================================================================================

An offline, P&ID-centered PHA tool. HTML, CSS and JavaScript only. No install, no server,
no internet. Projects saved by versions 0.1 to 0.4 open in this one, and 0.4.0 can still open
projects saved by 0.5.0 (same project format 3).

  P&ID for process context > Scenario Wizard for analysis > Node Board for group review >
  Repository for institutional memory > Report Builder for documentation.
  The software assists the PHA team; it does not replace its technical judgment.

NEW IN 0.5.0 - THE EIGHT-STEP WIZARD
------------------------------------
Select a node, then "+ Review a deviation" (or click a deviation in the node's list).
  1 Deviation        Parameter + guideword; the deviation is shown in large text.
  2 Applicable?      "Is this deviation applicable to the selected node?"
                       Yes          -> then choose how it is dispositioned:
                                       Analyse as a scenario (explicit; Yes alone creates nothing)
                                       No credible hazardous scenario (written finding required)
                                       Covered elsewhere (reference required)
                       No           -> technical justification required; no scenario
                       Not reviewed -> stays outstanding in the completion summary
  3 Causes           One cause per entry, typed or with Quick Add. The same text twice in one
                     scenario is refused. "Give this cause its own scenario" when it needs
                     different consequences or safeguards.
  4 Failure sequence How the deviation could escalate (write it conditionally: "may", "if"),
                     then the hazardous event: Loss of containment / Other hazardous event.
                     Or tick "No intermediate mechanism". The chain cause > deviation >
                     mechanism > event > consequences is shown as you go.
  5 Consequences     Ultimate outcomes, one per entry, typed or with Quick Add, each with
                     optional escalation conditions ("if ignition occurs") and category.
  6 Safeguards  7 Risk  8 Recommendations and review (as in 0.4.0).
  "A+" in the wizard header enlarges the text for a meeting-room screen.
  The full scenario editor shows the same fields (including the failure sequence) at once.

QUICK ADD
  "Quick Add..." next to the cause and consequence entry boxes opens the library:
  - Built-in: generic wording written for this application (copy it to change it).
  - This project: templates saved in the project; they travel in the .phaz file.
  - My templates: saved in this browser for all projects.
  - Favorites: star any template.
  Pick a template, fill its placeholders ([Material], [Tag], [Equipment], [Location],
  [Operation], [Failure Event]); suggestion buttons show values already in the project
  (the node's equipment tags, the scenario's hazardous event, values typed before). Nothing is
  filled in automatically and nothing is invented. A blank placeholder stays in brackets and
  is flagged. "+ New template" creates one; the star button on an item saves its wording.
  Inserted items are marked "not yet confirmed by the team as credible" until someone presses
  Confirm. A scenario cannot be marked Reviewed while it has unconfirmed items or unfilled
  placeholders.

PREVIOUS RELEASE (0.4.0) - still applies, except that the six wizard steps in item 1 are now the
eight steps above
------------------------
1. Select a node on the drawing (or in the node list). Under "Deviation review" click
   "+ Review a deviation". The Scenario Wizard opens in the left panel; the P&ID stays visible.

   Step 1 Deviation    Pick parameter and guideword. The deviation is shown in large text.
                       Ask the team: is it applicable / credible for this node?
                         Yes          -> continue to the analysis
                         No           -> type the technical basis (required) and Save decision.
                                         No scenario is created.
                         Not reviewed -> saved as outstanding; the study stays incomplete.
   Step 2 Causes       "What could cause this deviation?" Type one cause, press Enter. Repeat.
                       Each cause is its own record: edit it in place, reorder, or remove it.
                       "Give this cause its own scenario" when it leads to different
                       consequences or safeguards (same deviation, new scenario).
   Step 3 Consequences One consequence per entry (Enter adds). With several causes, the C1/C2
                       buttons mark which causes a consequence follows from (none = all).
   Step 4 Safeguards   Add new safeguards, or "Select an existing safeguard" to reuse a record
                       already in the study. Mark each Preventive or Mitigative. Listing a
                       safeguard does not mean it is effective; use Safeguard evaluation for that.
   Step 5 Risk         Ranked with the study's configured matrix (see Modules > Risk matrix).
                       The band's risk-reduction requirement is shown if one is entered.
   Step 6 Review       Recommendations, then the summary card. Mark the scenario Reviewed
                       (only when cause, consequence and ranking are recorded), Pending
                       verification, or leave it Draft.

   The step buttons at the top go to any step; nothing is lost moving back and forward.
   Everything is saved as it is typed (autosave, as before).

2. Full editor: click a scenario in the panel (or "+ Add scenario (full editor)") to see every
   field at once. Wizard and full editor edit the same records; switch with "Open in wizard" /
   "Full editor".

3. Checklist...: adds chosen parameter x guideword combinations to a node as Not reviewed, so the
   team can work through them and nothing is forgotten.

4. Node Board: the "P&ID View | Node Board" switch above the drawing. Scenario cards built from
   the records. Selected node / All nodes, filters for node, deviation text, risk ranking,
   status and open recommendations. Each node shows a completion summary and its not-reviewed
   and not-applicable deviations. Click a card to open it in the full editor ("Wizard" on the
   card opens the wizard). Long lists show "Show all" rather than being cut off.

5. Node labels on the drawing now show the node ID (plus the scenario count). The full name is
   in the tooltip and in the panel. "Labels: ID / ID + name" switches to a shortened name.

6. Report: "Study info" in the top bar records purpose, scope, objectives, exclusions, revision,
   team, session dates and assumptions. "Report" opens the Report Builder: tick sections,
   check the preview, then Print / Save as PDF. In the print dialog choose Letter, Margins
   Default, and turn browser "Headers and footers" OFF (the report prints its own header,
   DRAFT marking and page numbers). "Annotated drawings" downloads each drawing with its node
   boundaries as a full-size PNG (a zip when there are several).

7. Repository screen: "Print register" prints an index of the listed projects (name, facility,
   methodology, revision, status, last modified, completion, backup). It reads only the
   catalog, plus the project record for projects last saved by 0.3.0; never the drawings.

Reports never claim more than the records show: an incomplete study is marked "DRAFT - STUDY
INCOMPLETE" on the cover and every page header, every scenario carries its status, and the
"Study completion and outstanding items" section lists unreviewed deviations, scenarios
awaiting verification, missing rankings, open recommendations, open assumptions and missing
supporting information. See MIGRATION.txt for how older projects are converted.

See CHANGELOG.txt for what changed, ARCHITECTURE.txt for how the repository works and what
its limits are, and TEST-RESULTS.txt for what was tested.

HOW TO RUN
  Unzip the folder anywhere and double-click index.html. Use Microsoft Edge or Chrome.
  Keep index.html together with the css, js, lib and tests folders.

HOW IT WORKS NOW
  The app opens on the Project repository. Your studies are kept in this browser's storage
  on this computer and saved automatically while you work.

    Repository -> Open project -> P&ID workspace -> (autosave) -> "Projects" to go back

  + New project     create a study (name, facility, study type, methodology)
  Open              load a study straight from the repository
  Import .phaz      add a project file to the repository (also .json exports)
  Export            write a complete .phaz file to this computer
  More              Duplicate, change status, Archive / Restore, Delete

  In the workspace the top bar shows two things:
    Saved locally / Unsaved changes / Saving... / Save failed   - the repository copy
    Exported / Not exported / Export out of date / Download started - the .phaz backup

THE ONE RULE TO REMEMBER
  The repository is a working copy held by the browser. It can be wiped by "Clear browsing
  data", by IT policy, by a new Windows profile or by a disk failure. A .phaz file is the
  only permanent copy. Export each study after every session and keep the files where your
  site keeps controlled records. The repository screen warns you which projects need it.

TESTING IN EDGE AND CHROME (do this on the work computer, in each browser you will use)
  Each browser, and each browser profile, has its own separate repository.

  1. System check (top right of the repository screen). Every line should say OK, except
     "Storage protection", which normally says LIMITED. FAIL on "Project repository" means
     the browser will not keep projects: stop and tell IT.
  2. Open tests/tests.html. It should show "All 293 tests passed" in green. These tests use
     temporary databases and do not touch your projects.
  3. The acceptance test:
       a. + New project, give it a name, Create and open.
       b. Import P&ID and pick samples/sample-pid.pdf, then one of your own drawings.
       c. Draw a node, name it, add a scenario with a cause and a safeguard.
       d. Wait for the green "Saved locally" in the top bar.
       e. Close the browser completely (every window). Reopen index.html.
       f. The project must be listed. Open it. The drawing, node and scenario must be there
          without importing anything.
  4. Export: in the project click Export .phaz and choose a location. Change something and
     click Export .phaz again. In Edge and Chrome the second export should not ask where to
     save and the pill should read "Exported". If it reads "Download started", the browser
     could not confirm the file: check the Downloads folder.
  5. Reimport: back on the repository, More -> Delete the project (tick the box), then
     Import .phaz and pick the file you exported. Open it and check nothing is missing.
  6. Overnight: repeat 3e and 3f the next morning. If the project is gone, your browser is
     set to clear its data and the repository cannot be relied on. Use .phaz files only.
  7. Optional: click "Backup folder", pick a folder, then click the button again. Each
     project that needs a backup is written there as its own .phaz file.
  8. Not for InPrivate / Incognito windows: those delete the repository when closed.

MODULES
  Click "Modules" in the workspace. Risk matrix is on by default; Operating parameters and
  limits, Process Safety Time, Safeguard evaluation and Human factors start off. Set project
  defaults there, and select a node first to give that node its own setting. Turning a
  module off only hides it. Nothing is deleted.

KEYS (in the workspace)
  In the wizard and item lists: Enter adds the item, Shift+Enter starts a new line in it.
  In the Report Builder: Ctrl+P prints the report.
  V select | H pan | P polygon node | R box node | Esc cancel | Enter finish polygon
  Backspace remove last point | + - zoom | 0 fit
  Ctrl+S export .phaz | Ctrl+Shift+S export as
  Ctrl+Z undo | Ctrl+Y redo (inside a text box these act on the text only)

FILES
  index.html          page layout and the list of scripts
  css/app.css         all styling
  js/util.js          small shared helpers
  js/calc.js          calculations and checks (no screen code)
  js/store.js         the open project, file-format upgrades, undo/redo
  js/viewer.js        PDF rendering, zoom and pan
  js/annotate.js      drawing and editing node regions
  js/panel.js         the analysis panel on the left
  js/modules.js       module switches, status, risk ranking, safeguard evaluation
  js/opparams.js      operating parameters, checks and envelope
  js/pst.js           process safety time timeline
  js/humanfactors.js  human factors prompts
  js/persist.js       drawing import, reading and writing .phaz files
  js/repo.js          the project repository (IndexedDB), no screen code
  js/autosave.js      autosave, save status, close-time recovery
  js/dashboard.js     the repository screen
  js/review.js        deviation review, completeness and completion counts     [0.4.0]
  js/library.js       Quick-Add libraries, placeholders, personal templates    [0.5.0]
  js/quickadd.js      Quick-Add dialog and template editor                     [0.5.0]
  js/wizard.js        Scenario Wizard and the individual-item list editors     [0.4.0]
  js/board.js         Node Board and scenario cards                            [0.4.0]
  js/study.js         Study information dialog                                 [0.4.0]
  js/reportgen.js     builds the report HTML from the records (no screen code) [0.4.0]
  js/report.js        Report Builder screen, drawing images, register          [0.4.0]
  css/report.css      Report Builder and the print stylesheet                  [0.4.0]
  js/diag.js          the System check
  js/main.js          startup and wiring
  lib/                PDF.js 3.11.174 and fflate (zip), bundled for offline use. The PDF.js worker is
                      stored as a text string so it can start from disk; its code is unchanged.
  tests/              offline tests, with real 0.1 and 0.2 project files as fixtures
  tests/browser/      developer-only end-to-end scripts (need Node.js + Playwright; not needed
                      to use or test the app on a work computer)
  licenses/           licenses for the two libraries
  samples/            a synthetic sample P&ID for testing

IMPORTANT LIMITS
  - The app never supplies an engineering value. Every limit and time is what the team types.
  - Consistency checks compare entries with each other. They do not confirm a limit is correct.
  - Process Safety Time is a plain sum of the entered times, not a validated model. A positive
    margin does not by itself show that a safeguard is effective.
  - The 5x5 risk matrix is a placeholder until you enter your site's labels and thresholds.
  - Browser storage is not an archive. See "The one rule to remember".

NOT YET BUILT
  Excel export, a separate shared safeguard register screen, traced-line regions, drawing
  revision replacement, sign-off / audit trail, Word output.

THE PROJECT FILE
  A .phaz file is a normal zip. Inside: project.json (all records) and drawings/<fingerprint>.pdf
  (the original drawing files, byte for byte). 0.4.0 writes project format 3 (individual cause
  and consequence records, deviation review records). Older versions of the app refuse format 3
  files with a clear message rather than opening them partly. Keep 0.3.0 exports if anyone
  still needs to open them in 0.3.0. See MIGRATION.txt.
